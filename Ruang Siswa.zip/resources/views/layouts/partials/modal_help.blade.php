@push('css-styles')
<style>
#modal-quickEdit .form-label { color: var(--bs-primary); font-size: 10pt; }
#modal-quickEdit input { font-size: 9pt; }
</style>
@endpush

<div class="modal fade" id="modal-help" aria-hidden="true"> 
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center gap-2 fs-14" style="font-weight:500"><i class='bx bx-help-circle'></i><span id="modal-help-title">Help</span></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="modal-help-body" class="modal-body fs-11">
            </div>
            <div class="modal-footer gap-2">
                <button type="button" class="btn btn-sm btn-secondary gap-1" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i>Close</button>
            </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script type="text/javascript">
const modalHelp = (topic) => {
    let modal_title = '';
    let modal_content = '';
    switch(topic) {
        case 'book_access':
            modal_title = 'About book access';
            modal_content = `
                <p class="mb-1">This option will determine who can view and access the book:</p>
                <ul>
                    <li><b>Open</b>, anyone can view and access this book including guest. If you choose this option, you have to make sure that <b>you have the permission of the publisher</b>. You also have to attach the source info in the provided input field.</li>
                    <li><b>Limited</b>, only registered user can view and access this book. This is the <b>default</b> setting.</li>
                    <li><b>Teacher only</b>, student can't view or access this book.</li>
                </ul>
            `;
        break;
    }
    $('#modal-help-title').html(modal_title);
    $('#modal-help-body').html(modal_content);
    $('#modal-help').modal('show');
};
</script>
@endpush