
<div class="modal fade" id="" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center fw-bold"><i class='bx bxs-user me-2'></i><span></span></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/" id="" method="POST">
            @csrf
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary me-3" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Cancel</button>
                <button type="submit" id="" class="btn btn-sm btn-primary"><i class='bx bx-chevrons-right' ></i> Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>