<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Authority;
use App\Models\Profile;
use App\Models\Book;
use App\Models\Notification;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Builder;
use File;
use ZipArchive;
use Response;
use DB;

class AdminController extends Controller
{
    public function __construct() {
        $this->metaTags = [
            'title' => 'Digital Library',
            'description' => 'Unlock the World of Knowledge!',
        ];
    }
    public function user()
    {
        $users = (Auth::user()->authority->name == 'superadmin') ? User::get() : User::whereHas('authority', function (Builder $query) {
            $query->where('name', '!=', 'superadmin');
        })->get();
        return view('admin.user', [
            'dashboard_header' => '<i class="bx bxs-user me-3"></i><span>User Controller</span>',
            'metaTags' => $this->metaTags,
            'page_title' => 'Digital Library | Admin',
            'authorities' => Authority::get(),
            'users' => $users,
        ]);
    }
    public function action(Request $request)
    {
        switch($request->action) {
            case 'change_authority':
                $update = User::find($request->user_id)->update(['authority_id' => $request->authority_id]);
                return response()->json([
                    'message' => 'User authority updated',
                ], 200);
            break;
            case 'reset_password':
                $user = User::find($request->user_id); $messages = []; $error = false;
                $password = $request->password; $password_confirmation = $request->password_confirmation;
                if($password != $password_confirmation) {
                    $error = true;
                    $messages[] = "password confirmation doesnt't match";
                }
                if(strlen($password) < 6) {
                    $error = true;
                    $messages[] = "must consist of at least 6 characters";
                }
                if($error == false) {
                    $user->update([ 'password' => Hash::make($request->password), ]);
                    return response()->json([
                        'message' => "password updated",
                    ], 200);
                }
                return response()->json([
                    'message' => 'An error occured',
                    'messages' => $messages,
                ], 400);
            break;
        }
    }
}
