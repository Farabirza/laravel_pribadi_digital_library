<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\GeneralController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\BookmarkController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\NotificationController;

Route::get('/', [GeneralController::class, 'index'])->name('home');
Route::get('/home', function () { return redirect('/'); });

Route::group([
    'middleware' => ['auth', 'verified', 'isAdmin'],
    'prefix' => 'admin'
    ], function () {
        Route::get('/user', [AdminController::class, 'user']);
});

Route::group([
    'middleware' => ['auth'],
    ], function () {
    Route::resource('/profile', ProfileController::class);
    Route::resource('/book', BookController::class, ['except' => ['show', 'index']] )->middleware('verified');
    Route::resource('/review', ReviewController::class)->middleware('verified');
    Route::get('/review/{book_id}/delete', [ReviewController::class, 'delete'])->middleware('verified');
    Route::resource('/bookmark', BookmarkController::class)->middleware('verified');
    Route::resource('/report', ReportController::class)->middleware('verified');
    Route::get('/report/{book_id}/delete', [ReportController::class, 'delete'])->middleware('verified');
});
Route::resource('/book', BookController::class)->only(['show', 'index']);

Route::group([
    'prefix' => 'action'
    ], function () {
    Route::post('/admin', [AdminController::class, 'action'])->middleware(['auth', 'verified', 'isAdmin']);
    Route::post('/user', [UsersController::class, 'action'])->middleware('auth');
    Route::post('/profile', [ProfileController::class, 'action'])->middleware('auth');
    Route::post('/book', [BookController::class, 'action'])->middleware(['auth', 'verified']);
    Route::post('/bookmark', [BookmarkController::class, 'action'])->middleware(['auth', 'verified']);
    Route::post('/report', [ReportController::class, 'action'])->middleware(['auth', 'verified']);
    Route::post('/notification', [NotificationController::class, 'action'])->middleware(['auth', 'verified']);
    Route::post('/general', [GeneralController::class, 'action']);
});

Route::group([
    'middleware' => ['auth', 'verified'],
    'prefix' => 'book'
    ], function () {
    Route::post('/quick_update', [BookController::class, 'quick_update']);
    Route::get('/{book_id}/delete', [BookController::class, 'delete'])->middleware('isAdmin');
});
Route::get('/{book_id}/{chapter_id}/read', [BookController::class, 'visit']);
Route::get('/notification/clear', [NotificationController::class, 'clear']);

Route::resource('/user', UsersController::class)->only(['store']);
Route::get('auth/google', [UsersController::class, 'google_login'])->name('google.login');
Route::get('auth/google/callback', [UsersController::class, 'google_callback'])->name('google.callback');
Route::post('auth/google/register', [UsersController::class, 'google_register']);
Route::post('/update_password', [UsersController::class, 'update_password']);

Auth::routes(['verify'=>true]);
