<!-- Check login status -->
<?php if(auth()->guard()->check()): ?>
<?php header("Location: /home"); die(); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="description" content="Blank Laravel Template by irzafarabi.com" />
<meta name="keywords" lan="en" content="blank, laravel, template" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Blank Laravel Template" />
<meta property="og:description" content="Blank Laravel Template by irzafarabi.com" />
<meta property="og:url" content="https://www.irzafarabi.com/" />
<meta property="og:site_name" content="www.irzafarabi.com" />
<meta property="og:image" content="<?php echo e(asset('img/bg/office-1.jpg')); ?>" />
<meta property="og:image:type" content="image/jpg" />
<meta property="og:image:width" content="1366" />
<meta property="og:image:height" content="768" />

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.1.1.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/aos/aos.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>Blank Laravel Template</title>

<style>
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark { color: #124265; } .title-light { color: #f1f1f1; }

.section-hero

.img-logo-sm { width: 60px; }
.img-logo-md { width: 120px; }

@media (max-width: 768px) {
}
</style>
</head>
<body>

<?php echo $__env->make('layouts/partials/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- section-hero -->
<section id="section-hero">
    <div class="container">
        <div class="row vh-100 vertical-center justify-content-center">
            <h1 class="text-center">Hellow</h1>
        </div>
    </div>
</section>
<!-- section-hero end -->

</body>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/aos/aos.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('/js/navbar.js')); ?>"></script>

<!-- Purecounter -->
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
$(document).ready(function(){
  <?php if(session('success')): ?>
    successMessage("<?php echo e(session('success')); ?>");
  <?php elseif(session('error')): ?>
    errorMessage("<?php echo e(session('error')); ?>");
  <?php endif; ?>
  <?php if(isset($_GET['admin']) == 'false'): ?>
    Swal.fire({
      icon: 'error',
      title: "Access Denied!",
      text: "You are not an admin!",
      showConfirmButton: false,
      timer: 2000
    });
  <?php endif; ?>
  
});
  function successMessage(message) {
      toastr.success(message, 'Success!');
  } 
  function infoMessage(message) {
      toastr.info(message, 'Info');
  } 
  function warningMessage(message) {
      toastr.error(message, 'Warning!');
  } 
  function errorMessage(message) {
      toastr.error(message, 'Error!');
  } 
</script>
</html><?php /**PATH C:\xampp\htdocs\- CV Kreatif\Laravel CVKreatif\resources\views/index.blade.php ENDPATH**/ ?>