<?php if(auth()->guard()->check()): ?>
<?php if($user->id != Auth::user()->id): ?>
<?php if($user->config->access === 'draft'): ?> <?php header("Location: /?info=halaman ini tidak dibuka untuk umum"); die(); ?> <?php endif; ?>
<?php endif; ?>
<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>
<?php if($user->config->access === 'registered'): ?> <?php header("Location: /?login=required"); die(); ?> <?php endif; ?>
<?php if($user->config->access === 'draft'): ?> <?php header("Location: /?info=halaman ini tidak dibuka untuk umum"); die(); ?> <?php endif; ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="keywords" lan="en" content="<?php if(isset($config->meta_keywords)): ?><?php echo e($config->meta_keywords); ?><?php else: ?> cvkreatif.com, cv kreatif, portofolio, cv online <?php endif; ?>" />
<meta property="og:type" content="laravel app" />
<meta property="og:title" content="cvkreatif.com" />
<meta property="og:description" content="<?php if($config->meta_description): ?><?php echo e($config->meta_description); ?><?php else: ?> Buat halaman portofolio kamu di sini, gratis! <?php endif; ?>" />
<meta property="og:url" content="https://www.cvkreatif.com/" />
<meta property="og:site_name" content="www.cvkreatif.com" />
<meta property="og:image" content="<?php echo e(asset('img/materials/landing.jpg')); ?>" />
<meta property="og:image:type" content="image/jpg" />
<meta property="og:image:width" content="1366" />
<meta property="og:image:height" content="768" />

<meta name="twitter:image" content="<?php echo e(asset('img/materials/landing.jpg')); ?>">

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.6.0.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/aos/aos.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>cvkreatif.com <?php if($config->meta_title): ?>| <?php echo e($config->meta_title); ?> <?php else: ?> | <?php echo e($user->profile->first_name.' '.$user->profile->last_name); ?> <?php endif; ?></title>
  
<?php echo $__env->yieldPushContent('css-styles'); ?>
<style>
#main { min-height: 100vh; background: #f9f9f9; }
@media (max-width: 768px) {
}
</style>
</head>
<body>

<!-- ======= Header ======= -->
<?php if(auth()->guard()->check()): ?>
<?php if($user->id == Auth::user()->id): ?>
<?php echo $__env->make('layouts/partials/topbar_owner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php endif; ?>
<!-- ======= Header end ======= -->

<!-- ======= Main content ======= -->
<main id="main">
<?php echo $__env->yieldContent('content'); ?> <!-- Contents here! -->

<!-- include('layouts.partials.footer') ======= Footer ======= -->
</main>
<!-- ======= Main content end ======= -->

<!-- <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a> -->

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>

<script type="text/javascript">
const lightbox = GLightbox({
    selector: '.glightbox',
});
const lightbox1 = GLightbox({
    selector: '.glightbox1', touchNavigation: true, loop: true, autoplayVideos: true
});
$(document).ready(function(){
  // Animate on scroll
  AOS.init({ once: true,  easing: 'ease-in-out-sine' });
  
  // tooltip
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
  })

  // popperjs
    $('.popper').popover({ 
        trigger: 'hover',
        html: true,
        placement: 'bottom',
        container: 'body'
    });
});

// toaster simplified
function successMessage(message) { toastr.success(message, 'Success!'); } 
function infoMessage(message) { toastr.info(message, 'Info'); } 
function warningMessage(message) { toastr.error(message, 'Warning!'); } 
function errorMessage(message) { toastr.error(message, 'Error!'); } 
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/layouts/master_cv.blade.php ENDPATH**/ ?>