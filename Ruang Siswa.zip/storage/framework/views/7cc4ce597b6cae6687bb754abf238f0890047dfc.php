

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/dropzone/dropzone.min.css')); ?>" rel="stylesheet">
<style>
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark { color: #124265; } .title-light { color: #f1f1f1; }

.dropzone-container { 
    display: none;
    background: #f9f9f9;
    box-shadow: 0 0 1px rgba(0,0,0,.125),0 1px 3px rgba(0,0,0,.2);
    padding: 20px; 
    text-align: center;
}
.dropzone, .dropzone-notif {
    background: white;
    border-radius: 5px;
    border: 2px dashed rgb(0, 135, 247);
    border-image: none;
} .dropzone-notif { padding: 40px 0; text-align: center; }
.dropzone-notes { display: none; }

.sign-submitted { background: var(--bs-success); }
.sign-noSubmission { background: var(--bs-danger); }
.sign-submitted, .sign-noSubmission { padding: 4px; border-radius: 4px; font-size: 11pt; color: white; margin-left: 8px; }

table tr { vertical-align: middle; }
table .bx-check, table .bx-x { font-weight: 800; font-size: 16pt; }

#dropzone-container-title { display: none; }
@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-profile -->
<section id="section-profile" class="ptb-60 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 text-center">
                <img src="<?php echo e(asset('/img/profiles/'.Auth::user()->profile->image)); ?>" id="profile-img" alt="" class="rounded-circle mb-4 box-shadow-1">
                <h3 class="profile-name layout-5 mb-2">Welcome, <span style="color:#ff5546"><?php echo e(Auth::user()->profile->first_name); ?> <?php echo e(Auth::user()->profile->last_name); ?></span></h3>
                <p class="text-muted fst-italic"><?php echo e(Auth::user()->group->name); ?></p>
            </div>
        </div>
    </div>
</section>
<!-- section-profile end -->

<!-- section-assignment -->
<section id="section-assignment" class="ptb-60">
    <div class="container">
        <div class="row justify-content-center">

            <div class="col-md-12 text-center mb-4">
                <h1 class="section-title title-dark">My Assignment</h1>
            </div>

            <div class="col-md-12 mb-4">
                <h4 class="mb-3">Assignment List</h4>
                <table class="table table-striped">
                    <thead>
                        <th>#</th>
                        <th>Title</th>
                        <th class="text-center">Submitted</th>
                        <th class="text-center">Confirmed</th>
                        <th>Comment</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $myAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><span class="popper" title="<b>Time Limit</b><br><?php echo e($item['date_limit']); ?><br><?php echo e($item['time_limit']); ?>"><?php echo e($item['title']); ?></span></td>
                            <td class="text-center"><?php if($item['submitted'] == 1): ?> <i class='bx bx-check popper' style="color:var(--bs-primary)" title="<b>Submitted at</b><br><?php echo e($item['submitted_at']); ?>"></i> <?php else: ?> <i class='bx bx-x' style="color:var(--bs-danger)"></i> <?php endif; ?></td>
                            <td class="text-center"><?php if($item['confirmed'] == 1): ?> <i class='bx bx-check' style="color:var(--bs-primary)"></i> <?php else: ?> <i class='bx bx-x' style="color:var(--bs-danger)"></i> <?php endif; ?></td>
                            <td><?php if($item['comment']): ?> <?php echo e($item['comment']); ?> <?php else: ?> - <?php endif; ?></td>
                            <td><a href="<?php echo e($item['id']); ?>" class="show_assignment btn btn-success btn-sm mr-4"><i class='bx bx-show'></i> Show</a></td>
                            <?php $i++; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="text-center">There is no assignment for you</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="col-md-12 mb-2">
                <h4 id="dropzone-container-title" class="mb-4">Submit Assignment</h4>

                <!-- Dropzone -->
                <div id="dropzone-container" class="dropzone-container div-md-12 card mb-3">
                    <h4 class="assignment-title vertical-center justify-content-center">
                        <input type="hidden" name="assignment_id" id="assignment_id" value="">
                        <span id="assignment-title">Assignment Title</span>
                        <span class="sign sign-noSubmission">Not submitted yet</span>
                    </h4>
                    <p id="assignment-timeLimit" class="mb-2">Time limit</p>
                    <p id="assignment-description" class="text-muted mb-3">Brief description</p>
                    <div id="assignment-dropzone">
                        <div class="dropzone"></div>
                    </div>
                    <!-- <form action="<?php echo e(route('submit_assignment')); ?>" class='dropzone' method="POST">
                    </form> -->
                </div>
                <!-- Dropzone end -->
            </div>

            <div class="col-md-12 dropzone-notes">
                <p class="text-muted fst-italic">*File format must be ".pdf" with maximum size : 10 Mb</p>
            </div>
        </div>
    </div>
</section>
<!-- section-assignment end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/dropzone/dropzone.min.js')); ?>"></script>
<script type="text/javascript">
    var CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]').getAttribute("content");
    Dropzone.autoDiscover = false;
    var assignDropzone = new Dropzone(".dropzone",{ 
        // addRemoveLinks: true,
        autoProcessQueue: false,
        url: '/submit_assignment',
        maxFilesize: 10,  // 4 mb
        acceptedFiles: ".pdf",
    });
    assignDropzone.on('addedfile', function(file) {
        if (this.files[1]!=null){
            $('.dz-button').remove();
            this.removeFile(this.files[0]);
        }
        var filename = file.name, filename = filename.toLowerCase();
        var ext = filename.split('.').pop();
        if (ext == "pdf") {
            $('.dz-image').css('background','none').addClass('d-flex').addClass('justify-content-center');
            $(file.previewElement).find(".dz-image img").attr("src", "<?php echo e(asset('img/icons/icon-pdf.png')); ?>");
        } else if (ext.indexOf("doc") != -1) {
            $(file.previewElement).find(".dz-image img").attr("src", "<?php echo e(asset('img/icons/icon-doc.png')); ?>");
        }
        $('.dropzone').append('<div class="dz-button ptb-20"><button class="dz-submit btn btn-outline-primary" type="submit">Submit</button></div>');
        $(".dz-submit").click(function (e) {
            e.preventDefault();
            assignDropzone.processQueue();
        });
    });
    assignDropzone.on("sending", function(file, xhr, formData) {
        var assignment_id = $('#assignment_id').val();
        formData.append("_token", CSRF_TOKEN);
        formData.append("assignment_id", assignment_id);
    });
    assignDropzone.on("success", function(file, response) {
        successMessage(response.msg);
        $('.dz-button').remove();
        $('.sign').remove();
        $('.assignment-title').append('<span class="sign sign-submitted">Submitted</span>');
    });
</script>
<script src="<?php echo e(asset('/js/ajax_assignment.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project - Calendar\Sprachschule Mitra Leipzig\resources\views/calendar/assignment.blade.php ENDPATH**/ ?>