<?php if(auth()->guard()->guest()): ?>
<?php header("Location: /?login=required"); die(); ?>
<?php endif; ?>



<?php $__env->startPush('css-styles'); ?>
<style>
#main { min-height: 100vh; background: #f9f9f9; }
.bl-darkblue-md { color: #374785; }
.theme-list-item:hover { cursor: pointer; box-shadow: 2px 2px 10px #333; }

.card-img-container { position: relative; }
.card-img-container:hover .card-overlay { opacity: 1; }
.card-overlay {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    height: 100%;
    width: 100%;
    opacity: 0;
    transition: .5s ease;
    background-color: #008CBA;
}
.card-overlay-text {
    color: white;
    font-size: 20px;
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    text-align: center;
}

#help-access { cursor: pointer; }

@media (max-width: 768px) {
    #section-form { padding-top: 20px; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<section id="section-form" class="py-40">
    <div class="container">

        <?php echo $__env->make('cv.partials.wizard_progressbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="row mb-4">
            <div class="col-md-12">
                <h3 class="fw-bold ps-3 fs-32 bl-darkblue-md">Konfigurasi</h3>
            </div>
        </div> <!-- row end -->

        <div class="row mb-4">

            <div class="col-md-12">
                <h3 class="fs-24 fw-bold">Tema</h3>
            </div>

            <?php $i = 1; ?>

            <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 p-3"> <!-- Theme item -->
                <div class="card bg-white shadow-sm theme-list-item">
                    <div class="card-img-container">
                        <img src="<?php echo e(asset('img/theme_preview/'.$theme->preview_img)); ?>" class="card-img-top" alt="...">
                        <div class="card-overlay">
                            <div class="card-overlay-text"><?php echo e($theme->title); ?></div>
                        </div>
                    </div>
                    <div class="card-body p-4">
                        <p class="fs-12 fw-bold mb-1"><?php echo e($theme->title); ?></p>
                        <p class="fs-11 text-primary mb-2">Gratis</p>
                        <button type="button" id="btn-activate-<?php echo e($i); ?>" data-theme-id="<?php echo e($theme->id); ?>" class="btn btn-primary btn-sm w-100 mb-2 btn-theme-activate"><i class='bx bx-check-double'></i> Aktif</button>
                        <a href="/" class="btn btn-success btn-sm w-100" target="_blank"><i class='bx bx-show-alt'></i> Lihat contoh</a>
                    </div>
                </div>
            </div> <!-- Theme item end -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php $i++; ?>
        </div> <!-- row end -->
            
        <div class="row mb-4"> <!-- row start -->
            
            <!-------- form start -------->
            <form id="form-upload-cover" action="/upload/cover_image" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="col-md-12 card p-3 mb-4">
                <div class="card-body">
                    <h3 class="fs-24 fw-bold mb-3">Gambar Sampul</h3>
                    <div class="d-flex justify-content-center align-items-center mb-3 flex-remove-md">
                        <?php if(Auth::user()->profile->cover_image): ?>
                        <img src="<?php echo e(asset('img/covers/'.Auth::user()->profile->cover_image)); ?>" id="cover_preview" class="img-fluid img-thumbnail mb-2" style="max-height:320px"/>
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/bg/default.jpg')); ?>" id="cover_preview" class="img-fluid img-thumbnail mb-2" style="max-height:320px"/>
                        <?php endif; ?>
                        <div class="col form-group ps-3">
                            <label for="cover_image" class="form-label">Pilih gambar</label>
                            <input type="file" name="cover_image" class="form-control mb-2" accept="image/png, image/jpeg, image/jpg"/>
                            <p class="fs-10 text-muted fst-italic mb-3">*pilih file gambar dengan format ".png, .jpg, atau .jpeg"</p>
                            <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-upload me-2'></i>Upload gambar</button>
                        </div>
                    </div>
                </div>
            </div>
            </form>
            <!-- form end -->

            <!-------- form start -------->
            <form id="form-config" method="POST" enctype="multipart/form-data">

            <div class="col-md-12 card p-3 mb-4">
                <div class="card-body">
                    <h3 class="fs-24 fw-bold">Aksesibilitas</h3>
                    <div class="form-group d-flex flex-remove-md justify-content-between">
                        <label class="form-label pt-2 col">Siapa saja yang dapat mengunjungi halaman CV anda? <i id="help-access" class='bx bx-help-circle' data-bs-toggle="tooltip" data-bs-placement="top" title="Penjelasan"></i></label>
                        <select name="access" class="form-control form-select col select-access" required>
                            <option value="public">Publik</option>
                            <option value="draft">Hanya saya sendiri</option>
                            <option value="registered">Pengunjung terdaftar</option>
                            <option value="link">Pengunjung dengan link</option>
                        </select>
                    </div>
                </div>
            </div>
        </div> <!-- row end -->

        <div class="row"> <!-- row start -->
            <!-- form button -->
            <hr class="mb-3"/>
            <div class="form-group d-flex justify-content-end">
                <button type="submit" class="btn btn-success me-2 btn-form-save"><i class='bx bxs-save' ></i> Simpan</button>
                <a href="/wizard/skill?from=100" class="btn btn-secondary me-2"><i class='bx bx-left-arrow-alt' ></i> Sebelumnya</a>
                <a href="/wizard/finish?complete=true" class="btn btn-primary btn-warn me-2"><i class='bx bx-right-arrow-alt' ></i> Selesai</a>
            </div>
            <!-- form button end -->
        </div> <!-- row end -->

        </form>
        <!-------- form end -------->

    </div>
</section>

            
<!-- Modal help access -->
<div class="modal fade" id="modal-help-access" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title fs-18 display-5"><i class='bx bx-help-circle me-1'></i> Penjelasan menu aksesibilitas</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h5 class="fw-bold">Publik</h5>
                <p class="fs-11">Semua orang dapat mengakses halaman CV tanpa perlu membuat akun CVKreatif.com. Halaman CV juga dapat diakses melalui fitur search.</p>
                <h5 class="fw-bold">Hanya saya sendiri</h5>
                <p class="fs-11">Hanya pemilik yang dapat mengakses halaman CV. Fitur ini digunakan apabila CV masih belum siap ditayangkan secara umum.</p>
                <h5 class="fw-bold">Pengunjung terdaftar</h5>
                <p class="fs-11">Dapat dicari melalui fitur search namun hanya pengunjung terdaftar yang dapat mengakses halaman CV.</p>
                <h5 class="fw-bold">Pengunjung dengan link</h5>
                <p class="fs-11">Tidak dapat dicari melalui fitur search namun siapa saja dapat mengakses halaman CV langsung melalui link yang dibagikan pemilik.</p>
            </div>
        </div>
    </div>
</div>
<!-- Modal help access end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function(e){
    <?php if(isset($_GET['warn']) == 'config'): ?>
    Swal.fire({
      icon: 'error',
      title: "Gagal!",
      text: "Selesaikan dan simpan konfigurasi anda",
      showConfirmButton: false,
      timer: 2000
    });
    <?php endif; ?>

    // selected access
    let selected_access = '<?php echo e($config->access); ?>';
    $("[name='access'] option[value='" + selected_access + "']").attr('selected', 'selected');

    // Progressbar
    $('.progress-list').removeClass('progress-list-active');
    $('#progress-list-config').addClass('progress-list-active');
    $('.progress-bar').css('width','100%').attr('aria-valuenow','100');

    // Form
    $('#form-config').change(function(e){
        $('.btn-form-save').removeClass('disabled');
    });
});

// cover image
$('[name="cover_image"]').change(function() {
    let reader = new FileReader();
    reader.onload = (e) => { 
        $('#cover_preview').attr('src', e.target.result); 
    }
    reader.readAsDataURL(this.files[0]); 
});

$('#help-access').click(function(){
    $('#modal-help-access').modal('show');
});

// btn-theme-activate
$('.btn-theme-activate').click(function(e) {
    $('.btn-theme-activate').removeClass('active btn-primary').addClass('btn-outline-primary').html(
        '<i class="bx bx-check"></i> Aktifkan'
    );
    $(this).addClass('active btn-primary').removeClass('btn-outline-primary').html(
        '<i class="bx bx-check-double"></i> Aktif'
    );
});

</script>
<script src="<?php echo e(asset('/js/script_progressbar.js')); ?>"></script>
<script src="<?php echo e(asset('/js/ajax_wizard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/wizard_config.blade.php ENDPATH**/ ?>