<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta content="iCalendar made by irzafarabi" name="description">
<meta content="" name="keywords">

<!-- Vendor JS Files -->
<!-- <script src="<?php echo e(asset('/vendor/jquery/jquery-3.6.0.min.js')); ?>"></script> -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.1.1.min.js')); ?>"></script>

<!-- Favicons -->
<!-- <link href="<?php echo e(asset('/img/logo/logo_book_small.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo_book.png')); ?>" rel="apple-touch-icon"> -->

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<!-- <link href="<?php echo e(asset('/vendor/aos/aos.css')); ?>" rel="stylesheet"> -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>iCalendar</title>
  
<?php echo $__env->yieldPushContent('css-styles'); ?>
<style>
  #section-footer { background: #272829; }
  #section-footer p { margin: 0; font-size: 11pt; color: #f1f1f1; }
</style>
</head>
<body>
<!-- ======= Mobile nav toggle button ======= -->
<!-- <i class="bi bi-list mobile-nav-toggle d-xl-none"></i> -->

<!-- ======= Header ======= -->
<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======= Header end ======= -->

<!-- ======= Main content ======= -->
<main id="main">
<?php echo $__env->yieldContent('content'); ?> <!-- Contents here! -->

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- ======= Footer ======= -->
</main>
<!-- ======= Main content end ======= -->

<!-- <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a> -->

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>"></script> -->

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>


<script type="text/javascript">
$(document).ready(function(){
    var navbarHeight = $('#navbar').outerHeight();
    $('#main').css('padding-top',navbarHeight);
  <?php if(session('success')): ?>
    Swal.fire({
      icon: 'success',
      title: "<?php echo e(session('success')); ?>",
      showConfirmButton: false,
      timer: 2000
    });
  <?php endif; ?>
  <?php if(isset($_GET['admin']) == 'false'): ?>
    Swal.fire({
      icon: 'error',
      title: "Access Denied!",
      text: "You are not an admin!",
      showConfirmButton: false,
      timer: 2000
    });
  <?php endif; ?>
});
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\Project - Calendar\iCalendar\resources\views/layouts/master.blade.php ENDPATH**/ ?>