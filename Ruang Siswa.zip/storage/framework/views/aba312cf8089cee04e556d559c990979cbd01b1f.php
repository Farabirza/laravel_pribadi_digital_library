<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta content="" name="description">
<meta content="" name="keywords">

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.1.1.min.js')); ?>"></script>

<!-- Favicons -->
<!-- <link href="<?php echo e(asset('/img/logo/logo_book_small.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo_book.png')); ?>" rel="apple-touch-icon"> -->

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>Sprachschule Mitra Leipzig | Sign in</title>
  
<style>
#section-register {
    height: 100vh;
    background: url('../img/bg/bg_trans-60.png') top left repeat, url("../img/bg/bg-hero-1.jpg") top center transparent fixed;
    background-size: cover;
}
#form-register { background: #fff; padding: 60px 40px; border-radius: 8px; }
</style>
</head>
<body>

<section id="section-register">
    <div class="container py-5 h-100">
        <div class="row d-flex h-100 justify-content-center align-items-center">
            <div id="form-register" class="col-md-8">
                <h1 class="display-5">Sprachschule Mitra Leipzig</h1>
                <p class="mb-40">Register a new account</p>

                <form action="/register" method="POST">
                <?php echo csrf_field(); ?>
                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                    <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>  
                    <div class="form-group mb-3">
                        <input type="email" class="form-control" name="email" placeholder="Email Address" value="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(old('email')); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="form-group mb-3">
                        <input type="password" class="form-control mb-3" name="password" placeholder="Password">
                        <input type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br><div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br><div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php if($group_exist): ?>
                        <select name="group" id="select-group" class="form-control form-select">
                            <option value="" selected disabled hidden>Select User Group</option>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->name); ?>"><?php echo e($group->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="-">Other</option>
                        </select>
                        <input type="text" name="group-alt" id="input-group" class="form-control" placeholder="Insert Group's Name" value="<?php $__errorArgs = ['group-alt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(old('group-alt')); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php else: ?>
                        <input type="hidden" name="group" value="-">
                        <input type="text" name="group-alt" id="input-group-empty" class="form-control" placeholder="Insert Group's Name" value="<?php $__errorArgs = ['group-alt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(old('group-alt')); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php endif; ?>
                        <?php $__errorArgs = ['group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br><div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3 d-flex">
                        <input type="name" class="form-control col" name="first_name" placeholder="First Name" value="<?php echo e(old('first_name')); ?>">
                        <span>&ensp;</span>
                        <input type="name" class="form-control col" name="last_name" placeholder="Last Name" value="<?php echo e(old('last_name')); ?>">
                    </div>
                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="form-group mb-5">
                        <select name="gender" class="form-control form-select">
                            <option value="select" selected disabled hidden>Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    

                    <div class="pt-1 mb-3">
                        <button class="btn btn-outline-primary mr-8" type="submit"><i class='bx bx-user' ></i> Register</button>
                        <a class="btn btn-outline-danger" href="/login" type="button"><i class='bx bx-arrow-back' ></i> Back to Login Page</a>
                    </div>
                </form>

            </div>
        </div>
    </div>
</section>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>


<script type="text/javascript">
$(document).ready(function(){
    <?php if($group_exist): ?>
    const select_group = document.getElementById('select-group');
    const input_group = $('#input-group');
    input_group.css('display', 'none');

    select_group.addEventListener('change', function handleChange(event) {
        if (event.target.value === '-') {
        $('#select-group').addClass('mb-3');
        input_group.css('display', 'block');
        } else {
        $('#select-group').removeClass('mb-3');
        input_group.css('display', 'none');
        }
    });
    <?php endif; ?>
});
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\Project - Calendar\Sprachschule Mitra Leipzig\resources\views/auth/register.blade.php ENDPATH**/ ?>