

<?php $__env->startPush('css-styles'); ?>
<style>
.certif-item-add { min-height: 240px; }
.certif-item .card:hover { 
    cursor: pointer; 
    color: #fff;
    background-color: #0d6efd;
    transition: ease-in-out .3s;
} .certif-img { max-height: 240px; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content" class="bg-light">
    <div class="container">
        <!------------------------------- row start ------------------------->
        <div class="row mb-4">
            <!-- Form Dashboard education Start -->
            <div class="col-md-12 card bg-white p-4 shadow-sm">
                <div class="mb-4">
                    <h3 class="fw-bold ps-3 border-start border-primary border-5 mb-0">Riwayat pendidikan</h3>
                </div>

                <!-- education history start -->
                <table id="table-visitor" class="table table-striped align-middle mb-3">
                    <thead>
                        <tr>
                            <th>Tahun</th>
                            <th>Institusi pendidikan</th>
                            <th>Program studi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($edu->year_start.' - '.$edu->year_end); ?></td>
                            <td><?php echo e($edu->institution); ?></td>
                            <td><?php echo e($edu->major); ?></td>
                            <td class="d-flex flex-wrap">
                                <span class="btn btn-success btn-sm d-flex align-items-center btn-edu-edit" data-edu-id="<?php echo e($edu->id); ?>"><i class="bx bx-edit-alt me-1"></i>Edit</span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="text-center">Data tidak ditemukan</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <p class="mb-0 d-flex">
                    <span class="btn btn-primary btn-sm d-flex align-items-center btn-edu-add"><i class="bx bx-plus me-1"></i> Tambahkan</span>
                </p>
                <!-- education history end -->

            </div> <!-- col 12 end -->
            <!-- Form Dashboard education End -->
        </div>
        <!------------------------------- row end ------------------------->

        <!------------------------------- row start ------------------------->
        <div class="row mb-4">
            <!-- Form Dashboard certificate Start -->
            <div class="col-md-12 card bg-white p-4 shadow-sm">
                <div class="mb-4">
                    <h3 class="fw-bold ps-3 border-start border-primary border-5 mb-0">Sertifikat pelatihan</h3>
                </div>

                
                <div class="certif-container d-flex flex-wrap mb-2">
                    <!-- certif-item start -->
                    <?php if($certificates): ?>
                    <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="certif-item me-3 mb-3 bg-light text-primary">
                        <div class="certif-item-edit certif-card card rounded shadow-sm" data-id="<?php echo e($certif->id); ?>">
                            <div class="my-auto text-center p-3">
                                <img src="<?php echo e(asset('img/certificates/'.$certif->image)); ?>" class="certif-img img-fluid mb-3"/>
                                <p class="fs-10 mb-0"><?php echo e($certif->title); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <label for="certif_image" class="prevent-select">
                    <div class="certif-item me-3 mb-3 bg-light text-primary">
                        <div class="certif-item-add certif-card card px-5 rounded shadow-sm">
                            <div class="my-auto">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                <span class="fs-14 fw-bold">Tambahkan</span>
                            </div>
                        </div>
                    </div>
                    </label>
                    <!-- certif-item end -->
                </div>
                <p class="fs-11 fst-italic text-muted">*lampirkan file dalam format ".png, .jpg, dan jpeg" dengan ukuran maksimal 10mb</p>

            </div>
        <!------------------------------- row end ------------------------->
    </div>
</section>

<!-- Modal Education Add -->
<div class="modal fade" id="modal-edu-add" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center"><i class='bx bx-plus me-2'></i><span>Tambahkan riwayat pendidikan</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/dashboard/add/education" id="form-edu-add" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body fs-10">
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="add-year_start" placeholder="tahun masuk" value="" required>
                        <label for="add-year_start" class="form-label">Tahun masuk</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="add-year_end" placeholder="tahun lulus" value="" required>
                        <label for="add-year_end" class="form-label">Tahun lulus</label>
                    </div>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="add-institution" placeholder="institusi pendidikan" value="" required>
                    <label for="add-institution" class="form-label">Institusi pendidikan</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="add-major" placeholder="program studi" value="" required>
                    <label for="add-major" class="form-label">Program studi</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-plus' ></i> Tambahkan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal Education Add end -->

<!-- Modal Education Edit -->
<div class="modal fade" id="modal-edu-edit" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center"><i class='bx bx-edit-alt me-2'></i><span>Edit riwayat pendidikan</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/dashboard/update/education" id="form-edu-edit" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="edit-education_id" value="">
            <div class="modal-body fs-10">
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="edit-year_start" placeholder="tahun masuk" value="" required>
                        <label for="edit-year_start" class="form-label">Tahun masuk</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="edit-year_end" placeholder="tahun lulus" value="" required>
                        <label for="edit-year_end" class="form-label">Tahun lulus</label>
                    </div>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="edit-institution" placeholder="institusi pendidikan" value="" required>
                    <label for="edit-institution" class="form-label">Institusi pendidikan</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="edit-major" placeholder="program studi" value="" required>
                    <label for="edit-major" class="form-label">Program studi</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <a href="/dashboard/delete" class="btn btn-danger btn-warn-delete btn-sm mr-4 btn-delete-education"><i class='bx bx-trash-alt'></i> Hapus</a>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-edit-alt' ></i> Update</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal Education Edit end -->


<!-- modal new certificate-training start -->
<div class="modal fade" id="modal-certif-training" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center"><i class='bx bxs-file-plus me-2'></i> Upload File Sertifikat</h4>
                <button type="button" class="btn-close modal-certif-cancel" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/upload/certif_training" id="form-certif-training" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="col mb-3">
                    <img src="" id="certif_preview" class="img-fluid">
                </div>
                <hr/>
                <input id="certif_image" class="absolute w-full h-full d-none" name="certif_image" accept="image/png, image/jpeg, image/jpg" type="file">
                <div class="form-floating mb-3">
                    <input type="text" name="title" class="form-control form-control-sm" placeholder="title" value="">
                    <label for="title" class="form-label">Judul</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" name="issued_by" class="form-control form-control-sm" placeholder="issued by" value="">
                    <label for="title" class="form-label">Dikeluarkan oleh</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" name="category" class="form-control form-control-sm form-sm" placeholder="category" value="">
                    <label for="category" class="form-label">Kategori</label>
                </div>
                <div class="form-group mb-3">
                    <label for="description" class="form-label">Deskripsi</label>
                    <textarea name="description" rows="3" class="form-control form-control-sm"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-certif-cancel btn btn-sm btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back me-1'></i>Batalkan</button>
                <button type="submit" id="modal-certif-submit" class="btn btn-sm btn-primary"><i class='bx bxs-file-plus me-1'></i>Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- modal new certificate-training end -->

<!-- modal edit certif start -->
<div class="modal fade" id="modal-certif-edit" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center"><i class='bx bx-file me-2'></i> Edit Detail Sertifikat</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/update/certif_training" id="form-certif-edit" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="edit-certif_id" value=""/>
            <div class="modal-body">
                <div id="certif-edit-preview" class="col text-center mb-3"></div>
                <div class="form-floating mb-3">
                    <input type="text" name="edit-title" class="form-control form-control-sm" placeholder="title" value="">
                    <label for="edit-title" class="form-label">Judul</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" name="edit-issued_by" class="form-control form-control-sm" placeholder="issued by" value="">
                    <label for="title" class="form-label">Dikeluarkan oleh</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" name="edit-category" class="form-control form-control-sm form-sm" placeholder="category" value="">
                    <label for="edit-category" class="form-label">Kategori</label>
                </div>
                <div class="form-group mb-3">
                    <label for="edit-description" class="form-label">Deskripsi</label>
                    <textarea name="edit-description" rows="3" class="form-control form-control-sm"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back me-1'></i>Batalkan</button>
                <a href="/delete/certif_training" id="modal-certif-delete" class="btn btn-danger btn-warn-delete"><i class='bx bx-trash-alt me-1'></i>Hapus</a>
                <button type="submit" id="modal-certif-update" class="btn btn-primary"><i class='bx bx-edit-alt me-1'></i>Update</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- modal edit certif end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$('.btn-edu-add').click(function(){
    $('#modal-edu-add').modal('show');
});
$('.btn-edu-edit').click(function(){
    var edu_id = $(this).attr('data-edu-id');
    var formData = { 
        action: 'edit_education', education_id: edu_id,
    };
    $.ajax({
        type: "POST",
        url: "/ajax/dashboard",
        data: formData,
        dataType: 'JSON',
        success: function (data) {
            $('.btn-delete-education').attr('href', '/dashboard/delete/education/'+edu_id);
            $('[name="edit-education_id"]').val(edu_id);
            $('[name="edit-year_start"]').val(data.education.year_start);
            $('[name="edit-year_end"]').val(data.education.year_end);
            $('[name="edit-institution"]').val(data.education.institution);
            $('[name="edit-major"]').val(data.education.major);
            $('#modal-edu-edit').modal('show');
        }, error:function(data) {
            errorMessage('Terdapat kesalahan');
        },
    });
});

// Education - certificate training
$("[name='certif_image']").change(function(e) {
    let modal = $('#modal-certif-training');
    let reader = new FileReader();
    reader.onload = (e) => { 
        $('#certif_preview').attr('src', e.target.result); 
    }
    reader.readAsDataURL(this.files[0]); 

    let get_file = $(this).val();
    var file = $(this)[0].files[0];
    $('#modal-certif-submit').removeClass('disabled');
    $("[name='title']").val(file.name);
    modal.modal('show');
    $('.modal-certif-cancel').click(function(){ $('#form-certif-training').trigger("reset").unbind(); }); // cancel
});
$('.certif-item-edit').click(function(){
    $(document.body).css({'cursor' : 'wait'});
    let certif_id = $(this).attr('data-id');
    let modal = $('#modal-certif-edit');
    formData = { action: "edit_certif_training", certif_id: certif_id, }
    $.ajax({
        type: "POST",
        url: "/ajax/dashboard",
        data: formData,
        dataType: 'JSON',
        success: function (data) {
            if(data.success == true) {
                $('#certif-edit-preview').html('<img src="../../img/certificates/' + data.certificate.image + '" class="img-fluid" style="max-height:320px"/>');
                $('[name="edit-certif_id"]').val(data.certificate.id);
                $('[name="edit-title"]').val(data.certificate.title);
                $('[name="edit-issued_by"]').val(data.certificate.issued_by);
                $('[name="edit-category"]').val(data.certificate.category);
                $('[name="edit-description"]').val(data.certificate.description);
                $('#modal-certif-delete').attr('href', '/delete/certif_training/' + data.certificate.id);
                modal.modal('show');
            } else {
                errorMessage(data.message);
            }
        }, error:function(data) {
            errorMessage('Terdapat kesalahan')
        }, complete:function() {
            $(document.body).css({'cursor' : 'default'});
        }
    });
});

$(document).ready(function(){ 
    $('.nav-link').removeClass('active'); $('#link-edit').addClass('active'); $('#link-edit_education').addClass('active'); $('#submenu-edit').addClass('show'); // nav-link active
    
    // certificate item height
    var maxHeight = Math.max.apply(null, $("div.certif-card").map(function () {
        return $(this).height();
    }).get());
    $('.certif-card').css('height', maxHeight);
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/dashboard/edit_education.blade.php ENDPATH**/ ?>