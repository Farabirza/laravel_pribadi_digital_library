<?php if(auth()->guard()->guest()): ?>
<?php header("Location: /?login=required"); die(); ?>
<?php endif; ?>



<?php $__env->startPush('css-styles'); ?>
<style>
    #main { min-height: 100vh; background: #f9f9f9; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-form" class="py-60">
    <div class="container">
        <?php echo $__env->make('cv.partials.cv_create_disclaimer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-------- form start -------->
        <form id="form-profile" action="/form/cv/profile" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row mb-4 align-items-center">
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold text-dark ps-3 mb-3 fs-32 bl-dark-md">Profil</h3>
            </div>

            <div class="col-md-12"> <!-- col form start -->

                <!-- name  -->
                <div class="form-group d-flex mb-4">
                    <div class="form-floating col">
                        <input type="text" class="form-control" name="first_name" placeholder="Nama depan" value="<?php echo e(old('first_name')); ?>">
                        <label for="first_name" class="form-label">Nama depan</label>
                    </div>
                    <span>&ensp;</span>
                    <div class="form-floating col">
                        <input type="text" class="form-control" name="last_name" placeholder="Nama belakang" value="<?php echo e(old('last_name')); ?>">
                        <label for="last_name" class="form-label">Nama belakang</label>
                    </div>
                </div>
                <!-- name end -->

                <!-- gender & birth data  -->
                <div class="form-group mb-4">
                    <div class="d-flex">
                        <div class="form-floating col">
                            <select id="gender" name="gender" class="form-control form-select">
                                <option value="select" selected disabled hidden>Gender</option>
                                <option value="male">Laki-laki</option>
                                <option value="female">Perempuan</option>
                            </select>
                            <label for="gender" class="form-label">Jenis kelamin</label>
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <span>&ensp;</span>
                        <div class="form-floating col">
                            <input type="date" min="1950-01-01" max="<?php echo e(date('Y-m-d', time())); ?>" id="birth_date" class="form-control" name="birth_date" value="" required>
                            <label for="birth_date" class="form-label">Tanggal lahir</label>
                        </div>
                    </div>
                </div>
                <!-- gender & birth data end -->
                
                <!-- address -->
                <div class="form-group mb-3">
                    <label class="text-muted mb-2">Domisili</label>
                    <div class="d-flex">
                        <div class="form-floating col">
                            <input type="text" class="form-control" name="address_city" placeholder="City" value="<?php echo e(old('city')); ?>" required>
                            <label for="city" class="form-label">Kota / kabupaten</label>
                        </div>
                        <span>&ensp;</span>
                        <div class="form-floating col">
                            <input type="text" class="form-control" name="address_province" placeholder="Province" value="<?php echo e(old('province')); ?>" required>
                            <label for="province" class="form-label">Provinsi</label>
                        </div>
                        <span>&ensp;</span>
                        <div class="form-floating col">
                            <input type="number" class="form-control" name="zip" placeholder="Zip" value="<?php echo e(old('zip')); ?>" required>
                            <label for="zip" class="form-label">Kode pos</label>
                        </div>
                    </div>
                </div>
                <!-- address -->

            </div><!-- col form start end -->
        </div> <!-- row end -->

        <div class="row"> <!-- row start -->
            <!-- form button -->
            <hr class="mb-3"/>
            <div class="form-group d-flex justify-content-end">
                <button type="submit" id="btn-form-save" class="btn btn-success me-2 disabled"><i class='bx bxs-save' ></i> Simpan</button>
                <a href="/cv/create/education" class="btn btn-primary me-2"><i class='bx bx-right-arrow-alt' ></i> Selanjutnya</a>
            </div>
            <!-- form button end -->
        </div> <!-- row end -->

        </form>
        <!-------- form end -------->

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function(e){
    // Form
    $('#form-profile').change(function(e){
        $('.btn-form-save').removeClass('disabled');
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/cv_create_profile.blade.php ENDPATH**/ ?>