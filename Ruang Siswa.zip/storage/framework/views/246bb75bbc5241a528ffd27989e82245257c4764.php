<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com - Duplicate\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>