<!-- Check wether this user is an admin -->
<?php if(Auth::user()->role == 'user'): ?>
<?php header("Location: /?admin=false"); die(); ?>
<?php endif; ?>
<!-- Check wether this user is an admin -->



<?php $__env->startPush('css-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('/vendor/fontawesome/fontawesome.js')); ?>" crossorigin="anonymous"></script>
<style>
.popper { cursor: help; }
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark, .icon-dark { color: #124265; } .title-light, .icon-light { color: #f1f1f1; }
.title-icon { font-size: 28pt; }
table tr { vertical-align: middle; }
.form-label { color: #149ddd; }

.container-score {
    display: none;
    padding: 40px 20px;
    border-top: 8px solid #fac863;
    box-shadow: 0 0 1px rgba(0,0,0,.125),0 1px 3px rgba(0,0,0,.2);
}
/* .tableContainer { overflow: scroll; } */
@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-assignments -->
<section id="section-assignments" class="ptb-60">
    <div class="container">
        <div class="row justify-content-center">
            <!-- section_title -->
            <div class="col-md-12 mb-3 text-center">
                <i class='bx bxs-report title-icon icon-dark mb-2'></i>
                <h2 class="section-title title-dark">Reports</h2>
            </div>
            <!-- section_title end -->
        </div>

        <div class="row justify-content-center mb-3">
            <div class="col-md-12 mb-2">
                <h3>Based on User</h3>
            </div>
            <div class="col-md-12">
                <form id="form-score-user" action="/ajax_statistics" method="post">
                <div class="form-group d-flex">
                    <input type="hidden" name="action" value="show_score_user">
                    <select name="user_id" id="select-score-user" class="col form-control form-select mr-8">
                        <option value="0" selected disabled hidden>Select User</option>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->email); ?> | <?php echo e($user->profile->first_name.' '.$user->profile->last_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </select>
                    <button type="submit" id="submit-score-user" class="btn btn-primary"><i class='bx bxs-report'></i> Generate</button>
                </div>
                </form>
            </div>
            <div class="col-md-12 mb-3 container-score" id="container-score-user">
            </div>
        </div>
        <!-- row end -->

        <div class="row mb-3"><hr style="color:#124265"></div>
        <div class="row justify-content-center">
            <div class="col-md-12 mb-2">
                <h3>Based on Group</h3>
            </div>
        </div>
        <div class="col-md-12">
            <form id="form-score-group" action="/ajax_statistics" method="post">
            <div class="form-group d-flex">
                <input type="hidden" name="action" value="show_score_user">
                <select name="user_id" id="select-score-group" class="col form-control form-select mr-8">
                    <option value="0" selected disabled hidden>Select Group</option>
                    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </select>
                <button type="submit" id="submit-score-group" class="btn btn-primary"><i class='bx bxs-report'></i> Generate</button>
            </div>
            </form>
        </div>
        <div class="col-md-12 mb-3 container-score" id="container-score-group">
        </div>
        <!-- row end -->
    </div>
</section>
<!-- section-assignments end -->

<!-- section-profiles -->
<section id="section-profiles" class="bg-light ptb-60">
    <div class="container">
        <div class="row justify-content-center">
            <!-- section_title -->
            <div class="col-md-12 mb-3 text-center">
                <i class='bx bx-user title-icon icon-dark mb-2'></i>
                <h2 class="section-title title-dark">Users</h2>
            </div>
            <!-- section_title end -->

            <div class="container-table-profile col-md-12 mb-4">
                <h3 class="mb-3">Biodata</h3>
                <table id="table-profiles-1" class="table table-striped table-hover">
                    <thead>
                        <th>#</th>
                        <th>Full name</th>
                        <th>Gender</th>
                        <th>Birth place</th>
                        <th>Birth date</th>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><span class="popper" title="<?php echo e($item->email); ?>"><?php echo e($item->profile->first_name . ' ' . $item->profile->last_name); ?></span></td>
                            <td><?php echo e($item->profile->gender); ?></td>
                            <td><?php echo e($item->profile->birth_place); ?></td>
                            <td><?php echo e($item->profile->birth_date); ?></td>
                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mb-4"><hr></div>
            <div class="container-table-profile col-md-12">
                <h3 class="mb-3">Data</h3>
                <table id="table-profiles-2" class="table table-striped table-hover">
                    <thead>
                        <th>#</th>
                        <th>Full name</th>
                        <th>Contact</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Province</th>
                        <th>ZIP</th>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><span class="popper" title="<?php echo e($item->email); ?>"><?php echo e($item->profile->first_name . ' ' . $item->profile->last_name); ?></span></td>
                            <td><?php echo e($item->profile->contact); ?></td>
                            <td><?php echo e($item->profile->address_street); ?></td>
                            <td><?php echo e($item->profile->address_city); ?></td>
                            <td><?php echo e($item->profile->address_province); ?></td>
                            <td><?php echo e($item->profile->zip); ?></td>
                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div> <!-- end row -->
    </div>
</section>
<!-- section-profiles end -->

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
$(document).ready(function(){
    const lightbox = GLightbox({
        touchNavigation: true,
        loop: true,
        autoplayVideos: true
    });
    var table_profiles_1 = $('#table-profiles-1').DataTable();
    var table_profiles_2 = $('#table-profiles-2').DataTable();
    
    table_profiles_1.on('order.dt search.dt', function () {
        let i = 1;
        table_profiles_1.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(i++);
        });
    }).draw();
    table_profiles_2.on('order.dt search.dt', function () {
        let i = 2;
        table_profiles_2.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(i++);
        });
    }).draw();
});
</script>
<script type="text/javascript">
$(document).ready(function(){
    $('.nav-link').removeClass('active');
    $('.nav-link-admin').addClass('active');
});
</script>
<script src="<?php echo e(asset('/js/ajax_statistics.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/admin/statistics.blade.php ENDPATH**/ ?>