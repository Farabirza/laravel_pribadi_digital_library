<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="description" content="cvkreatif.com" />
<?php if(Auth::user()->config->meta_keywords): ?>
<meta name="keywords" lan="id" content="<?php echo e(Auth::user()->config->meta_keywords); ?>" />
<?php else: ?>
<meta name="keywords" lan="id" content="cvkreatif.com, cv kreafif, cvkreatif, portofolio online, portofolio, curriculum vitae" />
<?php endif; ?>
<meta property="og:type" content="laravel app" />
<meta property="og:title" content="cvkreatif.com" />
<?php if(Auth::user()->config->meta_description): ?>
<meta property="og:description" content="<?php echo e(Auth::user()->config->meta_description); ?>" />
<?php else: ?>
<meta property="og:description" content="Buat halaman portofolio kamu di sini, gratis!" />
<?php endif; ?>
<meta property="og:url" content="https://www.cvkreatif.com/" />
<meta property="og:site_name" content="www.cvkreatif.com" />
<?php if(Auth::user()->profile->cover_image): ?>
<meta property="og:image" content="<?php echo e(asset('img/covers/'.Auth::user()->profile->cover_image)); ?>" />
<?php else: ?>
<meta property="og:image" content="<?php echo e(asset('img/materials/landing.jpg')); ?>" />
<?php endif; ?>
<meta property="og:image:type" content="image/jpg" />
<meta property="og:image:width" content="1366" />
<meta property="og:image:height" content="768" />

<?php if(Auth::user()->profile->cover_image): ?>
<meta name="twitter:image" content="<?php echo e(asset('img/covers/'.Auth::user()->profile->cover_image)); ?>">
<?php else: ?>
<meta name="twitter:image" content="<?php echo e(asset('img/materials/landing.jpg')); ?>">
<?php endif; ?>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.6.0.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>cvkreatif.com <?php if(isset($page_title)): ?>| <?php echo e($page_title); ?> <?php endif; ?></title>
  
<?php echo $__env->yieldPushContent('css-styles'); ?>
<style>
:root {
  --sidebar-width: 240px;
}
a:hover { color: inherit }
/* ========================== Navigation start ========================== */
#sidebar-dashboard {
    z-index: 999;
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: var(--sidebar-width);
    transition: all ease-in-out 0.5s;
    transition: all 0.5s;
    padding: 0 15px;
    overflow-y: auto;
} .mobile-nav-toggle {
  position: fixed;
  right: 15px;
  top: 15px;
  z-index: 9998;
  border: 0;
  font-size: 24px;
  transition: all 0.4s;
  outline: none !important;
  color: #fff;
  width: 40px;
  height: 40px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  line-height: 0;
  border-radius: 50px;
  cursor: pointer;
} .mobile-nav-active {
  overflow: hidden;
} .mobile-nav-active #sidebar-dashboard {
  left: 0;
}

#section-header-dashboard { position: relative; }

#main, #container-header-dashboard {
    padding-left: var(--sidebar-width);
}

#section-content { padding: 30px 20px; }
@media (max-width: 768px) {
    #section-content { padding: 30px 1%; }
}

@media (max-width: 1199px) {
    #toggle-sidebar { display: none; }
    #main, #container-header-dashboard { padding-left: 0 }
    #sidebar-dashboard {
        left: calc(var(--sidebar-width) * -1);
    }
}
/* ========================== Navigation end ========================== */
@media (max-width: 768px) {
}
</style>
</head>
<body>
<!-- ======= Mobile nav toggle button ======= -->
<i class="bi bi-list mobile-nav-toggle bg-dark d-xl-none"></i>

 <!-- ======================================= sidebar start ================================================== -->
 <header>
 <div id="sidebar-dashboard" class="d-flex flex-column flex-shrink-0 bg-dark">
    <a href="/" class="text-center pt-3 mb-1 popper" title="ke beranda">
        <img src="<?php echo e(asset('img/logo/logo_long_white.png')); ?>" alt="">
    </a>
    <span class="px-4 mb-3">
        <img src="<?php echo e(asset('img/profiles/'.Auth::user()->profile->image)); ?>" alt="" class="rounded rounded-circle shadow">
    </span>
    <p class="text-center text-lowercase fw-semibold mb-0" style="color:#ddd"><a href="/cv/<?php echo e(Auth::user()->username); ?>" class="popper" title="ke halaman CV"><?php echo e('@'.Auth::user()->username); ?></a></p>
    <hr class="text-white"/>
    <nav class="nav-menu navbar">
        <ul>
            <a href="/dashboard/overview"><li id="link-overview" class="nav-link mb-3"><i class="bx bxs-dashboard"></i><span>Overview</span></li></a>
            <a href="/dashboard/analytics"><li id="link-analytics" class="nav-link mb-3"><i class="bx bxs-bar-chart-alt-2"></i><span>Analytics</span></li></a>
            <!-- nav link edit -->
            <li id="link-edit" class="nav-link mb-3"><i class="bx bx-edit-alt"></i><span role="button" data-bs-toggle="collapse" data-bs-target="#submenu-edit" aria-expanded="true" aria-controls="submenu-edit">Edit data<i class='bx bx-chevron-down nav-drop'></i></span></li>
            <ul class="bx-ul collapse nav-submenu mb-3" id="submenu-edit">
                <li id="link-edit_profile" class="nav-list"><a href='/dashboard/edit/profile'>Profil</a></li>
                <li id="link-edit_education" class="nav-list"><a href='/dashboard/edit/education'>Pendidikan</a></li>
                <li id="link-edit_experience" class="nav-list"><a href='/dashboard/edit/experience'>Pengalaman</a></li>
                <li id="link-edit_skill" class="nav-list"><a href='/dashboard/edit/skill'>Keterampilan</a></li>
            </ul>
            <!-- nav link edit end -->
            <a href="/dashboard/edit/portfolio"><li id="link-edit_portfolio" class="nav-link mb-3"><i class="bx bx-file"></i><span>Portofolio</span></li></a>
            <a href="/dashboard/config"><li id="link-config" class="nav-link mb-3"><i class="bx bxs-cog"></i><span>Konfigurasi</span></li></a>
        </ul>
    </nav>
</div>
</header>
<!-- ======================================= sidebar end ================================================== -->

<section id="section-header-dashboard" class="px-2 py-3 shadow">
    <div id="container-header-dashboard" class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-primary d-flex align-items-center">
                <span id="toggle-sidebar" role="button" class="btn me-2"><i class='bx bx-menu'></i></span>
                <h1 class="fs-18 display-5 d-flex align-items-center mb-0"><?php if(isset($dashboard_header)): ?><?php echo $dashboard_header; ?><?php else: ?><i class="bx bxs-dashboard me-3"></i><span>Dashboard</span><?php endif; ?></h1>
            </div>
        </div>
    </div>
</section>

<main id="main">
<?php echo $__env->yieldContent('content'); ?> <!-- Contents here! -->
</main>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>


<script type="text/javascript">
// toggle sidebar
var sidebar_show = true;
var sidebar_width = $('#sidebar-dashboard').outerWidth();
$('#toggle-sidebar').click(function() {
    toggleSidebar(sidebar_show);
});
$('.mobile-nav-toggle').click(function() {
    toggleSidebar(sidebar_show);
});
$(window).resize(function() {
    if($(window).width() < 1199) {
        $('#sidebar-dashboard').css('left', sidebar_width*-1);
        $('#container-header-dashboard').css('padding-left', 0);
        $('#main').css('padding-left', 0);
        sidebar_show = false;
    } else {
        $('#sidebar-dashboard').css('left', 0);
        $('#container-header-dashboard').css('padding-left', sidebar_width);
        $('#main').css('padding-left', sidebar_width);
        sidebar_show = true;
    }
});
function toggleSidebar(show) {
    if(show == true) {
        $('#sidebar-dashboard').css('left', sidebar_width*-1);
        if($(window).width() > 1199) {
          $('#container-header-dashboard').animate({'padding-left': 0});
          $('#main').animate({'padding-left': 0});
        }
        sidebar_show = false;
    } else {
        $('#sidebar-dashboard').css('left', 0);
        if($(window).width() > 1199) {
          $('#container-header-dashboard').animate({'padding-left': sidebar_width});
          $('#main').animate({'padding-left': sidebar_width});
        }
        sidebar_show = true;
    }
};
$(document).ready(function(){
  if($(window).width() < 1199) {
      $('#sidebar-dashboard').removeClass('show');
      sidebar_show = false;
  } else {
      $('#sidebar-dashboard').removeClass('show').addClass('show');
      sidebar_show = true;
  }
  // tooltip
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
  })

  $('.popper').popover({ // require popper.js
      trigger: 'hover',
      html: true,
      placement: 'bottom',
      container: 'body'
  });
  <?php if(session('success')): ?>
    successMessage("<?php echo e(session('success')); ?>");
  <?php elseif(session('error')): ?>
    errorMessage("<?php echo e(session('error')); ?>");
  <?php endif; ?>
  <?php if(isset($_GET['success'])): ?>
    Swal.fire({
      icon: 'success',
      title: "<?php echo e($_GET['success']); ?>",
      showConfirmButton: false,
      timer: 3000
    });
  <?php endif; ?>
  <?php if(isset($_GET['info'])): ?>
    Swal.fire({
      icon: 'info',
      title: "<?php echo e($_GET['info']); ?>",
      showConfirmButton: false,
      timer: 3000
    });
  <?php endif; ?>
});

function successMessage(message) { toastr.success(message, 'Success!'); } 
function infoMessage(message) { toastr.info(message, 'Info'); } 
function warningMessage(message) { toastr.error(message, 'Warning!'); } 
function errorMessage(message) { toastr.error(message, 'Error!'); } 
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/layouts/master_dashboard.blade.php ENDPATH**/ ?>