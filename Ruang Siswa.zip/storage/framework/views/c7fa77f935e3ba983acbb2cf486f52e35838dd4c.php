

<?php $__env->startPush('css-styles'); ?>
<style>
.certif-item-add { min-height: 240px; }
.certif-item .card:hover { 
    cursor: pointer; 
    color: #fff;
    background-color: #0d6efd;
    transition: ease-in-out .3s;
} .certif-img { max-height: 240px; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content" class="bg-light">
    <div class="container">
        <!------------------------------- row start ------------------------->
        <div class="row mb-5">
            <!-- Form Dashboard work Start -->
            <div class="col-md-12 card bg-white p-4 shadow-sm">
                <div class="mb-4">
                    <h3 class="fw-bold ps-3 border-start border-primary border-5 mb-0">Riwayat pekerjaan</h3>
                </div>

                <!-- work history start -->
                <table id="table-visitor" class="table table-striped align-middle mb-3">
                    <thead>
                        <tr>
                            <th>Tahun</th>
                            <th>Tempat kerja</th>
                            <th>Peran</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $work_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($wh->year_start); ?><?php if($wh->year_end): ?> - <?php echo e($wh->year_end); ?><?php endif; ?></td>
                            <td><?php echo e($wh->work_place); ?></td>
                            <td><?php echo e($wh->role); ?></td>
                            <td class="d-flex flex-wrap">
                                <span class="btn btn-success btn-sm d-flex align-items-center btn-wh-edit" data-wh-id="<?php echo e($wh->id); ?>"><i class="bx bx-edit-alt me-1"></i>Edit</span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">Data tidak ditemukan</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <p class="mb-0 d-flex">
                    <span class="btn btn-primary btn-sm d-flex align-items-center btn-wh-add"><i class="bx bx-plus me-1"></i> Tambahkan</span>
                </p>
                <!-- work history end -->

            </div> <!-- col 12 end -->
            <!-- Form Dashboard work End -->
        </div>
        <!------------------------------- row end ------------------------->

        <!------------------------------- row start ------------------------->
        <div class="row mb-4">
            <!-- Form Dashboard Experience Start -->
            <div class="col-md-12 card bg-white p-4 shadow-sm">
                <div class="mb-4">
                    <h3 class="fw-bold ps-3 border-start border-primary border-5 mb-2">Pengalaman lainnya</h3>
                    <p class="mb-0 fs-11 text-secondary">Organisasi, pelatihan, pengisi acara, dan sebagainya</p>
                </div>

                <!-- Experience start -->
                <table id="table-visitor" class="table table-striped align-middle mb-3">
                    <thead>
                        <tr>
                            <th>Tahun</th>
                            <th>Judul</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($exp->year_start); ?><?php if($exp->year_end): ?> - <?php echo e($exp->year_end); ?><?php endif; ?></td>
                            <td><?php echo e($exp->title); ?></td>
                            <td class="d-flex flex-wrap">
                                <span class="btn btn-success btn-sm d-flex align-items-center btn-exp-edit" data-exp-id="<?php echo e($exp->id); ?>"><i class="bx bx-edit-alt me-1"></i>Edit</span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="text-center">Data tidak ditemukan</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <p class="mb-0 d-flex">
                    <span class="btn btn-primary btn-sm d-flex align-items-center btn-exp-add"><i class="bx bx-plus me-1"></i> Tambahkan</span>
                </p>
                <!-- Experience end -->

            </div> <!-- col 12 end -->
            <!-- Form Dashboard Experience End -->
        </div>
        <!------------------------------- row end ------------------------->

    </div>
</section>

<!-- Modal work Add -->
<div class="modal fade" id="modal-wh-add" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center"><i class='bx bx-plus me-2'></i><span>Tambahkan riwayat pekerjaan</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/dashboard/add/work_history" id="form-wh-add" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body fs-10">
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="add-year_start" placeholder="tahun bergabung" value="" required>
                        <label for="add-year_start" class="form-label">Tahun bergabung</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="add-year_end" placeholder="tahun berhenti" value="">
                        <label for="add-year_end" class="form-label">Tahun berhenti*</label>
                    </div>
                </div>
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <select name="add-month_start" class="form-control form-select form-select-sm" required>
                            <option value="january">Januari</option>
                            <option value="february">Februari</option>
                            <option value="march">Maret</option>
                            <option value="april">April</option>
                            <option value="may">Mei</option>
                            <option value="june">Juni</option>
                            <option value="july">Juli</option>
                            <option value="august">Agustus</option>
                            <option value="september">September</option>
                            <option value="october">Oktober</option>
                            <option value="november">November</option>
                            <option value="desember">Desember</option>
                        </select>
                        <label for="add-month_start" class="form-label">Bulan bergabung</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <select name="add-month_end" class="form-control form-select form-select-sm">
                            <option value="" selected disabled>Pilih bulan</option>
                            <option value="january">Januari</option>
                            <option value="february">Februari</option>
                            <option value="march">Maret</option>
                            <option value="april">April</option>
                            <option value="may">Mei</option>
                            <option value="june">Juni</option>
                            <option value="july">Juli</option>
                            <option value="august">Agustus</option>
                            <option value="september">September</option>
                            <option value="october">Oktober</option>
                            <option value="november">November</option>
                            <option value="desember">Desember</option>
                        </select>
                        <label for="add-month_end" class="form-label">Bulan berhenti*</label>
                    </div>
                </div>
                <p class="mb-3 fs-9 fst-italic text-secondary">*kosongkan bulan dan tahun berhenti apabila masih aktif</p>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control form-control-sm" name="add-work_place" placeholder="tempat kerja" value="" required>
                    <label for="add-work_place" class="form-label">Tempat kerja</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control form-control-sm" name="add-role" placeholder="peran" value="" required>
                    <label for="add-role" class="form-label">Peran</label>
                </div>
                <div class="form-floating mb-3">
                    <select name="add-employment" class="form-control form-select form-select-sm" required>
                        <option value="full time">Full time</option>
                        <option value="part time">Part time</option>
                        <option value="self employed">Self employed</option>
                        <option value="freelance">Freelance</option>
                        <option value="contract">Contract</option>
                        <option value="internship">Internship</option>
                        <option value="apprenticeship">Apprenticeship</option>
                        <option value="seasonal">Seasonal</option>
                    </select>
                    <label for="add-employment" class="form-label">Tipe pekerjaan</label>
                </div>
                <div class="mb-3">
                    <label for="add-description" class="form-label text-secondary">Deskripsi*</label>
                    <textarea name="add-description" class="form-control form-control-sm mb-2" placeholder="Deskripsi singkat"></textarea>
                    <span class="text-muted fst-italic fs-9">*gunakan simbol semicolon " ; " untuk membuat batas antar point</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-plus' ></i> Tambahkan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal work Add end -->

<!-- Modal work Edit -->
<div class="modal fade" id="modal-wh-edit" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center"><i class='bx bx-edit-alt me-2'></i><span>Edit data riwayat pekerjaan</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/dashboard/update/work_history" id="form-wh-edit" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="edit-wh_id" val="">
            <div class="modal-body fs-10">
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="edit-year_start" placeholder="tahun bergabung" value="" required>
                        <label for="edit-year_start" class="form-label">Tahun bergabung</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="edit-year_end" placeholder="tahun berhenti" value="">
                        <label for="edit-year_end" class="form-label">Tahun berhenti*</label>
                    </div>
                </div>
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <select name="edit-month_start" class="form-control form-select form-select-sm" required>
                            <option value="january">Januari</option>
                            <option value="february">Februari</option>
                            <option value="march">Maret</option>
                            <option value="april">April</option>
                            <option value="may">Mei</option>
                            <option value="june">Juni</option>
                            <option value="july">Juli</option>
                            <option value="august">Agustus</option>
                            <option value="september">September</option>
                            <option value="october">Oktober</option>
                            <option value="november">November</option>
                            <option value="desember">Desember</option>
                        </select>
                        <label for="edit-month_start" class="form-label">Bulan bergabung</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <select name="edit-month_end" class="form-control form-select form-select-sm">
                            <option id="edit-month_end-null" value="" selected disabled>Pilih bulan</option>
                            <option value="january">Januari</option>
                            <option value="february">Februari</option>
                            <option value="march">Maret</option>
                            <option value="april">April</option>
                            <option value="may">Mei</option>
                            <option value="june">Juni</option>
                            <option value="july">Juli</option>
                            <option value="august">Agustus</option>
                            <option value="september">September</option>
                            <option value="october">Oktober</option>
                            <option value="november">November</option>
                            <option value="desember">Desember</option>
                        </select>
                        <label for="edit-month_end" class="form-label">Bulan berhenti*</label>
                    </div>
                </div>
                <p class="mb-3 fs-9 fst-italic text-secondary">*kosongkan bulan dan tahun berhenti apabila masih aktif</p>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control form-control-sm" name="edit-work_place" placeholder="tempat kerja" value="" required>
                    <label for="edit-work_place" class="form-label">Tempat kerja</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control form-control-sm" name="edit-role" placeholder="peran" value="" required>
                    <label for="edit-role" class="form-label">Peran</label>
                </div>
                <div class="form-floating mb-3">
                    <select name="edit-employment" class="form-control form-select form-select-sm" required>
                        <option value="full time">Full time</option>
                        <option value="part time">Part time</option>
                        <option value="self employed">Self employed</option>
                        <option value="freelance">Freelance</option>
                        <option value="contract">Contract</option>
                        <option value="internship">Internship</option>
                        <option value="apprenticeship">Apprenticeship</option>
                        <option value="seasonal">Seasonal</option>
                    </select>
                    <label for="edit-employment" class="form-label">Tipe pekerjaan</label>
                </div>
                <div class="mb-3">
                    <label for="edit-description" class="form-label text-secondary">Deskripsi*</label>
                    <textarea name="edit-description" class="form-control form-control-sm mb-2" placeholder="Deskripsi singkat"></textarea>
                    <span class="text-muted fst-italic fs-9">*gunakan simbol semicolon " ; " untuk membuat batas antar point</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <a href="/dashboard/delete" class="btn btn-danger btn-warn-delete btn-sm mr-4 btn-delete-wh"><i class='bx bx-trash-alt'></i> Hapus</a>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-edit-alt' ></i> Update</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal work edit end -->

<!-- Modal experience Add -->
<div class="modal fade" id="modal-exp-add" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center"><i class='bx bx-plus me-2'></i><span>Tambahkan pengalaman</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/dashboard/add/experience" id="form-exp-add" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body fs-10">
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="add-exp-year_start" placeholder="tahun mulai" value="" required>
                        <label for="add-exp-year_start" class="form-label">Tahun mulai</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="add-exp-year_end" placeholder="tahun selesai" value="">
                        <label for="add-exp-year_end" class="form-label">Tahun selesai*</label>
                    </div>
                </div>
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <select name="add-exp-month_start" class="form-control form-select form-select-sm" required>
                            <option value="january">Januari</option>
                            <option value="february">Februari</option>
                            <option value="march">Maret</option>
                            <option value="april">April</option>
                            <option value="may">Mei</option>
                            <option value="june">Juni</option>
                            <option value="july">Juli</option>
                            <option value="august">Agustus</option>
                            <option value="september">September</option>
                            <option value="october">Oktober</option>
                            <option value="november">November</option>
                            <option value="desember">Desember</option>
                        </select>
                        <label for="add-exp-month_start" class="form-label">Bulan mulai</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <select name="add-exp-month_end" class="form-control form-select form-select-sm">
                            <option value="" selected disabled>Pilih bulan</option>
                            <option value="january">Januari</option>
                            <option value="february">Februari</option>
                            <option value="march">Maret</option>
                            <option value="april">April</option>
                            <option value="may">Mei</option>
                            <option value="june">Juni</option>
                            <option value="july">Juli</option>
                            <option value="august">Agustus</option>
                            <option value="september">September</option>
                            <option value="october">Oktober</option>
                            <option value="november">November</option>
                            <option value="desember">Desember</option>
                        </select>
                        <label for="add-exp-month_end" class="form-label">Bulan selesai*</label>
                    </div>
                </div>
                <p class="mb-3 fs-9 fst-italic text-secondary">*kosongkan bulan dan tahun selesai apabila masih aktif</p>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control form-control-sm" name="add-exp-title" placeholder="judul" value="" required>
                    <label for="add-exp-title" class="form-label">Judul</label>
                </div>
                <div class="mb-3">
                    <label for="add-exp-description" class="form-label text-secondary">Deskripsi*</label>
                    <textarea name="add-exp-description" class="form-control form-control-sm mb-2" placeholder="Deskripsi singkat"></textarea>
                    <span class="text-muted fst-italic fs-9">*gunakan simbol semicolon " ; " untuk membuat batas antar point</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-plus' ></i> Tambahkan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal exp Add end -->
<!-- Modal experience edit -->
<div class="modal fade" id="modal-exp-edit" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center"><i class='bx bx-edit-alt me-2'></i><span>Edit data pengalaman</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/dashboard/update/experience" id="form-exp-edit" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="edit-exp_id" val="">
            <div class="modal-body fs-10">
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="edit-exp-year_start" placeholder="tahun mulai" value="" required>
                        <label for="edit-exp-year_start" class="form-label">Tahun mulai</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <input type="number" class="form-control form-control-sm" name="edit-exp-year_end" placeholder="tahun selesai" value="">
                        <label for="edit-exp-year_end" class="form-label">Tahun selesai*</label>
                    </div>
                </div>
                <div class="mb-3 d-flex flex-md-remove">
                    <div class="form-floating col">
                        <select name="edit-exp-month_start" class="form-control form-select form-select-sm" required>
                            <option value="january">Januari</option>
                            <option value="february">Februari</option>
                            <option value="march">Maret</option>
                            <option value="april">April</option>
                            <option value="may">Mei</option>
                            <option value="june">Juni</option>
                            <option value="july">Juli</option>
                            <option value="august">Agustus</option>
                            <option value="september">September</option>
                            <option value="october">Oktober</option>
                            <option value="november">November</option>
                            <option value="desember">Desember</option>
                        </select>
                        <label for="edit-exp-month_start" class="form-label">Bulan mulai</label>
                    </div>
                    &ensp;
                    <div class="form-floating col">
                        <select name="edit-exp-month_end" class="form-control form-select form-select-sm">
                            <option value="" selected>Pilih bulan</option>
                            <option value="january">Januari</option>
                            <option value="february">Februari</option>
                            <option value="march">Maret</option>
                            <option value="april">April</option>
                            <option value="may">Mei</option>
                            <option value="june">Juni</option>
                            <option value="july">Juli</option>
                            <option value="august">Agustus</option>
                            <option value="september">September</option>
                            <option value="october">Oktober</option>
                            <option value="november">November</option>
                            <option value="desember">Desember</option>
                        </select>
                        <label for="edit-exp-month_end" class="form-label">Bulan selesai*</label>
                    </div>
                </div>
                <p class="mb-3 fs-9 fst-italic text-secondary">*kosongkan bulan dan tahun selesai apabila masih aktif</p>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control form-control-sm" name="edit-exp-title" placeholder="judul" value="" required>
                    <label for="edit-exp-title" class="form-label">Judul</label>
                </div>
                <div class="mb-3">
                    <label for="edit-exp-description" class="form-label text-secondary">Deskripsi*</label>
                    <textarea name="edit-exp-description" class="form-control form-control-sm mb-2" placeholder="Deskripsi singkat"></textarea>
                    <span class="text-muted fst-italic fs-9">*gunakan simbol semicolon " ; " untuk membuat batas antar point</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <a href="/dashboard/delete" class="btn btn-danger btn-warn-delete btn-sm mr-4 btn-delete-exp"><i class='bx bx-trash-alt'></i> Hapus</a>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-edit-alt' ></i> Update</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal exp edit end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

/* ------------------------------------------- Work history start ------------------------------------------- */
$('.btn-wh-add').click(function(){ $('#modal-wh-add').modal('show'); });
$('.btn-wh-edit').click(function(){
    var wh_id = $(this).attr('data-wh-id');
    var formData = { 
        action: 'edit_work_history', wh_id: wh_id,
    };
    $.ajax({
        type: "POST",
        url: "/ajax/dashboard",
        data: formData,
        dataType: 'JSON',
        success: function (data) {
            $('.btn-delete-wh').attr('href', '/dashboard/delete/work_history/'+wh_id);
            $('[name="edit-wh_id"]').val(wh_id);
            $('[name="edit-year_start"]').val(data.work_history.year_start);
            $('[name="edit-year_end"]').val(data.work_history.year_end);
            $('[name="edit-month_start"] option[value="'+data.work_history.month_start+'"]').prop('selected', true);
            if(data.work_history.month_end != null) {
                $('[name="edit-month_end"] option[value="'+data.work_history.month_end+'"]').prop('selected', true);
            } else {
                $('[name="edit-month_end"] #edit-month_end-null').prop('selected', true);
            }
            $('[name="edit-work_place"]').val(data.work_history.work_place);
            $('[name="edit-role"]').val(data.work_history.role);
            $('[name="edit-employment"] option[value="'+data.work_history.employment+'"]').prop('selected', true);
            $('[name="edit-description"]').val(data.work_history.description);
            $('#modal-wh-edit').modal('show');
        }, error:function(data) {
            errorMessage('Terdapat kesalahan');
        },
    });
});
/* ------------------------------------------- Work history end ------------------------------------------- */

/* ------------------------------------------- Experience start ------------------------------------------- */
$('.btn-exp-add').click(function(){ $('#modal-exp-add').modal('show'); });
$('.btn-exp-edit').click(function(){
    var exp_id = $(this).attr('data-exp-id');
    var formData = { 
        action: 'edit_experience', exp_id: exp_id,
    };
    $.ajax({
        type: "POST",
        url: "/ajax/dashboard",
        data: formData,
        dataType: 'JSON',
        success: function (data) {
            $('.btn-delete-exp').attr('href', '/dashboard/delete/experience/'+exp_id);
            $('[name="edit-exp_id"]').val(exp_id);
            $('[name="edit-exp-year_start"]').val(data.experience.year_start);
            $('[name="edit-exp-year_end"]').val(data.experience.year_end);
            $('[name="edit-exp-month_start"] option[value="'+data.experience.month_start+'"]').prop('selected', true);
            if(data.experience.month_end != null) {
                $('[name="edit-exp-month_end"] option[value="'+data.experience.month_end+'"]').prop('selected', true);
            } else {
                $('[name="edit-exp-month_end"] #edit-exp-month_end-null').prop('selected', true);
            }
            $('[name="edit-exp-title"]').val(data.experience.title);
            $('[name="edit-exp-description"]').val(data.experience.description);
            $('#modal-exp-edit').modal('show');
        }, error:function(data) {
            errorMessage('Terdapat kesalahan');
        },
    });
});
/* ------------------------------------------- Experience end ------------------------------------------- */

$(document).ready(function(){ 
    $('.nav-link').removeClass('active'); $('#link-edit').addClass('active'); $('#link-edit_experience').addClass('active'); $('#submenu-edit').addClass('show'); // nav-link active
    
    // certificate item height
    var maxHeight = Math.max.apply(null, $("div.certif-card").map(function () {
        return $(this).height();
    }).get());
    $('.certif-card').css('height', maxHeight);
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/dashboard/edit_experience.blade.php ENDPATH**/ ?>