

<?php $__env->startPush('css-styles'); ?>
<style>
@media (max-width: 1199px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-intro -->
<section id="section-intro" class="vh-100" style="background: #f8e9a1;">
    <div class="container h-100">
        <div class="row h-100 align-items-center justify-content-center mb-4">
            <div class="col-md-10 d-flex flex-remove-md align-items-center px-4">
                <div class="col mb-3">
                    <img class="img-fluid" src="<?php echo e(asset('/img/materials/gif-dekstop.gif')); ?>" style="max-height: 480px"/>
                </div>
                <div class="col mb-3" style="color:#374785;">
                    <h1 class="fw-bold" style="font-size:36pt; lettter-spacing:2em">cvkreatif.com</h1>
                    <hr>
                    <p class="fs-14">Make your own personal portfolio website only in a few steps <b>for free!</b></p>
                    <button class="btn btn-outline-primary w-100 mb-2" onclick="modal_login_show()">Sign in</button>
                    <a href="/auth/google" class="btn btn-danger d-flex align-items-center justify-content-center mb-3 fs-10"><i class='bx bx-xs bxl-google-plus me-2'></i><span>Sign in with Google</span></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- section-intro end -->

<?php if(auth()->guard()->guest()): ?>
<?php echo $__env->make('layouts/partials/modal_auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
$(document).ready(function(){
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif 2.0\cvkreatif.com\resources\views/index.blade.php ENDPATH**/ ?>