

<?php $__env->startPush('css-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<style>
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark, .icon-dark { color: #124265; } .title-light, .icon-light { color: #f1f1f1; }

.card:hover { box-shadow: 2px 2px 10px #333; }

@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-news -->
<section id="section-news" class="ptb-40">
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-md-10 mb-5 text-center">
                <h1 class="section-title title-dark mb-4"><?php echo e($news['title']); ?></h1>
                <?php if($news['keywords'][0] != null): ?>
                <p class="d-flex flex-wrap justify-content-center mb-5">
                    <?php $__empty_1 = true; $__currentLoopData = $news['keywords']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a class="btn btn-outline-secondary btn-sm mr-8" href="/news?key=<?php echo e(ltrim($key)); ?>"><?php echo e(ltrim($key)); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </p>
                <?php endif; ?>
                <a href="<?php echo e(asset('img/news/'.$news['image'])); ?>" class="glightbox">
                    <img src="<?php echo e(asset('img/news/'.$news['image'])); ?>" alt="">
                </a>
            </div>
            <div class="col-md-10">
                <p class="mb-3">
                    <span class="text-muted"><?php echo e($news['created_at']); ?></span> | <a href="#"><?php echo e($news['author']); ?></a>
                </p>
                <?php echo $news['content']; ?>

                <?php if(Auth::user()->role != 'user'): ?>
                <p class="mt-3 font-10">Last updated by : <?php echo e($news['user_email']); ?></p>
                <?php endif; ?>
                <?php if(Auth::user()->role != 'user'): ?>
                <hr class="mt-4 mb-4">
                <p class="d-flex justify-content-end">
                    <a class="btn btn-danger btn-warn mr-8" href="/news/delete/<?php echo e($news['news_id']); ?>"><i class="bx bx-trash-alt"></i> Delete</a>
                    <a class="btn btn-success" href="/news/edit/<?php echo e($news['news_id']); ?>"><i class="bx bx-edit-alt"></i> Edit</a>
                </p>
                <?php endif; ?>
            </div>
        </div> <!-- row end -->

        <!-- other_news -->
        <div class="row justify-content-center">
            <?php $i = 0; ?>
            <?php $__empty_1 = true; $__currentLoopData = $other_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="news-item col-md-3 mb-3"> <!-- news-item -->
                <a href="/news/show/<?php echo e($item->id); ?>">
                    <div class="card">
                        <?php if($item->image != null): ?>
                        <img src="<?php echo e(asset('img/news/'.$item->image)); ?>" alt="">
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/news/default.jpg')); ?>" alt="">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item->title); ?></h5>
                            <p class="font-10 mb-1"><span class="text-muted fst-italic"><?php echo e(date('l, d F Y', strtotime($item->created_at))); ?></span> | <?php echo e($item->author); ?></p>
                        </div>
                    </div>
                </a>
            </div> <!-- news-item end -->
            <?php $i++ ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div> <!-- row end -->
        <!-- other_news end -->

    </div>
</section>
<!-- section-news end -->

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/cropper/cropper.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script type="text/javascript">
const lightbox = GLightbox({
    touchNavigation: true,
    loop: true,
    autoplayVideos: true
});
$(document).ready(function(){
    $('.nav-link').removeClass('active');
    $('.nav-link-news').addClass('active');
});
</script>
<script src="<?php echo e(asset('/js/ajax_news.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/news/show.blade.php ENDPATH**/ ?>