

<?php $__env->startPush('css-styles'); ?>
<script src="https://cdn.tiny.cloud/1/azk02t135qrzd1zf1kmlzrv6alvdkzlaq3q0kn01d0ce8mu9/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script> <!-- Tiny MCE -->
<link href="<?php echo e(asset('/vendor/cropper/cropper.min.css')); ?>" rel="stylesheet">
<style>
#form-portfolio { display: none }
.item-portfolio-add { min-height: 240px; }
.item-portfolio .card:hover { 
    cursor: pointer; 
    color: #fff;
    background-color: #0d6efd;
    transition: ease-in-out .3s;
} .item-portfolio img { max-height: 320px; }

.card-img-overlay { opacity: 0; color: #fff; }
.card-img-overlay:hover { background: rgba(0, 0, 0, 0.5); opacity: 1; transition: ease-in-out .4s; }

/* ------------------------------- isotope start ------------------------------- */
.container-filter {
  margin-top: 0;
  margin-right: 0;
  margin-left: 0;
  margin-bottom: 30px;
  padding: 0;
  text-align: center;
}

.container-filter li {
  list-style: none;
  display: inline-block;
}

.container-filter a {
  display: block;
  cursor: pointer;
  -webkit-transition: all 0.6s;
  border-bottom: 1px solid transparent;
  color: #807c7c !important;
}

.container-filter a.active {
  color: #222222 !important;
  border-bottom: 1px solid #222222;
}
/* ------------------------------- isotope end ------------------------------- */
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content" class="bg-light">
    <div class="container">

        <!------------------------------- row start ------------------------->
        <form id="form-portfolio" action="/portfolio/add" class="m-0" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="add_portfolio">
        <input type="hidden" name="portfolio-id" value="">
        <div id="row-form-portfolio" class="row mb-4 border bg-white p-4 shadow-sm">
            <div class="col-md-12 d-flex justify-content-between align-items-center mb-4">
                <h3 id="form-title" class="fw-bold ps-3 border-start border-primary border-5 m-0">Tambahkan Portofolio Baru</h3>
            </div>
            <div class="col-md-12 d-flex flex-remove-md align-items-center mb-4">
                <div class="col">
                    <div class="card mb-3">
                        <img id="portfolio-image-preview" src="<?php echo e(asset('/img/materials/noimage.jpg')); ?>" class="card-img"/>
                        <div class="card-img-overlay d-flex">
                            <div class="m-auto text-light text-center">
                                <p class="mb-0 text-white">Gambar sampul portofolio</p>
                            </div>
                        </div>
                    </div>
                    <input type="file" name="portfolio-image" class="form-control form-control-sm">
                    <input type="hidden" name="portfolio-image-base64">
                </div>
                &ensp;&ensp;
                <div class="col">
                    <div class="form-floating mb-3">
                        <input type="text" name="portfolio-title" class="form-control form-control-sm" placeholder="Judul" required>
                        <label for="portfolio-title" class="form-label">Judul</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="portfolio-url" class="form-control form-control-sm mb-1" placeholder="Link eksternal">
                        <label for="portfolio-url" class="form-label">Link eksternal</label>
                        <p class="mb-0 text-muted fst-italic fs-10">*opsional, tambahkan link menuju portofolio kamu seperti Google Drive, Github, dan sebagainya</p>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="portfolio-category" class="form-control form-control-sm" placeholder="Kategori">
                        <label for="portfolio-category" class="form-label">Kategori</label>
                    </div>
                    <p class="fs-11 mb-2">Kategori portofolio yang pernah kamu buat :</p>
                    <div class="d-flex flex-wrap align-items-center mb-3">
                        <?php if(count($portfolio_categories) > 0): ?>
                        <?php $__currentLoopData = $portfolio_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="btn-category-select btn btn-secondary btn-sm fs-10 me-2 mb-2"><?php echo e($item->category); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <hr class="col"><span class="fs-11 text-muted mx-2">Belum ada kategori</span><hr class="col">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="mb-3">
                    <textarea id="portfolio-description" name="portfolio-description" class="form-control" placeholder="Berikan deskripsi singkat tentang portofoliomu" style="min-height:480px"></textarea>
                </div>
                <!-- only show on edit mode -->
                <div id="container-portfolio-images" class="mt-4 d-none">
                    <h5 class="fw-bold mb-3">Galeri portofolio</h5>
                    <div class="d-flex flex-wrap mb-3">
                        <div id="thumbnail-portfolio-gallery" class="d-flex flex-wrap"></div>
                        <label for="portfolio-gallery" class="prevent-select">
                        <div class="item-portfolio me-3 mb-3 bg-light text-primary">
                            <div class="item-portfolio-add portfolio-card card px-5 rounded shadow-sm">
                                <div class="my-auto">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                    <span class="fs-14 fw-bold">Tambahkan</span>
                                </div>
                            </div>
                        </div>
                        </label>
                    </div>
                </div>
                <!-- only show on edit mode -->
                <div class="d-flex justify-content-end">
                    <a href="/portfolio/delete" class="btn-warn d-none btn-portfolio-delete btn btn-danger btn-sm d-flex align-items-center justify-content-center me-2"><i class="bx bx-trash-alt me-2"></i> Hapus</a>
                    <button id="btn-submit-form-portfolio" type="submit" class="btn btn-success d-flex align-items-center"><i class="bx bx-send me-2"></i>Submit</button>
                </div>
            </div>
        </div>
        <!------------------------------- row end ------------------------->
        </form>

        <!------------------------------- row start ------------------------->
        <div class="row mb-4 card bg-white p-4 shadow-sm">
            <div class="col-md-12">
                <div class="mb-4 d-flex justify-content-between align-items-center">
                    <h3 class="fw-bold ps-3 border-start border-primary border-5 mb-0">Portofolio</h3>
                    <button class="btn-portfolio-add d-flex align-items-center btn btn-sm btn-primary"><i class="bx bx-plus me-1"></i>Tambahkan</button>
                </div>
                <!-- filter start -->
                <?php if(count($portfolios) > 0): ?>
                <div class="col-md-12 mb-4">
                    <div class="text-center">
                        <ul class="col container-filter list-unstyled fs-12 mb-0" id="filter-portfolio">
                            <li><a class="categories mx-3 active" data-filter="*">All</a></li>
                            <?php $__currentLoopData = $portfolio_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $trim = str_replace(' ', '_', $item->category); ?>
                            <li><a class="categories mx-3" data-filter=".<?php echo e(strtolower($trim)); ?>"><?php echo e($item->category); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <!-- filter end -->
                <div class="col-md-12">
                    <div class="container-portfolio row">
                        <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $trim = str_replace(' ', '_', $portfolio->category); ?>
                        <!-- item start -->
                        <div class="col-md-6 item-portfolio <?php echo e(strtolower($trim)); ?> mb-3">
                            <div class="card">
                                <img src="<?php echo e(asset('img/portfolios/'.$portfolio->image)); ?>" class="card-img"/>
                                <div class="card-img-overlay d-flex">
                                    <div class="m-auto text-light text-center">
                                        <p class="fs-14 fw-bold"><?php echo e($portfolio->title); ?></p>
                                        <p class="mb-2"><button class="btn-portfolio-edit form-control btn btn-outline-light btn-sm d-flex align-items-center justify-content-center" data-id="<?php echo e($portfolio->id); ?>"><i class="bx bx-edit-alt me-2"></i> Edit</button></p>
                                        <p><a href="/portfolio/delete/<?php echo e($portfolio->id); ?>" class="btn-warn btn btn-danger btn-sm d-flex align-items-center justify-content-center" data-id="<?php echo e($portfolio->id); ?>"><i class="bx bx-trash-alt me-2"></i> Hapus</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- item end -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
                <!-- item container start -->
                <div class="container-portfolio d-flex flex-wrap mb-2">
                    <?php if(count($portfolios) == 0): ?>
                    <div class="item-portfolio card me-3">
                        <img src="<?php echo e(asset('/img/materials/noimage.jpg')); ?>" class="card-img"/>
                        <div class="card-img-overlay d-flex">
                            <a href="#row-form-portfolio" class="btn-portfolio-add m-auto text-light">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                <span class="fs-14 fw-bold">Tambahkan</span>
                            </a>
                        </div>
                    </div>
                    <?php else: ?>
                    <?php endif; ?>
                </div>
                <!-- item container end -->
            </div>
        </div>
        <!------------------------------- row end ------------------------->
        
    </div>
</section>

<!-- modal image cropper -->
<div class="modal fade" id="modal-portfolio-image-cropper" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center"><i class='bx bx-crop me-2'></i> Gambar sampul portofolio</h4>
                <button type="button" class="btn-close modal-portfolio-cancel" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8">
                        <img id="portfolio-image-crop" src="">
                    </div>
                    <div class="col-md-4">
                        <div id="portfolio-image-crop-preview" class="mx-auto mb-3" style="height:120px;overflow:hidden;"></div>
                        <p class="fs-10 text-muted fst-italic px-2">*Pilih area gambar dengan dimensi 9:16</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batalkan</button>
                <button type="button" class="btn btn-primary" id="btn-portfolio-image-crop">Pilih</button>
            </div>
        </div>
    </div>
</div>
<!-- modal image cropper end -->

<!-- modal portfolio gallery start -->
<div class="modal fade" id="modal-portfolio-gallery" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 id="title-modal-portfolio-gallery" class="modal-title d-flex align-items-center"><i class='bx bxs-file-plus me-2'></i> Upload Gambar Galeri Portofolio</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/upload/portfolio_gallery" id="form-portfolio-gallery" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <div class="col mb-3">
                    <img src="" id="preview-portfolio-gallery" class="img-fluid">
                </div>
                <hr/>
                <input id="portfolio-gallery" class="absolute w-full h-full d-none" name="portfolio-gallery" accept="image/png, image/jpeg, image/jpg" type="file">
                <div class="form-floating mb-3">
                    <input type="text" name="caption" class="form-control form-control-sm" placeholder="Caption" value="">
                    <label for="caption" class="form-label">Caption</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back me-1'></i>Batalkan</button>
                <button type="submit" id="submit-portfolio-gallery" class="btn btn-sm btn-primary"><i class='bx bxs-file-plus me-1'></i>Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- modal portfolio gallery end -->

<!-- modal portfolio gallery edit start -->
<div class="modal fade" id="modal-gallery-edit" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center"><i class='bx bx-edit-alt me-2'></i> Edit Gambar Galeri Portofolio</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/update/portfolio_gallery" id="form-gallery-edit" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="gallery-id">
            <input type="hidden" name="gallery-portfolio-id">
            <div class="modal-body">
                <div class="col mb-3">
                    <img src="" id="preview-gallery-edit" class="img-fluid">
                </div>
                <hr/>
                <div class="form-floating mb-3">
                    <input type="text" name="caption-edit" class="form-control form-control-sm" placeholder="Caption" value="">
                    <label for="caption-edit" class="form-label">Caption</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back me-1'></i>Batalkan</button>
                <button type="button" id="delete-gallery-edit" class="btn btn-sm btn-danger"><i class='bx bx-trash-alt me-1'></i>Hapus</button>
                <button type="submit" id="submit-gallery-edit" class="btn btn-sm btn-primary"><i class='bx bx-edit-alt me-1'></i>Update</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- modal portfolio gallery edit end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/isotope-layout/masonry.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/cropper/cropper.min.js')); ?>"></script>
<script>
$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });

/* -------------------- isotope start -------------------- */
$(window).on('load', function() {
    var $portfolio_container = $('.container-portfolio');
    var $portfolio_filter = $('#filter-portfolio');
    $portfolio_container.isotope({
        filter: '*',
        layoutMode: 'masonry',
        animationOptions: {
            duration: 750,
            easing: 'linear'
        }
    });
    $portfolio_filter.find('a').click(function() {
        let selector = $(this).attr('data-filter');
        $portfolio_filter.find('a').removeClass('active');
        $(this).addClass('active');
        $portfolio_container.isotope({
            filter: selector,
            animationOptions: {
                animationDuration: 750,
                easing: 'linear',
                queue: false,
            }
        });
        return false;
    });
});
/* -------------------- isotope end -------------------- */

/* ================================== form portfolio start ================================== */
var image_url = "http://localhost:8000/img/";
// var image_url = "https://cvkreatif.com/img/";

/* -------- form portfolio add start -------- */
$('.btn-portfolio-add').click(function(e) { /* ---------- show form for adding portfolio ---------- */
    $('#form-portfolio').hide();
    clearForm();
    $('#container-portfolio-images').addClass('d-none');
    $('.btn-portfolio-delete').addClass('d-none');
    $('#portfolio-image-preview').attr('src', image_url + 'materials/noimage.jpg');
    tinymce.get("portfolio-description").setContent('');
    $('#form-title').html('Tambahkan Portfolio Baru');
    $('#btn-submit-form-portfolio').html('<i class="bx bx-send me-2"></i>Submit');
    $('#form-portfolio').attr('action','/portfolio/add').slideDown('slow');
});
/* -------- form portfolio add end -------- */

/* -------- form portfolio edit start -------- */
$('.btn-portfolio-edit').click(function(e) { /* ---------- show form for editing portfolio ---------- */
    $('#form-portfolio').hide();
    clearForm();
    var portfolio_id = $(this).attr('data-id');
    var formData = {
        'action': 'get_portfolio', 'portfolio_id': portfolio_id
    }
    $.ajax({
        type: "POST",
        url: "/ajax/portfolio",
        data: formData,
        dataType: 'JSON',
        success: function(response) {
            $('#form-title').html('Edit Portfolio');
            $('#container-portfolio-images').removeClass('d-none');
            $('.btn-portfolio-delete').removeClass('d-none').attr('href', '/portfolio/delete/' + response.portfolio.id);

            $('[name="portfolio-id"]').val(response.portfolio.id);
            $('#portfolio-image-preview').attr('src', image_url + 'portfolios/' + response.portfolio.image);
            $('[name="portfolio-title"]').val(response.portfolio.title);
            $('[name="portfolio-url"]').val(response.portfolio.url);
            $('[name="portfolio-category"]').val(response.portfolio.category);
            if(response.portfolio.description) {
                tinymce.get("portfolio-description").setContent(response.portfolio.description);
            } else {
                tinymce.get("portfolio-description").setContent('');
            }
            $('#btn-submit-form-portfolio').html('<i class="bx bx-edit-alt me-2"></i>Update');
            $('#form-portfolio').attr('action','/portfolio/update');
            get_portfolio_gallery(response.portfolio.id);
        }, error: function(response) {
            errorMessage('Terdapat kesalahan');
        }, complete: function(response) {
            $('#form-portfolio').slideDown('slow');
        }
    });
});
/* -------- form portfolio edit end -------- */

$("[name='portfolio-image']").change(function(e) { /* ---------- image cropper for portfolio cover ---------- */
    var modal = $('#modal-portfolio-image-cropper');
    var image = document.getElementById('portfolio-image-crop');
    var cropper; modal.modal('show');

    let reader = new FileReader();
    reader.onload = (e) => { 
        $('#portfolio-image-crop').attr('src', e.target.result); 
    }
    reader.readAsDataURL(this.files[0]); 
    let get_file = $(this).val();
    
    modal.on('shown.bs.modal', function () {
        cropper = new Cropper(image, {
            aspectRatio: 16/9, viewMode: 3, preview: '#portfolio-image-crop-preview',
        });
    }).on('hidden.bs.modal', function () {
        cropper.destroy();
        cropper = null;
    });
    
    $("#btn-portfolio-image-crop").click(function(){ /* ---------- crop cover image start ---------- */
        var canvas = cropper.getCroppedCanvas({
            width: 640,
            height: 360,
            // width: 1280,
            // height: 720,
        });
        canvas.toBlob(function(blob) {
            url = URL.createObjectURL(blob);
            var reader = new FileReader();
            reader.readAsDataURL(blob); 
            reader.onloadend = function() {
                var base64data = reader.result; 
                $('#portfolio-image-preview').attr('src', reader.result);
                $('#modal-portfolio-image-cropper').modal('hide');
                $('[name="portfolio-image-base64"]').val(reader.result);
            }
        });
    }); /* ---------- crop cover image end ---------- */
});
$('.btn-category-select').click(function(e){ /* ---------- select category ---------- */
    e.preventDefault();
    let category = $(this).html();
    $('[name="portfolio-category"]').val(category);
});
const clearForm = () => { /* ---------- clear form ---------- */
    $('#form-portfolio').trigger('reset');
}

/* -------- form portfolio gallery start -------- */
$('[name="portfolio-gallery"]').change(function(e){ /* ---------- input image portfolio gallery ---------- */
    let modal = $('#modal-portfolio-gallery');
    let reader = new FileReader();
    reader.onload = (e) => { 
        $('#preview-portfolio-gallery').attr('src', e.target.result); 
    }
    reader.readAsDataURL(this.files[0]); 
    let file = $(this)[0].files[0];
    $("[name='caption']").val(file.name);
    modal.modal('show');
});
$('#form-portfolio-gallery').submit(function(e){ /* ---------- upload portfolio gallery ---------- */
    e.preventDefault();
    var formData = new FormData(this);
    let portfolio_id = $('[name="portfolio-id"]').val();
    formData.append('action', 'add_portfolio_gallery');
    formData.append('portfolio_id', portfolio_id);
    $.ajax({
        type: "POST",
        url: "/ajax/portfolio",
        data: formData,
        cache:false,
        contentType: false,
        processData: false,
        success: function(response) {
            if(response.error == true) {
                errorMessage(response.message);
            } else {
                successMessage(response.message);
                $('#modal-portfolio-gallery').modal('hide');
                $('#form-portfolio-gallery').trigger('reset');
                get_portfolio_gallery(portfolio_id);
            }
        }, error: function(response) {
            errorMessage('Terdapat kesalahan');
            return false;
        }, complete: function(response) {
            //
        }
    });
});
$('#delete-gallery-edit').click(function(e){ /* ---------- confirmation delete portfolio gallery ---------- */
    e.preventDefault();
    let item_id = $('[name="gallery-id"]').val();
    let portfolio_id = $('[name="gallery-portfolio-id"]').val();
    Swal.fire({
        title: 'Apakah anda yakin?',
        icon: 'info',
        showCancelButton: true,
        cancelButtonColor: '#666',
        cancelButtonText: 'Batalkan',
        confirmButtonColor: '#0d6efd',
        confirmButtonText: "Lanjutkan"
        }).then((result) => {
        if(result.isConfirmed) {
            delete_portfolio_gallery(item_id);
        }
    });
});
$('#form-gallery-edit').submit(function(e){ /* ---------- update portfolio gallery ---------- */
    e.preventDefault();
    var formData = new FormData(this);
    let portfolio_id = $('[name="gallery-portfolio-id"]').val();
    let gallery_id = $('[name="gallery-id"]').val();
    formData.append('action', 'update_portfolio_gallery');
    $.ajax({
        type: "POST",
        url: "/ajax/portfolio",
        data: formData,
        cache:false,
        contentType: false,
        processData: false,
        success: function(response) {
            if(response.error == true) {
                errorMessage(response.message);
            } else {
                successMessage(response.message);
                $('#modal-gallery-edit').modal('hide');
                $('#form-gallery-edit').trigger('reset');
                get_portfolio_gallery(portfolio_id);
            }
        }, error: function(response) {
            errorMessage('Terdapat kesalahan');
            return false;
        },
    });
});
const get_portfolio_gallery = (portfolio_id) => { /* ---------- refresh portfolio gallery ---------- */
    $.ajax({
        type: "POST",
        url: "/ajax/portfolio",
        data: { action: 'get_portfolio_gallery', portfolio_id: portfolio_id},
        dataType: 'JSON',
        success: function(response) {
            $('#thumbnail-portfolio-gallery').html('');
            if(response.gallery.length > 0) {
                response.gallery.forEach(display_portfolio_gallery);
                function display_portfolio_gallery(item, index) {
                    $('#thumbnail-portfolio-gallery').append(
                        '<div class="card me-3 mb-3"><a href="" data-id="'+ item.id +'" data-portfolio-id="'+ portfolio_id +'" data-caption="'+ item.caption +'" class="item-portfolio-gallery"><img src="'+ image_url + 'portfolios/'+ portfolio_id + '/'+ item.image +'" class="card-img" style="max-height:240px;"/><div class="card-img-overlay d-flex"><div class="m-auto text-light text-center"><p>'+ item.caption +'</p></div></div></a></div>'
                    );
                }
            }
        }, complete: function(response) {
            $('.item-portfolio-gallery').click(function(e){ /* ---------- edit portfolio gallery image ---------- */
                e.preventDefault();
                let portfolio_id = $(this).attr('data-portfolio-id');
                let item_id = $(this).attr('data-id');
                let item_caption = $(this).attr('data-caption');
                let item_src = $(this).children('img').attr('src');
                $('[name="gallery-id"]').val(item_id);
                $('[name="gallery-portfolio-id"]').val(portfolio_id);
                $('#preview-gallery-edit').attr('src', item_src);
                $('[name="caption-edit"]').val(item_caption);
                $('#modal-gallery-edit').modal('show');
            });
        }
    });
}
const delete_portfolio_gallery = (item_id) => { /* ---------- delete portfolio gallery ---------- */
    $.ajax({
        type: "POST",
        url: "/ajax/portfolio",
        data: { action: 'delete_portfolio_gallery', item_id: item_id},
        dataType: 'JSON',
        success: function(response) {
            if(response.error == true) {
                errorMessage(response.message);
            } else {
                successMessage(response.message);
                $('#modal-gallery-edit').modal('hide');
                $('#form-gallery-edit').trigger('reset');
                get_portfolio_gallery(response.portfolio_id);
            }
        }, error: function(response) {
            errorMessage('Terdapat kesalahan');
            return false;
        },
    });
}
/* -------- form portfolio gallery end -------- */

/* ================================== form portfolio end ================================== */

$(document).ready(function(){ 
    /* ------------------- Tinymce start ------------------- */
    tinymce.init({
        selector: '#portfolio-description',
        plugins: 'advlist autolink lists link charmap preview anchor pagebreak',
    });
    /* ------------------- Tinymce end ------------------- */
    $('.nav-link').removeClass('active'); $('#link-edit_portfolio').addClass('active'); // nav-link active
    
    // portfolio item height
    var maxHeight = Math.max.apply(null, $("div.portfolio-card").map(function () {
        return $(this).height();
    }).get());
    $('.portfolio-card').css('height', maxHeight);
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/dashboard/edit_portfolio.blade.php ENDPATH**/ ?>