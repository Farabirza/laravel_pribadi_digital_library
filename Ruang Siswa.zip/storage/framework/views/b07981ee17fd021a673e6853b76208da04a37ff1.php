

<?php $__env->startPush('css-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<style>
body { background: #f9f9f9; }
.assignment-container {
    padding: 30px;
    background: #fff;
    box-shadow: 0 0 1px rgba(0,0,0,.125),0 1px 3px rgba(0,0,0,.2);
}
.assignment-container h3 { margin-bottom: 10px; }
.assignment-container p { margin-bottom: 10px; font-size: 11pt; }
.assignment-status { display: flex; align-items: center; padding: 8px 12px; border-radius: 4px; color: #fff; font-size: 11pt; }
.assignment-score { font-size: 18pt; font-weight: 600; }

.assignment-comment {
  border-radius: 0.3rem;
  background-color: #d2d6de;
  border: 1px solid #d2d6de;
  color: #444;
  margin: 5px 0 0 15px;
  padding: 10px;
  position: relative;
}
.assignment-comment::after, .assignment-comment::before {
  border: solid transparent;
  border-right-color: #d2d6de;
  content: " ";
  height: 0;
  pointer-events: none;
  position: absolute;
  right: 100%;
  top: 15px;
  width: 0;
}
.assignment-comment::after {
  border-width: 5px;
  margin-top: -5px;
}
.assignment-comment::before {
  border-width: 6px;
  margin-top: -6px;
}
.assignment-message {
    word-wrap: break-word;
  border-radius: 0.3rem;
  background-color: #d2d6de;
  border: 1px solid #d2d6de;
  color: #444;
  margin: 5px 15px 0 0;
  padding: 10px;
  position: relative;
}
.assignment-message::after, .assignment-message::before {
  border: solid transparent;
  border-left-color: #d2d6de;
  content: " ";
  height: 0;
  pointer-events: none;
  position: absolute;
  left: 100%;
  top: 15px;
  width: 0;
}
.assignment-message::after {
  border-width: 5px;
  margin-top: -5px;
}
.assignment-message::before {
  border-width: 6px;
  margin-top: -6px;
}

@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-assignment -->
<section id="section-assignment" class="ptb-60">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center mb-5">
                <h1 class="section-title title-dark">My Assignments</h1`>
            </div>
        </div>
        <div class="row mb-4"> <!-- row start -->
            <!-- Assignment-item -->
            <?php $i = 1; ?>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> <?php if($item['active'] == true): ?>
            <div class="assignment-item col-md-6 mb-4">
                <div class="assignment-container">
                    <div class="assignment-details">
                        <h5 class="mb-2" style="color:#df111e"><b><?php echo e($item['subject_title']); ?></b></h5>
                        <h3 class="d-flex flex-inline">
                            <span class="assignment-title mr-8"><?php echo e($item['title']); ?></span>
                            <?php if($item['status'] == 'open'): ?>
                            <?php elseif($item['status'] == 'submitted'): ?><span class="assignment-status" style="background:var(--bs-primary)"><i class='bx bx-check mr-8' ></i><?php echo e(ucfirst($item['status'])); ?></span>
                            <?php elseif($item['status'] == 'confirmed'): ?><span class="assignment-status" style="background:var(--bs-success)"><i class='bx bx-check-double mr-8'></i><?php echo e(ucfirst($item['status'])); ?></span>
                            <?php elseif($item['status'] == 'closed'): ?><span class="assignment-status" style="background:var(--bs-secondary)"><i class='bx bx-x mr-8' ></i><?php echo e(ucfirst($item['status'])); ?></span>
                            <?php elseif($item['status'] == 'warning'): ?><span class="assignment-status" style="background:var(--bs-warning)"><i class='bx bx-time-five mr-8'></i>Almost Deadline</span>
                            <?php elseif($item['status'] == 'deadline'): ?><span class="assignment-status" style="background:var(--bs-danger)"><i class='bx bx-x mr-8' ></i><?php echo e(ucfirst($item['status'])); ?></span>
                            <?php endif; ?> 
                        </h3>
                        <p> 
                            <?php if($item['score'] != null): ?><b>Score :</b>
                                <?php if($item['score'] >= 85): ?> <span class="assignment-score" style="color:var(--bs-primary)"><?php echo e($item['score']); ?></span>
                                <?php elseif($item['score'] < 85 && $item['score'] >= 75): ?> <span class="assignment-score" style="color:var(--bs-success)"><?php echo e($item['score']); ?></span>
                                <?php elseif($item['score'] < 75 && $item['score'] >= 60): ?> <span class="assignment-score" style="color:var(--bs-warning)"><?php echo e($item['score']); ?></span>
                                <?php elseif($item['score'] < 60): ?> <span class="assignment-score" style="color:var(--bs-danger)"><?php echo e($item['score']); ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </p>
                        <p><b>Time limit :</b> <span class="assignment-timeline fst-italic text-muted"><?php echo e($item['timelimit']); ?></span></p>
                        <p class="mb-3"><?php if($item['description'] != null): ?><b>Description :</b><br><?php echo e($item['description']); ?> <?php endif; ?></p>
                        <?php if($item['attachment_exist'] == 1): ?>
                            <p class="d-flex flex-wrap">
                                <?php $__empty_2 = true; $__currentLoopData = $item['attachments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <a href="/download_attachment/<?php echo e($attachment['id']); ?>" class="popper btn btn-secondary btn-sm mb-1 mr-8" target="_blank" title="<?php echo e($attachment['description']); ?>"><i class='bx bxs-file' ></i> <?php echo e($attachment['name']); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <?php endif; ?>
                            </p>
                        <?php endif; ?>
                    </div><hr>
                    
                    <!-- Accordion -->
                    <div class="card">
                        <h2 class="accordion-header" id="accrH-<?php echo e($i); ?>">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo e($i); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e($i); ?>"><b>Submission</b></button>
                        </h2>
                        <div id="collapse-<?php echo e($i); ?>" class="accordion-collapse collapse" aria-labelledby="accrH-<?php echo e($i); ?>" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <div class="assignment-chat mb-3">
                                    <?php if($item['message'] != null || $item['submission_file'] != null): ?>
                                    <div class="d-flex justify-content-end">
                                        <div class="assignment-message mb-2">
                                            <span class="font-9 text-muted">User message</span><br>
                                            <?php if($item['message'] != null): ?><?php echo e($item['message']); ?><?php endif; ?>
                                            <?php if($item['submission_file'] != null): ?>
                                                <?php if($item['message'] != null): ?><hr><?php endif; ?>
                                                <a href="/download_submission/<?php echo e($item['submission_id']); ?>" target="_blank"><i class="bx bxs-file mr-8 popper" title="Download submission file"></i><?php echo e($item['submission_file']); ?></a>
                                            <?php endif; ?>
                                        </div>
                                        <a href="<?php echo e(asset('/img/profiles/'.Auth::user()->profile->image)); ?>" class="glightbox"><img src="<?php echo e(asset('/img/profiles/'.Auth::user()->profile->image)); ?>" class="img-fluid rounded-circle" style="width:60px;"></a>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($item['comment'] != null || $item['response_file'] != null): ?>
                                    <div class="d-flex">
                                        <a href="<?php echo e(asset('/img/profiles/'.$item['admin_img'])); ?>" class="glightbox" title="<?php echo e($item['admin_name']); ?>">
                                            <img src="<?php echo e(asset('/img/profiles/'.$item['admin_img'])); ?>" class="img-fluid rounded-circle" style="width:60px;">
                                        </a>
                                        <div class="assignment-comment mb-2">
                                            <span class="font-9 text-muted">Admin comment</span><br>
                                            <?php if($item['comment'] != null): ?><?php echo e($item['comment']); ?><?php endif; ?>
                                            <?php if($item['response_file'] != null): ?>
                                                <?php if($item['comment'] != null): ?><hr><?php endif; ?>
                                                <a href="/download_personalAttachment/<?php echo e($item['assignment_id']); ?>/<?php echo e(Auth::user()->id); ?>" target="_blank"><i class="bx bxs-file mr-8 popper" title="Download submission file"></i><?php echo e($item['response_file']); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <form action="/submit_message/<?php echo e($item['assignment_id']); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <textarea name="message" rows="3" class="form-control mb-3" placeholder="Message"></textarea>
                                <p class="d-flex justify-content-end"><button type="submit" class="btn btn-primary btn-sm <?php if($item['status'] == 'deadline'): ?> disabled <?php endif; ?>"><i class='bx bx-message'></i> Send Message</button></p>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Accordion end -->

                    <hr>
                    <p class="d-flex flex-wrap">
                        <?php if($item['status'] == 'closed' || $item['status'] == 'deadline'): ?>
                        <a href="#" class="btn btn-secondary disabled mr-8">Link Closed</a>
                        <?php else: ?>
                        <a href="<?php echo e($item['assignment_id']); ?>" class="upload-submission btn btn-primary mr-8"><i class='bx bx-upload'></i> Upload</a>
                        <?php endif; ?>
                        <?php if($item['submission_file'] != null): ?>
                        <a href="/download_submission/<?php echo e($item['submission_id']); ?>" class="btn btn-primary mr-8" target="_blank"><i class='bx bx-download'></i> Download</a>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            <?php $i++; ?>
            <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="assignment-item col-md-12 mb-4">
                <div class="assignment-container text-center">
                    <h3>There is no assignment for you</h3>
                </div>
            </div>
            <?php endif; ?>
            <!-- Assignment-item end -->
        </div> <!-- row end -->
            
            <!-- Modal Upload Assignment -->
            <div class="modal fade" id="modal-upload" aria-hidden="true"> 
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Upload Submission</h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="/submit_file" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <input type="hidden" name="assignment_id" id="assignment_id" value="">
                                <div class="form-group">
                                    <label class="form-label">Input File</label>
                                    <input class="form-control" id="upload-file" name="file" type="file">
                                </div>
                                <p class="text-muted fst-italic">*Maximum file size : 50 Mb</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" id="cancel-upload" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Cancel</button>
                                <button type="submit" id="submit-upload" class="btn btn-primary"><i class='bx bx-upload' ></i> Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Modal Upload Assignment end -->

            <div class="col-md-12 text-center mb-4">
                <h1 class="section-title title-dark">History</h1`>
            </div>
            <div class="col-md-12">
                <table id="historyTable" class="table table-striped">
                    <thead>
                        <th>#</th>
                        <th>Subject</th>
                        <th>Title</th>
                        <th>Score</th>
                        <th>Comment</th>
                    </thead>
                    <tbody>
                        <?php $j = 1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> <?php if($item['active'] == false): ?>
                        <tr>
                            <td><?php echo e($j); ?></td>
                            <td><?php echo e($item['subject_title']); ?></td>
                            <td><?php echo e($item['title']); ?></td>
                            <td><?php if($item['score'] != null): ?><?php echo e($item['score']); ?><?php else: ?> - <?php endif; ?></td>
                            <td><?php if($item['comment'] != null): ?><?php echo e($item['comment']); ?><?php else: ?> - <?php endif; ?></td>
                        </tr>
                        <?php $j++; ?>
                        <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center">No assignment data found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</section>
<!-- section-assignment end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function(){
    var historyTable = $('#historyTable').DataTable();
    const lightbox = GLightbox({
        touchNavigation: true,
        loop: true,
        autoplayVideos: true
    });
});
</script>
<script src="<?php echo e(asset('/js/ajax_assignment.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/calendar/assignment.blade.php ENDPATH**/ ?>