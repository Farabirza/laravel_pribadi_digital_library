

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>" rel="stylesheet">
<style>
@media (max-width: 768px) {
    table { font-size: 9pt; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h3 class="fw-bold ps-3 border-start border-primary border-5">Statistik Pengunjung</h3>
            </div>
            <div class="col-md-6 p-3">
                <div class="shadow p-4 rounded">
                    <p id="heading-chart-visitor-total" class="d-flex justify-content-between mb-0">
                        <span><i class="bx bxs-bar-chart-alt-2 me-2"></i>Jumlah total pengunjung bulan ini</span>
                        <span type="button" data-bs-toggle="collapse" data-bs-target="#chart-visitor-total" aria-expanded="true" aria-controls="chart-visitor-total"><i class='bx bx-xs bx-minus toggle-collapse'></i></span>
                    </p>
                    <div id="chart-visitor-total" class="card p-4 collapse show mt-2" aria-labelledby="heading-chart-visitor-total">
                        <canvas id="chart-visitor-auth"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6 p-3">
                <div class="shadow p-4 rounded">
                    <p id="heading-chart-visitor-auth" class="d-flex justify-content-between mb-0">
                        <span><i class="bx bxs-bar-chart-alt-2 me-2"></i>Jumlah pengunjung terdaftar dan tidak terdaftar bulan ini</span>
                        <span type="button" data-bs-toggle="collapse" data-bs-target="#chart-visitor-auth" aria-expanded="true" aria-controls="chart-visitor-auth"><i class='bx bx-xs bx-minus toggle-collapse'></i></span>
                    </p>
                    <div id="chart-visitor-auth" class="card p-4 collapse show mt-2" aria-labelledby="heading-chart-visitor-auth">
                        <canvas id="chart-visitor-guest"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-12 p-3">
                <div class="shadow p-4 rounded">
                    <p class="mb-3"><i class='bx bx-table me-2'></i>Tabel pengunjung</p>
                    <!-- table visitor start -->
                    <table id="table-visitor" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Waktu</th>
                                <th>Pengunjung</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(date('Y/m/d | h:i A', strtotime($log->created_at))); ?></td>
                                <?php if($log->username != 'guest'): ?>
                                <td><a href="/cv/<?php echo e($log->username); ?>"><?php echo e($log->username); ?></a></td>
                                <?php else: ?>
                                <td><?php echo e($log->username); ?></td>
                                <?php endif; ?>
                            </tr> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- table visitor end -->
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('/vendor/chart/chart.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/vendor/chart/chartjs-plugin-datalabels.min.js')); ?>" ></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script>
$('.toggle-collapse').click(function(){
    $(this).toggleClass('bx-minus').toggleClass('bx-plus');
});

$(document).ready(function(){ 
    $('.nav-link').removeClass('active'); $('#link-analytics').addClass('active'); // nav-link active

    // chartjs
    var thisMonth_days = <?php echo e($thisMonth_days); ?>;
    var guest_visitor = <?php echo e($guest_visitor); ?>;
    var auth_visitor = <?php echo e($auth_visitor); ?>;
    var total_visitor = <?php echo e($total_visitor); ?>;
    var data_visitor = {
        labels: thisMonth_days,
        datasets: [
            {
            type: 'line', label: 'Akun terdaftar', fill: false,
            backgroundColor: "#0d6efd", borderColor: '#0d6efd',
            tension: 0.4, data: auth_visitor
            },
            {
            type: 'line', label: 'Tidak terdaftar', fill: false,
            backgroundColor: "#6c757d", borderColor: '#6c757d',
            tension: 0.4, data: guest_visitor
            },
        ]
    };
    var chart_visitor = $("#chart-visitor-guest").get(0).getContext('2d');
    window.myBar = new Chart(chart_visitor, { data: data_visitor, });
    var data_visitor_total = {
        labels: thisMonth_days,
        datasets: [{
            type: 'line', label: 'Total pengunjung', fill: true,
            backgroundColor: "#0d6efd", borderColor: '#0d6efd',
            tension: 0.4, data: total_visitor
        },]
    };
    var chart_visitor = $("#chart-visitor-auth").get(0).getContext('2d');
    window.myBar = new Chart(chart_visitor, { data: data_visitor_total, });
    // end of chartjs

    // datatables start
    $('#table-visitor').DataTable({
        order: [[0, 'desc']], responsive: true,
    });
    // datatables end
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/dashboard/analytics.blade.php ENDPATH**/ ?>