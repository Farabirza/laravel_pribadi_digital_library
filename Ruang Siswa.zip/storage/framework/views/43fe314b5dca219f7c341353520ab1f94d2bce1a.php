<!-- Check wether this user is an admin -->
<?php if(Auth::user()->role == 'user'): ?>
<?php header("Location: /?admin=false"); die(); ?>
<?php endif; ?>
<!-- Check wether this user is an admin -->



<?php $__env->startPush('css-styles'); ?>
<script src="https://cdn.tiny.cloud/1/azk02t135qrzd1zf1kmlzrv6alvdkzlaq3q0kn01d0ce8mu9/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script> <!-- Tiny MCE -->
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<style>
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark, .icon-dark { color: #124265; } .title-light, .icon-light { color: #f1f1f1; }
.title-icon { font-size: 28pt; }
.form-label { color: #149ddd; }
table tr { vertical-align: middle; }

#container-new-article { 
    padding: 20px;
    box-shadow: 0 0 1px rgba(0,0,0,.125),0 1px 3px rgba(0,0,0,.2); 
    border-top: 8px solid #fac863;
}
@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-news -->
<section id="section-news" class="ptb-60">
    <div class="container">
        <div class="row justify-content-center mb-4">
            <div class="col-md-12 mb-3 text-center">
                <i class='bx bx-news title-icon icon-dark mb-2' ></i>
                <h2 class="section-title title-dark">News Controller</h2>
            </div>
        </div> <!-- row end -->

        <!-- news table -->
        <div class="row mb-5">
            <h3 class="section-title title-dark mb-4">News Article List</h3>
            <div id="container-table-news" class="col-md-12">
                <table id="table-news" class="table table-striped">
                    <thead>
                        <th>#</th>
                        <th>Title</th>
                        <th>Published at</th>
                        <th>Author</th>
                        <th>Keywords</th>
                        <th>Uploaded by</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                            <td><?php echo e($item->author); ?></td>
                            <td><?php echo e($item->keywords); ?></td>
                            <td><?php echo e($item->user_email); ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" id="dropdown-news-action-<?php echo e($i); ?>" data-bs-toggle="dropdown" aria-expanded="false">Action&nbsp;</button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdown-news-action-<?php echo e($i); ?>">
                                        <li><a class="dropdown-item" href="/news/show/<?php echo e($item->id); ?>" target="_blank"><i class="bx bx-show mr-4"></i> Show</a></li>
                                        <li><a class="dropdown-item" href="/news/edit/<?php echo e($item->id); ?>"><i class="bx bx-edit-alt mr-4"></i> Edit</a></li>
                                        <li><a class="dropdown-item btn-warn" href="/news/delete/<?php echo e($item->id); ?>"><i class="bx bx-trash-alt mr-4"></i> Delete</a></li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php $i++ ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td class="text-center" colspan="7">No news article found</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- news table end -->

        <!-- news builder -->
        <div class="row justify-content-center mb-5">
            <form id="form-publish" action="/publish_article" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="publish_article">
                <div id="container-new-article" class="col-md-12">
                    <h3 class="mb-3"><i class='bx bxs-file-plus mr-4'></i> New Article</h3>
                    <!-- date and author -->
                    <div class="form-group d-flex mb-4">
                        <div class="col">
                            <label for="date" class="form-label">Date</label>
                            <input type="text" name="date" class="form-control" value="<?php echo e(date('l, d F Y', time())); ?>" disabled>
                        </div>
                        <span>&ensp;</span>
                        <div class="col">
                            <label for="author" class="form-label">Author</label>
                            <input type="text" name="author" class="form-control" value="<?php echo e(Auth::user()->profile->first_name.' '.Auth::user()->profile->last_name); ?>" placeholder="Author" required>
                        </div>
                    </div>
                    <!-- date and author end -->
                    <!-- title -->
                    <div class="form-floating mb-4">
                        <input type="text" name="title" class="form-control" placeholder="Title" required>
                        <label for="title" class="form-label">Title</label>
                    </div>
                    <!-- title end  -->
                    <!-- image -->
                    <div class="form-group text-center mb-3">
                        <label class="form-label">Featured image</label>
                        <label for="article-image"><img id="article-image-preview" class="w-50 box-shadow-2" src="<?php echo e(asset('img/news/default.jpg')); ?>"></label>
                        <input class="form-control form-input d-none" type="file" name="image" id="article-image">
                    </div>
                    <!-- image end  -->
                    <!-- content -->
                    <div class="form-group mb-3">
                        <label for="content" class="form-label">Content</label>
                        <textarea id="article-content" name="content"></textarea>
                    </div>
                    <!-- content end -->
                    <!-- keywords -->
                    <div class="form-group mb-4">
                        <label for="keywords" class="form-label">Keywords</label>
                        <textarea id="article-keywords" name="keywords" class="form-control" placeholder="keywords, goes, here"></textarea>
                    </div>
                    <!-- keywords end -->
                    <!-- button -->
                    <div class="form-group d-flex justify-content-end mb-3">
                        <button id="btn-article-reset" class="btn btn-secondary mr-8"><i class="bx bx-reset"></i> Reset</button>
                        <button role="submit" type="submit" class="btn btn-primary mr-8"><i class="bx bx-mail-send"></i> Publish</button>
                    </div>
                    <!-- button end -->
                </div>
            </form>
        </div> <!-- row end -->
        <!-- news builder end -->
        <div class="row">
            <div class="col-md-12 padd-20" id="preview"></div>
        </div>

    </div>
</section>
<!-- section-news end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
const lightbox = GLightbox({
    touchNavigation: true,
    loop: true,
    autoplayVideos: true
});
$('#article-image').change(function(){
    let reader = new FileReader();
    reader.onload = (e) => { 
        $('#article-image-preview').attr('src', e.target.result); 
    }
    reader.readAsDataURL(this.files[0]); 
}); 
$(document).ready(function(){
    tinymce.init({
        selector: '#article-content',
        plugins: 'advlist autolink lists link charmap preview anchor pagebreak',
    });

    var table_news = $('#table-news').DataTable();
    table_news.on('order.dt search.dt', function () {
        let i = 1;
        table_news.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(i++);
        });
    }).draw();

    $('.nav-link').removeClass('active');
    $('.nav-link-admin').addClass('active');
});
</script>
<script src="<?php echo e(asset('/js/ajax_news.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/admin/admin_news.blade.php ENDPATH**/ ?>