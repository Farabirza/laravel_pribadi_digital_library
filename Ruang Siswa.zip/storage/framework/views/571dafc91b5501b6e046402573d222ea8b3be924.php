<!DOCTYPE html>
<html lang="en">

<head>
<?php echo $__env->make('layouts.partials.metaTags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.6.0.min.js')); ?>"></script>

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<?php if(isset($page_title)): ?>
<title><?php echo e($page_title); ?></title>
<?php else: ?>
<title>cvkreatif.com</title>
<?php endif; ?>
  
<?php echo $__env->yieldPushContent('css-styles'); ?>
<style>
@media (max-width: 768px) {
}

@media (max-width: 1199px) {
}
</style>
</head>
<body>
  
<!-- ======= Main content ======= -->
<main id="main">
<?php echo $__env->yieldContent('content'); ?>
</main>
<!-- ======= Main content end ======= -->

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/axios/axios.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>

<script type="text/javascript">
const domain = 'http://localhost:8000/';
// const domain = 'https://internal.journalsml.co.id/';

$(window).resize(function() {
  if($(window).width() < 1199) {
  } else {
  }
});
$(document).ready(function() {
  if($(window).width() < 1199) {
  } else {
  }
  
  // tooltip
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
  })
  // popperjs
  $('.popper').popover({
      trigger: 'hover',
      html: true,
      placement: 'bottom',
      container: 'body'
  });
  <?php if(session('success')): ?>
    successMessage("<?php echo e(session('success')); ?>");
  <?php elseif(session('error')): ?>
    errorMessage("<?php echo e(session('error')); ?>");
  <?php elseif(session('info')): ?>
    infoMessage("<?php echo e(session('info')); ?>");
  <?php endif; ?>
});

<?php if(isset($_GET['info'])): ?>
    Swal.fire({
      icon: 'info',
      title: "<?php echo e($_GET['info']); ?>",
      showConfirmButton: false,
      timer: 3000
    });
<?php endif; ?>

function successMessage(message) { toastr.success(message, 'Success!'); } 
function infoMessage(message) { toastr.info(message, 'Info'); } 
function warningMessage(message) { toastr.error(message, 'Warning!'); } 
function errorMessage(message) { toastr.error(message, 'Error!'); } 
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\CV Kreatif 2.0\cvkreatif.com\resources\views/layouts/master.blade.php ENDPATH**/ ?>