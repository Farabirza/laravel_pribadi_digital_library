<?php if(auth()->guard()->guest()): ?>
<?php header("Location: /?login=required"); die(); ?>
<?php endif; ?>



<?php $__env->startPush('css-styles'); ?>
<style>
.form-range:hover::after {
  content: attr(title);
  position: absolute;
  top: -100%;
  left: 0;
}
#main { min-height: 100vh; background: #f9f9f9; }
.bl-darkblue-md { color: #374785; }

.portfolio-item-add { min-height: 240px; }
.portfolio-item .card:hover { 
    cursor: pointer; 
    color: #fff;
    background-color: #0d6efd;
    transition: ease-in-out .3s;
} .portfolio-img { max-height: 240px; }
@media (max-width: 768px) {
    #section-form { padding-top: 20px; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-form" class="py-40">
    <div class="container">
        <?php echo $__env->make('cv.partials.wizard_progressbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('cv.partials.wizard_disclaimer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row align-items-center mb-4"> <!-- row start -->
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold ps-3 fs-32 bl-darkblue-md">Keterampilan</h3>
            </div>

            <div class="col-md-12 card p-4">
                <!-- table skill start -->
                <table id="table-skill" class="table table-striped align-middle mb-3">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Jenis keterampilan</th>
                            <th>Tingkat kemahiran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($skill->name); ?></td>
                            <td class="pe-4">
                                <div class="progress"><div class="progress-bar popper" role="progressbar" aria-label="Animated striped example" aria-valuenow="<?php echo e($skill->proficiency); ?>0" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($skill->proficiency); ?>0%" title="<?php echo e($skill->proficiency); ?> / 10"></div></div>
                            </td>
                            <td class="d-flex flex-wrap">
                                <span class="btn btn-success btn-sm d-flex align-items-center btn-skill-edit fs-10" data-skill-id="<?php echo e($skill->id); ?>"><i class="bx bx-edit-alt me-1"></i>Edit</span>
                            </td>
                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="text-center">Data tidak ditemukan</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <p class="mb-0 d-flex">
                    <span class="btn btn-primary btn-sm d-flex align-items-center btn-skill-add"><i class="bx bx-plus me-1"></i> Tambahkan</span>
                </p>
                <!-- table skill end -->
            </div>

        </div> <!-- row end -->

        <div class="row mb-4"> <!-- row start -->
            <div class="d-flex justify-content-end align-items-center">
                <hr class="col me-3" style="height:2px"/>
                <a href="/wizard/experience?from=80" class="btn btn-secondary me-2"><i class='bx bx-left-arrow-alt' ></i> Sebelumnya</a>
                <a href="/wizard/config?from=80" class="btn btn-primary me-2"><i class='bx bx-right-arrow-alt' ></i> Selanjutnya</a>
            </div>
        </div> <!-- row end -->

    </div>
</section>


<!-- Modal skill Add -->
<div class="modal fade" id="modal-skill-add" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center"><i class='bx bx-plus me-2'></i><span>Tambahkan keterampilan</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/dashboard/add/skill" id="form-skill-add" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body fs-10">
                <div class="col mb-3 form-floating">
                    <input type="text" class="form-control form-control-sm" name="add-name" placeholder="Keterampilan" value="" required>
                    <label for="add-name" class="form-label">Jenis keterampilan</label>
                </div>
                <div class="col mb-2">
                    <label for="add-proficiency" class="form-label fs-11">Tingkat kemahiran</label>
                    <div class="d-flex">
                        <span class="fs-11 text-danger me-3">Pemula</span>
                        <input type="range" name="add-proficiency" class="form-range col" min="1" max="10" step="1" required>
                        <span class="fs-11 text-primary ms-3">Expert</span>
                    </div>
                    <span class="fs-11 text-muted">Level :</span> <span id="add-skill-prof-level" class="fs-11 fw-bold skill-prof-level">6</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-plus' ></i> Tambahkan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal skill Add end -->

<!-- Modal skill edit start -->
<div class="modal fade" id="modal-skill-edit" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title d-flex align-items-center"><i class='bx bx-edit-alt me-2'></i><span>Edit keterampilan</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/dashboard/update/skill" id="form-skill-edit" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="edit-skill_id" val=""/>
            <div class="modal-body fs-10">
                <div class="col mb-3 form-floating">
                    <input type="text" class="form-control form-control-sm" name="edit-name" placeholder="Keterampilan" value="" required>
                    <label for="edit-name" class="form-label">Jenis keterampilan</label>
                </div>
                <div class="col mb-2">
                    <label for="edit-proficiency" class="form-label fs-11">Tingkat kemahiran</label>
                    <div class="d-flex">
                        <span class="fs-11 text-danger me-3">Pemula</span>
                        <input type="range" name="edit-proficiency" class="form-range col" min="1" max="10" step="1" required>
                        <span class="fs-11 text-primary ms-3">Expert</span>
                    </div>
                    <span class="fs-11 text-muted">Level :</span> <span id="edit-skill-prof-level" class="fs-11 fw-bold skill-prof-level">6</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <a href="" type="button" class="btn btn-danger btn-sm btn-warn-delete btn-delete-skill"><i class='bx bx-trash-alt' ></i> Hapus</a>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-edit-alt' ></i> Update</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal skill edit end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });

/* ------------------------------------------- skill start ------------------------------------------- */
$('.btn-skill-add').click(function(){ $('#modal-skill-add').modal('show'); });
$('.btn-skill-edit').click(function(){
    var skill_id = $(this).attr('data-skill-id');
    var formData = { 
        action: 'edit_skill', skill_id: skill_id,
    };
    $.ajax({
        type: "POST",
        url: "/ajax/dashboard",
        data: formData,
        dataType: 'JSON',
        success: function (data) {
            $('.btn-delete-skill').attr('href', '/dashboard/delete/skill/'+skill_id);
            $('[name="edit-skill_id"]').val(skill_id);
            $('[name="edit-name"]').val(data.skill.name);
            $('[name="edit-proficiency"]').val(data.skill.proficiency);
            $('#edit-skill-prof-level').html(data.skill.proficiency);
            $('#modal-skill-edit').modal('show');
        }, error:function(data) {
            errorMessage('Terdapat kesalahan');
        },
    });
});
/* ------------------------------------------- skill end ------------------------------------------- */


$(document).ready(function(){
    if($(window).width() < 992) {
        $('.skill-content').removeClass('w-50');
    } else {
        $('.skill-content').removeClass('w-50').addClass('w-50');
    }
    // Progressbar
    $('.progress-list').removeClass('progress-list-active');
    $('#progress-list-skill').addClass('progress-list-active');
    $('.progress-bar-wizard').css('width','80%').attr('aria-valuenow','80');
    // portfolio height
    
    var maxHeight = Math.max.apply(null, $("div.portfolio-card").map(function () {
        return $(this).height();
    }).get());
    $('.portfolio-card').css('height', maxHeight);
});

$(window).resize(function() {
  if($(window).width() < 992) {
      $('.skill-content').removeClass('w-50');
  } else {
      $('.skill-content').removeClass('w-50').addClass('w-50');
  }
});

// Form range
$('[name="add-proficiency"]').change(function(e) {
    $('#add-skill-prof-level').html($(this).val());
});
$('[name="edit-proficiency"]').change(function(e) {
    $('#edit-skill-prof-level').html($(this).val());
});

// Form
$('#form-skill').change(function(e){
    $('.btn-form-save').removeClass('disabled');
});


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/cv/wizard_skill.blade.php ENDPATH**/ ?>