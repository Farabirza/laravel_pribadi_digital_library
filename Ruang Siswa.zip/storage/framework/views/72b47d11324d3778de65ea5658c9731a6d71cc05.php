
<?php $__env->startPush('css-styles'); ?>
<style>
.container-profile-image-cropper { position: relative; }
#overlay-img img {
    opacity: 1;
    display: block;
    width: 100%;
    height: auto;
    transition: .5s ease;
    backface-visibility: hidden;
}
.overlay {
    transition: .5s ease;
    opacity: 0;
    position: absolute;
    text-align: center;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
}
/* .container-profile-image-cropper:hover #overlay-img img { opacity: 0.8; } */
.container-profile-image-cropper:hover .overlay { opacity: 1; }
.overlay-text { background-color: var(--bs-primary); color: white; font-size: 10pt; padding: 4px 10px; border: 1px solid var(--bs-primary); }
.overlay-text:hover { cursor:pointer; background-color: #fff; color: var(--bs-primary); transition: .5s; }
.cropper-preview { overflow: hidden; height: 180px; margin: 10px; border: 1px solid red; }
</style>
<?php $__env->stopPush(); ?>

<!-- profile picture start -->
<div class="d-flex justify-content-center">
    <div class="container-profile-image-cropper col-md-4 text-center mb-3">
        <label for="replace-img">
            <div id="overlay-img">
                <img src="<?php echo e(asset('/img/profiles/'.Auth::user()->profile->image)); ?>" id="profile-img" alt="" class="rounded-circle shadow">
            </div>
            <div class="overlay">
                <div id="overlay-text" class="overlay-text rounded"><i class='bx bx-image-alt'></i> Ubah foto profil</div>
            </div>
        </label>
    </div>
    <form id="form-profile-image-cropper" enctype="multipart/form-data" method="POST">
        <input id="replace-img" class="absolute d-none" name="profile-img" type="file">
    </form>
</div>
<!-- profile picture end -->

<!-- modal image cropper -->
<div id="modal-profile-image-cropper" class="modal fade prevent-select" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-md-8">
                            <img id="img-crop" src="">
                        </div>
                        <div class="col-md-4">
                            <div class="cropper-preview"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batalkan</button>
                <button type="button" class="btn btn-primary" id="crop">Pilih</button>
            </div>
        </div>
    </div>
</div>
<!-- modal image cropper end -->

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

$('input[name=profile-img]').change(function(e){
    var modal = $('#modal-profile-image-cropper');
    var image = document.getElementById('img-crop');
    var cropper;
    modal.modal('show');

    let reader = new FileReader();
    reader.onload = (e) => { 
        $('#img-crop').attr('src', e.target.result); 
    }
    reader.readAsDataURL(this.files[0]); 

    modal.on('shown.bs.modal', function () {
        cropper = new Cropper(image, {
        aspectRatio: 1, viewMode: 3, preview: '.cropper-preview',
        });
    }).on('hidden.bs.modal', function () {
        cropper.destroy();
        cropper = null;
    });
    $("#crop").click(function(){
        var canvas = cropper.getCroppedCanvas({
            width: 320,
            height: 320,
        });
        canvas.toBlob(function(blob) {
            url = URL.createObjectURL(blob);
            var reader = new FileReader();
            reader.readAsDataURL(blob); 
            reader.onloadend = function() {
                var base64data = reader.result; 
                $.ajax({
                    type: "POST",
                    url: "/ajax/profile",
                    data: { action: 'update_profile_img', profile_img: base64data },
                    dataType: "json",
                    success: function(data) {
                        modal.modal('hide');
                        successMessage('Foto profil anda berhasil diperbaharui');
                        location.reload();
                    }, error: function(data) {
                        errorMessage('Foto profil anda gagal diperbaharui');
                        return false;
                    }
                });
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/layouts/partials/profile_image_cropper.blade.php ENDPATH**/ ?>