<style>
.progress-list { 
    letter-spacing: 1px;
    font-weight: 600;
    font-size: 12pt;
    color: #374785;
 }
.progress-list-active .progress-icon, .progress-icon:hover  {
    background: #374785;
    color: #fff;
}
.progress-icon {
    padding: 12px;
    border-radius: 50%;
    margin-bottom: 10px;
    font-size: 4rem;
    border: 2px solid #374785;
    color: #374785;
}
.progressbar-line {
	height: 1px;
    min-width: 40px;
	border-top: 1px solid #374785;
    margin-left: 12px;
    margin-right: 12px;
}
@media (max-width: 768px) {
    .progress-list { letter-spacing: .2; font-weight: 400; font-size: 8pt; }
    .progress-icon { padding: 8px; border: 1px solid #374785; margin-bottom: 6px; font-size: 20pt; }
    .progressbar-line, .progress-title { display: none; }
}
</style>

<div class="row d-flex justify-content-center mb-5">
    <div class="col-md-10 d-flex mb-3 progress-container">
        <a href="/wizard/profile" class="text-center progress-list"><div id="progress-list-profile">
            <i class='bx bxs-user progress-icon'></i>
            <p class="progress-title">Profil</p>
        </div></a>
        <div class="progressbar-line col"></div>
        <a href="/wizard/education" class="text-center progress-list"><div id="progress-list-edu">
            <i class='bx bxs-graduation progress-icon'></i>
            <p class="progress-title">Pendidikan</p>
        </div></a>
        <div class="progressbar-line col"></div>
        <a href="/wizard/experience" class="text-center progress-list"><div id="progress-list-wh">
            <i class='bx bxs-briefcase progress-icon'></i>
            <p class="progress-title">Pengalaman</p>
        </div></a>
        <div class="progressbar-line col"></div>
        <a href="/wizard/skill" class="text-center progress-list"><div id="progress-list-skill">
            <i class='bx bxs-brush progress-icon'></i>
            <p class="progress-title">Keterampilan</p>
        </div></a>
        <div class="progressbar-line col"></div>
        <a href="/wizard/config" class="text-center progress-list"><div id="progress-list-config">
            <i class='bx bxs-cog progress-icon'></i>
            <p class="progress-title">Konfigurasi</p>
        </div></a>
    </div>
    <div class="col-md-10">
        <div class="progress">
            <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-label="Basic example" style="width: <?php if(isset($_GET['from'])): ?> <?php echo e($_GET['from'].'%'); ?> <?php else: ?> 0 <?php endif; ?>" aria-valuenow="<?php if(isset($_GET['from'])): ?> <?php echo e($_GET['from']); ?> <?php else: ?> 0 <?php endif; ?>" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $('.progress-container').addClass('justify-content-center');
    $('.progress-list').addClass('mx-auto');
    $('.progressbar-line').css('margin-top', $('.progress-icon').outerHeight()/2);
})
$(window).resize(function() {
    if($(window).width() < 992) {
        $('.progress-container').addClass('justify-content-center');
        $('.progress-list').addClass('mx-auto');
        $('.progressbar-line').css('margin-top', $('.progress-icon').outerHeight()/2);
    }
});
</script><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com - Duplicate\resources\views/cv/partials/wizard_progressbar.blade.php ENDPATH**/ ?>