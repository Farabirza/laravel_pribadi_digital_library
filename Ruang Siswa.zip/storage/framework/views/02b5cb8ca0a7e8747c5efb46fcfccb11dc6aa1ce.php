<hr class="mb-3"/>
<div class="form-group d-flex justify-content-end">
    <button type="submit" class="btn btn-primary"><i class='bx bxs-save' ></i> Simpan</button>
</div><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/partials/cv_create_submit.blade.php ENDPATH**/ ?>