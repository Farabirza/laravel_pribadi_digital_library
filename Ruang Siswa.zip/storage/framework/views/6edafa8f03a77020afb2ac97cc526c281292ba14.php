

<!-- Modal Login -->
<div class="modal fade" id="modal-login" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title align-middle fw-bold"><span class="px-2 py-1 bg-primary text-light rounded-circle me-1"><i class='bx bx-log-in-circle'></i></span> Masuk ke akun kamu</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/login" id="form-login" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="form-floating mb-3">
                    <input type="email" name="email" id="modal-login-email" class="form-control" placeholder="Email" value="" required>
                    <label for="modal-login-email" class="label">Email</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" name="password" id="modal-login-password" class="form-control" placeholder="Password" value="" required>
                    <label for="modal-login-password" class="label">Password</label>
                </div>
                <div class="form-outline mb-3">
                    <p class="text-muted" style="color: #393f81;"><input type="checkbox" name="remember" value="true" class="mr-8"> Ingat saya</p>
                </div>
                <p class="text-muted">Belum punya akun? <a class="btn-modal-register text-primary" href="#">Daftar</a></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Cancel</button>
                <button type="submit" class="btn btn-primary"><i class='bx bx-log-in-circle' ></i> Sign in</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal Login end -->
<!-- Modal Register -->
<div class="modal fade" id="modal-register" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title align-middle fw-bold"><span class="px-2 py-1 bg-primary text-light rounded-circle me-1"><i class='bx bxs-user-plus'></i></span> Buat akun baru</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/register" id="form-register" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="form-floating mb-3">
                    <input type="text" name="username" id="modal-register-username" class="form-control" placeholder="Username" value="" required>
                    <label for="modal-register-username" class="label">Username</label>
                </div>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="alert-danger-username" class="alert alert-danger mb-3"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="text-muted fst-italic font-10 mb-2">*username akan menjadi acuan alamat CV anda, contoh: https://cvkreatif.com/cv/john_doe</p>
                <p class="text-muted fst-italic font-10 mb-3">*hanya gunakan kombinasi huruf, angka, atau underscore ('_')</p>
                <div class="form-floating mb-3">
                    <input type="email" name="email" id="modal-register-email" class="form-control" placeholder="Email" value="" required>
                    <label for="modal-register-email" class="label">Email</label>
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="alert-danger-email" class="alert alert-danger mb-3"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-floating mb-3">
                    <input type="password" name="password" id="modal-register-password" class="form-control" placeholder="Password" value="" required>
                    <label for="modal-register-password" class="label">Password</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" id="modal-register-password_confirmation" class="form-control" name="password_confirmation" placeholder="Confirm Password" required>
                    <label for="modal-register-password_confirmation" class="form-label">Confirm password</label>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="alert-danger-password" class="alert alert-danger mb-3"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="text-muted fst-italic font-10 mb-3">*Password minimal terdiri dari 6 karakter</p>
                <div class="form-outline mb-3">
                    <p class="" style="color: #393f81;"><input type="checkbox" name="agreement" value="true" class="mr-8"> Saya setuju dengan <a class="text-primary" href="#">syarat dan ketentuan</a> yang berlaku</p>
                </div>
                <p class="text-muted">Sudah punya akun? <a class="btn-modal-login text-primary" href="#">Masuk</a></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Cancel</button>
                <button type="submit" class="btn btn-primary"><i class='bx bx-log-in-circle' ></i> Register</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal Register end -->

<script type="text/javascript">
$('.btn-modal-login').click(function(e){
  e.preventDefault();
  $('.modal').modal('hide');
  $('#modal-login').modal('show');
})
$('.btn-modal-register').click(function(e){
  e.preventDefault();
  $('.modal').modal('hide');
  $('#modal-register').modal('show');
})
$('#form-register').submit(function(e){
    e.preventDefault();
    if($('input[name="agreement"]').is(":checked")) {
        e.currentTarget.submit();
    } else {
        Swal.fire({
            icon: 'error',
            title: "Tidak dapat melanjutkan!",
            text: "Anda perlu konfirmasi persetujuan syarat dan ketentuan untuk dapat melanjutkan proses registrasi",
            showConfirmButton: true,
        });
    }
});
$(document).ready(function(){
    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    errorMessage('Username error : <?php echo e($message); ?>');
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    errorMessage('Email error : <?php echo e($message); ?>');
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    errorMessage('Password error : <?php echo e($message); ?>');
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
});
</script><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com - Duplicate\resources\views/layouts/partials/modal_auth.blade.php ENDPATH**/ ?>