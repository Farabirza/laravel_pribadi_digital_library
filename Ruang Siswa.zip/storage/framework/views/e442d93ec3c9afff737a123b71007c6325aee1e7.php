

<?php $__env->startPush('css-styles'); ?>
<style>
#section-hero {
    height: 100vh;
    background: url('../img/bg/bg_trans-80.png') top left repeat, url("../img/bg/mitraleipzig-min.png") top center transparent fixed;
    background-size: cover;
    color: white;
    text-align: center;
}
.btn-hero1 { margin-right: 20px; padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: white; color: #202020; }
.btn-hero1:hover { background: transparent; color: white; transition: ease .4s; }
.btn-hero2 { padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: transparent; }
.btn-hero2:hover { background: white; color: #202020; transition: ease .4s; }

.section-title {
  margin-bottom: 20px;
  padding-bottom: 20px;
  position: relative;
}
.section-title::after {
    content: "";
    position: absolute;
    display: block;
    width: 50px;
    height: 3px;
    background: #124265;
    bottom: 0;
    left: 0;
}
/* .section-title { text-align: center; margin-bottom: 30px; }
.section-title:before,
.section-title:after {
  content: "";
  width: 50px;
  height: 2px;
  background: var(--bs-warning);
  display: inline-block;
}
.section-title:before {
  margin: 0 15px 10px 0;
}
.section-title:after {
  margin: 0 0 10px 15px;
} */

#section-event .event-card {
    width: 100%;
    background: #f9f9f9;
    padding: 20px;
    border: 1px solid;
    border-left: 20px solid;
    border-radius: 0 4px 4px 0;
} 
#section-event .event-description { color: #404040; font-size: 11pt; }

.news-item { padding: 0 10px 20px 10px; }
.news-item .card:hover { box-shadow: 2px 2px 10px #999; }

.assignments-item { 
    padding: 20px;
    border-top: 20px solid;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-left: 2px solid; 
    border-radius: 4px;
}
.assignments-item p { margin-bottom: .5rem; }
.assignments-item .assignments-title { color: #404040; }
.assignments-item .assignments-status { 
    display: inline-block;
    padding: 4px 8px; 
    border-radius: 4pt;
    vertical-align: middle;
    text-align: center;
    color: #fff; 
    font-size: 11pt; 
}
.assignments-item .assignments-time_limit { color: var(--bs-secondary); font-style: italic; }
.assignments-item .assignments-description { color: #404040; }

@media (max-width: 768px) {
    #section-hero { padding: 40px 0; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section start -->
<section>
    <div class="container">
        <div class="row">
            <!-- left -->
            <div class="col-md-9 prl-20">
                <!-- section-event -->
                <div id="section-event" class="row ptb-40">
                    <div class="col-md-12 mb-4 text-center">
                        <h1 class="display-4 title-dark"><?php echo e($today); ?></h1>
                        <h5 class="display-5 title-dark"><span id="clock"></span></h5>
                    </div>
                    <div class="col-md-12 mb-3">
                        <h1 class="section-title title-dark">Event</h1>
                    </div>
                    <!-- today events -->
                    <div class="col-md-12 mb-2">
                        <div class="mb-3">
                            <h3 class="title-dark"><b>Today's Events</b></h3>
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="event-card mb-3" style="border-color: <?php echo e($event->color); ?>;">
                            <h3 class="event-title display-5 mb-2"><?php echo e($event->title); ?></h3>
                            <?php if($event->start_time == '00:00' && $event->end_time == '23:59'): ?>
                            <p class="event-time mb-2"><i class='bx bx-time' ></i> All day</p>
                            <?php else: ?>
                            <p class="event-time fst-italic mb-2"><i class='bx bx-time' ></i> <?php echo e($event->start_time); ?> - <?php echo e($event->end_time); ?></p>
                            <?php endif; ?>
                            <p class="event-description"><?php echo e($event->description); ?></p>
                            <?php if($event->link != ''): ?><p class="event-link"><a href="<?php echo e($event->link); ?>" target="_blank" class="btn btn-primary"><i class='bx bx-link-alt'></i> Visit Link</a></p><?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="event-card mb-3" style="border-color: var(--bs-secondary);">
                            <p class="mb-0">There's no event for today</p>
                        </div>
                        <?php endif; ?>
                    </div>
                    <!-- today events end -->

                    <!-- next events -->
                    <div class="col-md-12 mb-2">
                        <div class="mb-3">
                            <h3 class="title-dark"><b>Next Events</b></h3>
                        </div>
                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $next_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="nextEvents-item col-md-6 mb-1">
                                <h5 style="color:#fac863;"><span class="popper" title="<?php echo e($item->description); ?>"><?php echo e($item->title); ?></span></h5>
                                <p class="text-muted font-10"><?php echo e(date('l, d M Y', strtotime($item->start)).' - '.date('l, d M Y', strtotime($item->end)).' | '.$item->start_time.' - '.$item->end_time); ?></p>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="nextEvents-item col-md-12 mb-1">
                                <h5 class="text-muted">No event until next week</h5>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- next events end -->

                    <div class="col-md-12"><i><a href="/calendar">Go to calendar &raquo;</a></i></div>
                </div>
                <!-- section-event end -->

                <hr>

                <!-- section-assignment -->
                <div id="section-myAssignment" class="row ptb-40">
                    <div class="col-md-12 mb-3">
                        <h1 class="section-title title-dark">My Assignments</h1>
                    </div>

                    <!-- My Assignments -->
                    <?php $__empty_1 = true; $__currentLoopData = $myAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                    <?php if($item['active'] == true): ?>
                    <div class="col-md-6">
                        <div class="assignments-item w-100 mb-4"
                            <?php if($item['status'] === 'open'): ?> style="border-color:var(--bs-primary)"> 
                            <?php elseif($item['status'] === 'submitted'): ?> style="border-color:var(--bs-primary);color:var(--bs-primary)"> 
                            <?php elseif($item['status'] === 'confirmed'): ?> style="border-color:var(--bs-success);color:var(--bs-success)"> 
                            <?php elseif($item['status'] === 'warning'): ?> style="border-color:var(--bs-warning);color:var(--bs-warning)"> 
                            <?php elseif($item['status'] === 'deadline'): ?> style="border-color:var(--bs-danger);color:var(--bs-danger)"> 
                            <?php endif; ?>
                            <h3 class="vertical-center flex-wrap">
                                <span class="assignments-title mr-8 mb-1"><?php echo e($item['title']); ?></span>
                                <?php if($item['status'] === 'submitted'): ?><span class="assignments-status btn-primary mb-1">Submitted</span>
                                <?php elseif($item['status'] === 'confirmed'): ?><span class="assignments-status btn-success mb-1">Confirmed</span>
                                <?php elseif($item['status'] === 'warning'): ?><span class="assignments-status btn-warning mb-1">Almost Deadline</span>
                                <?php elseif($item['status'] === 'deadline'): ?><span class="assignments-status btn-danger mb-1">Deadline</span>
                                <?php endif; ?>
                            </h3>
                            <p class="assignments-time_limit" 
                                <?php if($item['status'] === 'warning'): ?> style="color:var(--bs-warning)">
                                <?php elseif($item['status'] === 'deadline'): ?> style="color:var(--bs-danger)">
                                <?php else: ?> ">
                                <?php endif; ?>
                                <?php echo e($item['date_limit']); ?> | <?php echo e($item['time_limit']); ?></p>
                            <p class="assignments-description mb-3"><?php echo e($item['description']); ?></p>
                            <div class="d-flex">
                                <?php if($item['status'] === 'submitted'): ?>
                                <a href="/download_submission/<?php echo e($item['submission_id']); ?>" class="btn btn-primary btn-sm mr-8" target="_blank"><i class='bx bx-download'></i> Download</a>
                                <a href="/assignments?assignment_id=<?php echo e($item['assignment_id']); ?>" class="btn btn-primary btn-sm mr-8"><i class='bx bx-edit' ></i> Edit</a>
                                <?php elseif($item['status'] === 'confirmed'): ?>
                                <a href="/download_submission/<?php echo e($item['submission_id']); ?>" class="btn btn-primary btn-sm mr-8" target="_blank"><i class='bx bx-download'></i> Download</a>
                                <?php elseif($item['status'] === 'deadline'): ?>
                                <a href="" class="btn btn-dark btn-sm disabled mr-8">Submission link closed</a>
                                <?php else: ?>
                                <a href="/assignments?assignment_id=<?php echo e($item['assignment_id']); ?>" class="btn btn-primary btn-sm mr-8"><i class='bx bx-mail-send' ></i> Submit</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <div class="assignments-item w-100 mb-4" style="border-color:var(--bs-secondary)">
                            <p class="text-center">There is no assignment for you</p>
                        </div>
                    </div>
                    <?php endif; ?>
                    <!-- My Assignments end -->

                    <div class="col-md-12"><i><a href="/assignments">More assignments &raquo;</a></i></div>
                </div>
                <!-- section-assignment end -->
            </div>
            <!-- left end -->

            <!-- right -->
            <div class="col-md-3 prl-20">
                
                <div class="row justify-content-center ptb-40">
                    <div class="col-md-12 mb-3">
                        <h3 class="title-dark"><b>News</b></h3>
                    </div>
                    <?php $i = 1; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="news-item col-md-12"> <!-- news-item -->
                        <div class="card">
                            <img src="<?php echo e(asset('img/news/'.$item['image'])); ?>" alt="">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($item['title']); ?></h5>
                                <p class="font-10 mb-1"><span class="text-muted fst-italic"><?php echo e($item['created_at']); ?></span> | <a href="/news?key=<?php echo e($item['author']); ?>"><?php echo e($item['author']); ?></a></p>
                                <?php if($item['keywords'][0] != null): ?>
                                <p id="article-keywords-<?php echo e($i); ?>" class="font-10 mb-2">
                                    <?php $__empty_2 = true; $__currentLoopData = $item['keywords']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <a href="/news?key=<?php echo e(ltrim($key)); ?>">#<?php echo e(ltrim($key)); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <?php endif; ?>
                                </p>
                                <?php endif; ?>
                                <p class="font-10 mb-2"><a href="/news/show/<?php echo e($item['news_id']); ?>">Read more &raquo;</a></p>
                            </div>
                        </div>
                    </div> <!-- news-item end -->
                    <?php $i++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="news-item col-md-12"> <!-- news-item -->
                        <div class="card">
                            <img src="<?php echo e(asset('img/bg/bg-hero-1.jpg')); ?>" alt="">
                            <div class="card-body">
                                <h5 class="card-title">News</h5>
                                <p class="font-10 mb-1"><span class="text-muted fst-italic">14 June 2022</span> | Admin</p>
                                <p class="font-10 mb-2">Quisque elit urna, cursus a rutrum nec, pharetra non dui.</p>
                                <p class="font-10 mb-2"><a href="#">Read more &raquo;</a></p>
                            </div>
                        </div>
                    </div> <!-- news-item end -->
                    <?php endif; ?>
                    <div class="col-md-12"><i><a href="/news">More news &raquo;</a></i></div>
                </div> <!-- row end  -->

            </div>
            <!-- right end -->
        </div>
    </div>
</section>
<!-- section end -->


<!-- section-news -->
<section id="section-news" class="ptb-60">
    <div class="container">

    </div>
</section>
<!-- section-news end -->

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
$(document).ready(function(){
    startTime();
    $('.popper').popover({
        trigger: 'hover',
        html: true,
        placement: 'bottom',
        container: 'body'
    });
});
function startTime() {
  const today = new Date();
  let h = today.getHours();
  let m = today.getMinutes();
  let s = today.getSeconds();
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById('clock').innerHTML =  h + ":" + m + ":" + s;
  setTimeout(startTime, 1000);
}

function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/home.blade.php ENDPATH**/ ?>