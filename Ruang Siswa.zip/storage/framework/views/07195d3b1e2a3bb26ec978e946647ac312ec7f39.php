

<?php $__env->startPush('css-styles'); ?>
<style>
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif 2.0\cvkreatif.com\resources\views/dashboard/overview.blade.php ENDPATH**/ ?>