<!-- Check wether this user is an admin -->
<?php if(Auth::user()->role == 'user'): ?>
<?php header("Location: /?admin=false"); die(); ?>
<?php endif; ?>
<!-- Check wether this user is an admin -->



<?php $__env->startPush('css-styles'); ?>
<script src="https://cdn.tiny.cloud/1/azk02t135qrzd1zf1kmlzrv6alvdkzlaq3q0kn01d0ce8mu9/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script> <!-- Tiny MCE -->
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<style>
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark, .icon-dark { color: #124265; } .title-light, .icon-light { color: #f1f1f1; }
.title-icon { font-size: 28pt; }
.form-label { color: #149ddd; }
table tr { vertical-align: middle; }

#container-new-article { 
    padding: 20px;
    box-shadow: 0 0 1px rgba(0,0,0,.125),0 1px 3px rgba(0,0,0,.2); 
    border-top: 8px solid #fac863;
}
@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-news -->
<section id="section-news" class="ptb-60">
    <div class="container">
        <div class="row justify-content-center mb-4">
            <div class="col-md-12 mb-3 text-center">
                <i class='bx bx-news title-icon icon-dark mb-2' ></i>
                <h2 class="section-title title-dark">Edit News Article</h2>
            </div>
        </div> <!-- row end -->

        <!-- news builder -->
        <div class="row justify-content-center mb-5">
            <form id="form-article-edit" action="/news/update" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="update_article">
                <input type="hidden" name="old_image" value="<?php echo e($news->image); ?>">
                <input type="hidden" name="news_id" value="<?php echo e($news->id); ?>">
                <div id="container-new-article" class="col-md-12">
                    <h3 class="mb-3"><i class='bx bx-edit mr-4'></i> Edit Article</h3>
                    <!-- date and author -->
                    <div class="form-group d-flex mb-4">
                        <div class="col">
                            <label for="date" class="form-label">Date</label>
                            <input type="text" name="date" class="form-control" value="<?php echo e(date('l, d F Y', strtotime($news->created_at))); ?>" disabled>
                        </div>
                        <span>&ensp;</span>
                        <div class="col">
                            <label for="author" class="form-label">Author</label>
                            <input type="text" name="author" class="form-control" value="<?php echo e($news->author); ?>" placeholder="Author" required>
                        </div>
                    </div>
                    <!-- date and author end -->
                    <!-- title -->
                    <div class="form-floating mb-4">
                        <input type="text" name="title" class="form-control" placeholder="Title" value="<?php echo e($news->title); ?>" required>
                        <label for="title" class="form-label">Title</label>
                    </div>
                    <!-- title end  -->
                    <!-- image -->
                    <div class="form-group text-center mb-3">
                        <label class="form-label">Featured image</label>
                        <label for="article-image">
                            <?php if($news->image != null): ?>
                            <img id="article-image-preview" class="w-50 box-shadow-2" src="<?php echo e(asset('img/news/'.$news->image)); ?>">
                            <?php else: ?>
                            <img id="article-image-preview" class="w-50 box-shadow-2" src="<?php echo e(asset('img/news/default.jpg')); ?>">
                            <?php endif; ?>
                        </label>
                        <input class="form-control form-input d-none" type="file" name="image" id="article-image">
                    </div>
                    <!-- image end  -->
                    <!-- content -->
                    <div class="form-group mb-3">
                        <label for="content" class="form-label">Content</label>
                        <textarea id="article-content" name="content"><?php echo e($news->content); ?></textarea>
                    </div>
                    <!-- content end -->
                    <!-- keywords -->
                    <div class="form-group mb-4">
                        <label for="keywords" class="form-label">Keywords</label>
                        <textarea id="article-keywords" name="keywords" class="form-control" placeholder="keywords, goes, here"><?php echo e($news->keywords); ?></textarea>
                    </div>
                    <!-- keywords end -->
                    <!-- button -->
                    <div class="form-group d-flex justify-content-end mb-3">
                        <button id="btn-article-reset" class="btn btn-secondary mr-8"><i class="bx bx-reset"></i> Reset</button>
                        <a class="btn btn-danger btn-warn mr-8" href="/news/delete/<?php echo e($news->id); ?>"><i class="bx bx-trash-alt"></i> Delete</a>
                        <button role="submit" type="submit" class="btn btn-primary mr-8"><i class="bx bx-edit-alt"></i> Update</button>
                    </div>
                    <!-- button end -->
                </div>
            </form>
        </div> <!-- row end -->
        <!-- news builder end -->

    </div>
</section>
<!-- section-news end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script type="text/javascript">
const lightbox = GLightbox({
    touchNavigation: true,
    loop: true,
    autoplayVideos: true
});
$(document).ready(function(){
    tinymce.init({
        selector: '#article-content',
        plugins: 'advlist autolink lists link charmap preview anchor pagebreak',
    });

    $('#article-image').change(function(){
        let reader = new FileReader();
        reader.onload = (e) => { 
            $('#article-image-preview').attr('src', e.target.result); 
        }
        reader.readAsDataURL(this.files[0]); 
    }); 
    $('.nav-link').removeClass('active');
    $('.nav-link-admin').addClass('active');
});
</script>
<script src="<?php echo e(asset('/js/ajax_news.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/news/edit.blade.php ENDPATH**/ ?>