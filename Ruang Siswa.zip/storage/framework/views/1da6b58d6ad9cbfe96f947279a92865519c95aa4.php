<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta content="Learning Management System by Sprachschule Mitra Leipzig" name="description">
<meta name="keywords" lan="en" content="Sprachschule Mitra Leipzig, LMS, Learning Management System, JournalSML" />
<meta property="og:title" content="JournalSML" />
<meta property="og:image" content="<?php echo e(asset('img/bg/mitraleipzig-min.png')); ?>" />
<meta property="og:image:type" content="image/png" />
<meta property="og:image:width" content="1366" />
<meta property="og:image:height" content="768" />

<meta name="twitter:image" content="<?php echo e(asset('img/bg/mitraleipzig-min.png')); ?>">

<!-- Vendor JS Files -->
<!-- <script src="<?php echo e(asset('/vendor/jquery/jquery-3.6.0.min.js')); ?>"></script> -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.1.1.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>Sprachschule Mitra Leipzig</title>
  
<?php echo $__env->yieldPushContent('css-styles'); ?>
<style>
  #section-footer { background: #272829; }
  #section-footer p { margin: 0; font-size: 11pt; color: #f1f1f1; }
</style>
</head>
<body>
<!-- ======= Mobile nav toggle button ======= -->
<!-- <i class="bi bi-list mobile-nav-toggle d-xl-none"></i> -->

<!-- ======= Header ======= -->
<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======= Header end ======= -->

<!-- ======= Main content ======= -->
<main id="main">
<?php echo $__env->yieldContent('content'); ?> <!-- Contents here! -->

<!-- include('layouts.partials.footer') ======= Footer ======= -->
</main>
<!-- ======= Main content end ======= -->

<!-- <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a> -->

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>


<script type="text/javascript">
$(document).ready(function(){
  $('.popper').popover({ // require popper.js
      trigger: 'hover',
      html: true,
      placement: 'bottom',
      container: 'body'
  });
  <?php if(Route::currentRouteName() != 'index'): ?>
    var navbarHeight = $('#navbar').outerHeight();
    $('#main').css('padding-top',navbarHeight);
  <?php endif; ?>
  <?php if(session('success')): ?>
    successMessage("<?php echo e(session('success')); ?>");
  <?php elseif(session('error')): ?>
    errorMessage("<?php echo e(session('error')); ?>");
  <?php endif; ?>
  <?php if(isset($_GET['admin']) == 'false'): ?>
    Swal.fire({
      icon: 'error',
      title: "Access Denied!",
      text: "You are not an admin!",
      showConfirmButton: false,
      timer: 2000
    });
  <?php endif; ?>
  
});
  function successMessage(message) {
      toastr.success(message, 'Success!');
  } 
  function infoMessage(message) {
      toastr.info(message, 'Info');
  } 
  function warningMessage(message) {
      toastr.error(message, 'Warning!');
  } 
  function errorMessage(message) {
      toastr.error(message, 'Error!');
  } 
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/layouts/master.blade.php ENDPATH**/ ?>