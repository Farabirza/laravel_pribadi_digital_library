

<?php $__env->startPush('css-styles'); ?>
<style>
#container-cover_image {
    background-position: fixed;
    background-size: cover;
}
</style>
<?php if(Auth::user()->profile->cover_image != null): ?>
<style>
#container-cover_image {  background: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), url("<?php echo e(asset('img/covers/'.Auth::user()->profile->cover_image)); ?>") center; }
</style>
<?php else: ?>
<style>
#container-cover_image { background: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), url("<?php echo e(asset('img/materials/1280x720.jpg')); ?>") center; }
</style>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-edit_profile" class="py-5 bg-white">
    <div class="container">
        <div class="row bg-white p-4 rounded shadow mb-4">
            <div class="col-md-12">
                <h2 class="section-title mb-4">Profile Data</h2>

                <div class="mb-3">
                    <label class="form-label">Profile and cover image</label>
                    <div id="container-cover_image" class="px-4 py-5 text-center rounded">
                        <label for="input-user-picture">
                        <?php if(Auth::user()->profile->cover_image != null): ?>
                        <img id="config-user-picture" src="<?php echo e(asset('img/profiles/'.Auth::user()->picture)); ?>" class="rounded rounded-circle shadow popper" style="max-height:160px;" type="button" title="change profile image">
                        <?php else: ?>
                        <img id="config-user-picture" src="<?php echo e(asset('img/profiles/user.jpg')); ?>" class="rounded rounded-circle shadow popper" style="max-height:160px;" type="button" title="change profile image">
                        <?php endif; ?>
                        </label>
                        <input id="input-user-picture" class="absolute d-none" name="input-user-picture" type="file" accept="image/*">
                        <p class="mt-4 mb-0">
                            <label for="config-cover_image" class="btn btn-sm btn-light"><span class="d-flex align-items-center"><i class="bx bx-image-alt me-2"></i>Change cover image</span></label>
                        </p>
                    </div>
                </div>

                <!-------------------------- form profile start -------------------------->
                <form id="form-profile" action="ajax/profile/<?php echo e($profile->id); ?>" method="put" class="m-0">
                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name*</label>
                    <input type="text" name="full_name" class="form-control form-control-sm mb-2" placeholder="full name" value="<?php echo e($profile->full_name); ?>">
                    <p class="fs-9 text-muted fst-italic mb-3">*) required</p>
                    <p id="alert-full_name" class="alert alert-danger d-none mb-3"></p>
                </div>
                <div class="d-flex flex-remove-md gap-3 mb-3">
                    <div class="col">
                        <label for="gender" class="form-label">Gender*</label>
                        <select name="gender" id="profile-gender" class="form-control form-select mb-2" required>
                            <option value="select" selected disabled hidden>Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                        <p class="mb-2 fs-9 text-muted fst-italic">*) required</p>
                    <p id="alert-gender" class="alert alert-danger d-none mb-3"></p>
                    </div>
                    <div class="col">
                        <label for="birth_date" class="form-label">Birth date</label>
                        <input type="date" min="1950-01-01" max="<?php echo e(date('Y-m-d', time())); ?>" id="profile-birth_date" class="form-control" name="birth_date" value="<?php echo e($profile->birth_date); ?>">
                    </div>
                </div>
                <div class="mb-2">
                    <span class="text-primary fw-bold fs-11">Domicile</span>
                </div>
                <div class="d-flex flex-remove-md gap-3 mb-3">
                    <div class="col">
                        <label for="address_street" class="form-label fs-10">Street</label>
                        <input type="text" name="address_street" class="form-control" placeholder="street" value="<?php echo e($profile->address_street); ?>">
                    </div>
                    <div class="col">
                        <label for="address_city" class="form-label fs-10">City</label>
                        <input type="text" name="address_city" class="form-control" placeholder="ex: Jakarta" value="<?php echo e($profile->address_city); ?>">
                    </div>
                </div>
                <div class="d-flex flex-remove-md gap-3 mb-3">
                    <div class="col">
                        <label for="address_state" class="form-label fs-10">State</label>
                        <input type="text" name="address_state" class="form-control" placeholder="ex: Indonesia" value="<?php echo e($profile->address_state); ?>">
                    </div>
                    <div class="col">
                        <label for="address_zip" class="form-label fs-10">ZIP code</label>
                        <input type="number" class="form-control" name="address_zip" placeholder="ZIP" value="" maxlength="5" value="<?php echo e($profile->address_zip); ?>">
                    </div>
                </div>
                <div class="d-flex flex-remove-md gap-3 mb-3">
                    <div class="col">
                        <label for="profile-languange" class="form-label">Languange</label>
                        <input type="text" name="languange" id="profile-languange" class="form-control form-control-sm mb-2" placeholder="ex: English, Spanish" value="<?php echo e($profile->languange); ?>">
                        <p class="mb-2 fs-9 text-muted fst-italic">*) use coma ',' as separator</p>
                        <p id="alert-languange" class="alert alert-danger d-none mb-3"></p>
                    </div>
                    <div class="col">
                        <label for="profile-interest" class="form-label">Interest</label>
                        <input type="text" name="interest" id="profile-interest" class="form-control form-control-sm mb-2" placeholder="ex: Artificial Intelligence, Traveling" value="<?php echo e($profile->interest); ?>">
                        <p class="mb-2 fs-9 text-muted fst-italic">*) use coma ',' as separator</p>
                        <p id="alert-interest" class="alert alert-danger d-none mb-3"></p>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="biodata" class="form-label">Biodata</label>
                    <textarea name="biodata" id="biodata" cols="30" rows="4" class="form-control" placeholder="tell us about yourself" value="<?php echo e($profile->biodata); ?>"></textarea>
                </div>

                
                <div class="d-flex justify-content-center py-4">
                    <div style="width:100%; border-bottom: 1px dashed #202020;"></div>
                </div>
                
                <h2 class="section-title my-4">Social Media</h2>

                <!-- email -->
                <div class="form-group mb-4">
                    <label class="form-label mb-2">Email*</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#BB001B"><i class='bx bx-envelope'></i></span>
                        <input type="text" name="email" class="form-control form-control-sm" placeholder="Email" value="<?php echo e($profile->email); ?>">
                    </div>
                    <p class="fst-italic text-muted fs-11 mb-0">*) this will be displayed on your page</p>
                    <p id="alert-email" class="alert alert-danger d-none mb-3"></p>
                </div>
                <!-- email end -->

                <!-- linkedin -->
                <div class="form-group mb-4">
                    <label class="form-label mb-2">LinkedIn</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#0e76a8"><i class='bx bxl-linkedin'></i></span>
                        <input type="text" name="li_name" class="form-control form-control-sm" placeholder="username" value="<?php echo e($profile->li_name); ?>">
                        <p id="alert-li_name" class="alert alert-danger d-none mb-3"></p>
                    </div>
                    <input type="text" name="li_url" class="form-control form-control-sm" placeholder="profile URL" value="<?php echo e($profile->li_url); ?>">
                    <p id="alert-li_url" class="alert alert-danger d-none mb-3"></p>
                </div>
                <!-- linkedin end -->

                <!-- twitter -->
                <div class="form-group mb-4">
                    <label class="form-label mb-2">Twitter</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#1DA1F2"><i class='bx bxl-twitter'></i></span>
                        <input type="text" name="tw_name" class="form-control form-control-sm" placeholder="username" value="<?php echo e($profile->tw_name); ?>">
                        <p id="alert-tw_name" class="alert alert-danger d-none mb-3"></p>
                    </div>
                    <input type="text" name="tw_url" class="form-control form-control-sm" placeholder="profile URL" value="<?php echo e($profile->tw_url); ?>">
                    <p id="alert-tw_url" class="alert alert-danger d-none mb-3"></p>
                </div>
                <!-- linkedin end -->

                <!-- instagram -->
                <div class="form-group mb-4">
                    <label class="form-label mb-2">Instagram</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#dd2a7b"><i class='bx bxl-instagram'></i></span>
                        <input type="text" name="ig_name" class="form-control form-control-sm" placeholder="username" value="<?php echo e($profile->ig_name); ?>">
                        <p id="alert-ig_name" class="alert alert-danger d-none mb-3"></p>
                    </div>
                    <input type="text" name="ig_url" class="form-control form-control-sm" placeholder="profile URL" value="<?php echo e($profile->ig_url); ?>">
                    <p id="alert-ig_url" class="alert alert-danger d-none mb-3"></p>
                </div>
                <!-- instagram end -->

                <!-- facebook -->
                <div class="form-group mb-4">
                    <label class="form-label mb-2">Facebook</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#3b5998"><i class='bx bxl-facebook'></i></span>
                        <input type="text" name="fb_name" class="form-control form-control-sm" placeholder="username" value="<?php echo e($profile->fb_name); ?>">
                        <p id="alert-fb_name" class="alert alert-danger d-none mb-3"></p>
                    </div>
                    <input type="text" name="fb_url" class="form-control form-control-sm" placeholder="profile URL" value="<?php echo e($profile->fb_url); ?>">
                    <p id="alert-fb_url" class="alert alert-danger d-none mb-3"></p>
                </div>
                <!-- facebook end -->

                <!-- Website -->
                <div class="form-group mb-4">
                    <label class="form-label mb-2">Website</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#404040"><i class='bx bx-link-alt'></i></span>
                        <input type="text" name="web_name" class="form-control form-control-sm" placeholder="Site name" value="<?php echo e($profile->web_name); ?>">
                        <p id="alert-web_name" class="alert alert-danger d-none mb-3"></p>
                    </div>
                    <input type="text" name="web_url" class="form-control form-control-sm" placeholder="Site URL" value="<?php echo e($profile->web_url); ?>">
                    <p id="alert-web_url" class="alert alert-danger d-none mb-3"></p>
                </div>
                <!-- Website end -->
                <div class="d-flex align-items-center mb-3">
                    <hr class="col me-3"/>
                    <button type="button" class="btn btn-success d-flex align-items-center" onclick="submitProfile()"><i class='bx bxs-save me-2' ></i>Save</button>
                </div>
                </form>
                <!-------------------------- form profile end -------------------------->

            </div>
        </div>
    </div>
</section>

<!-- modal user picture cropper -->
<div class="modal fade" id="modal-user-picture-cropper" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center fw-semibold"><i class='bx bx-selection me-2'></i><span>Select Picture</span></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-md-8">
                            <img id="img-crop" src="">
                        </div>
                        <div class="col-md-4">
                            <div class="user-picture-cropper-preview mx-3 mb-3" style="overflow: hidden; height: 180px; border: 1px solid #404040"></div>
                            <p class="mb-0 mx-3 fs-11">Select and crop image</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary d-flex align-items-center" data-bs-dismiss="modal"><i class='bx bx-exit me-2' ></i>Cancel</button>
                <button type="button" class="btn btn-primary d-flex align-items-center" id="user-picture-crop"><i class='bx bx-crop me-2' ></i>Crop</button>
            </div>
        </div>
    </div>
</div>
<!-- modal user picture cropper end -->

<!-- modal cover image start cropper -->
<div class="modal fade" id="modal-cover_image" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center fw-semibold"><i class='bx bx-image-alt me-2'></i><span>Cover Image</span></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="action/profile" method="post" id="form-cover_image" class="m-0">
                <img id="preview-cover_image" src="" class="rounded mb-3">
                <input type="file" name="cover_image" accept="image/*" id="config-cover_image" class="form-control mb-2">
                <p class="mb-2 fs-9 text-muted fst-italic">*) maximum file size: 2 MB</p>
                <p class="mb-2 fs-9 text-muted fst-italic">*) recommended aspect ratio: 16:9 or 1920x1080px</p>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary d-flex align-items-center" data-bs-dismiss="modal"><i class='bx bx-exit me-2' ></i>Cancel</button>
                <button type="button" class="btn btn-primary d-flex align-items-center" onclick="submitCover()"><i class='bx bx-save me-2' ></i>Save</button>
            </div>
        </div>
    </div>
</div>
<!-- modal cover image cropper end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/js/ScriptConfig.js')); ?>"></script>
<script type="text/javascript">
function submitProfile() {
    $('.alert').hide();
    var formData = $('#form-profile').serialize();
    var config = {
        method: $('#form-profile').attr('method'), url: domain + $('#form-profile').attr('action'),
        data: formData,
    }
    axios(config)
    .then((response) => {
        successMessage(response.data.message);
    })
    .catch((error) => {
        console.log(error.response);
        if(error.response) {
            let response = error.response.data;
            if(response.errors) {
                if(response.errors.full_name) { $('#alert-full_name').html(response.errors.full_name).removeClass('d-none').hide().fadeIn('slow'); }
                if(response.errors.gender) { $('#alert-gender').html(response.errors.gender).removeClass('d-none').hide().fadeIn('slow'); }
            }
        }
    });
};

$('[name="gender"] option[value="'+'<?php echo e($profile->gender); ?>'+'"]').prop('selected', true);
$(document).ready(function() {
    $('#submenu-edit').addClass('show');
    $('#link-edit_profile').addClass('active');
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif 2.0\cvkreatif.com\resources\views/dashboard/edit_profile.blade.php ENDPATH**/ ?>