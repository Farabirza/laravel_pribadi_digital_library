
<header id="header">
  <div class="d-flex flex-column">

      <div class="header-logo"><a href="/books">
          <h5><b>Digital</b> Library</h5>
      </a></div>

      <div class="profile">
        <img src="<?php echo e(asset('/img/logo/logo.png')); ?>" alt="" class="">
      </div>

    <nav id="navbar" class="nav-menu navbar">
      <ul>
        <li id="link-books" class="nav-link active"><i class="bx bxs-book"></i> <span role="button" data-bs-toggle="collapse" data-bs-target="#submenu-books" aria-expanded="true" aria-controls="submenu-books">Books <i class='bx bx-chevron-down nav-drop'></i></span></li>
        <ul class="collapse show nav-submenu" id="submenu-books">
            <li class="nav-list"><a href="/index <?php if(Route::is('books.index')): ?> #section-thumbnails <?php endif; ?>" class='scrollto'>Books index</a></li>
            <?php if(Route::is('books.index')): ?>
            <li class="nav-list"><a href='/books #section-most_visited' class='scrollto'>Most visited</a></li>
            <li class="nav-list"><a href='/books #section-reviews' class='scrollto'>Recent reviews</a></li>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->role != 'user'): ?>
            <li class="nav-list"><hr class="dropdown-divider"></li>
            <li class="nav-list"><a href='/books/create' class='scrollto'>Submit new book</a></li>
            <?php endif; ?>
            <?php endif; ?>
        </ul>
        <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->role != 'user'): ?>
        <li id="link-dashboard" class="nav-link"><i class="bx bxs-dashboard"></i> <span role="button" data-bs-toggle="collapse" data-bs-target="#submenu-dashboard" aria-expanded="false" aria-controls="submenu-dashboard">Admin Dashboard <i class='bx bx-chevron-down nav-drop'></i></span></li>
        <ul class="collapse nav-submenu" id="submenu-dashboard">
            <?php $route_dashboard = 'App\Http\Controllers\AdminController@dashboard' ?>
            <?php $route_statistics = 'App\Http\Controllers\AdminController@statistics' ?>
            <?php if(Route::currentRouteAction() == $route_dashboard): ?>
            <li class="nav-list"><a href="/dashboard <?php if(Route::currentRouteAction() == $route_dashboard): ?> #section-users <?php endif; ?>" class="scrollto">Users</a></li>
            <li class="nav-list"><a href="/dashboard <?php if(Route::currentRouteAction() == $route_dashboard): ?> #section-books <?php endif; ?>" class="scrollto">Books</a></li>
            <li class="nav-list"><a href="/dashboard <?php if(Route::currentRouteAction() == $route_dashboard): ?> #section-categories <?php endif; ?>" class="scrollto">Categories</a></li>
            <li class="nav-list"><a href="/dashboard <?php if(Route::currentRouteAction() == $route_dashboard): ?> #section-records <?php endif; ?>" class="scrollto">Logs</a></li>
            <li class="nav-list"><hr class="dropdown-divider"></li>
            <li class="nav-list"><a href='/statistics'>Statistics</a></li>
            <?php elseif(Route::currentRouteAction() == $route_statistics): ?>
            <li class="nav-list"><a href='/dashboard'>Dashboard</a></li>
            <li class="nav-list"><hr class="dropdown-divider"></li>
            <li class="nav-list"><a href="/dashboard <?php if(Route::currentRouteAction() == $route_statistics): ?> #section-book_charts <?php endif; ?>" class="scrollto">Charts</a></li>
            <li class="nav-list"><a href="/dashboard <?php if(Route::currentRouteAction() == $route_statistics): ?> #section-books_performance <?php endif; ?>" class="scrollto">Performance</a></li>
            <?php else: ?>
            <li class="nav-list"><a href='/dashboard'>Dashboard</a></li>
            <li class="nav-list"><a href='/statistics'>Statistics</a></li>
            <?php endif; ?>
        </ul>
        <?php endif; ?>
        <?php endif; ?>
      </ul>
    </nav>

  </div>
</header>

<!-- ======= section header ======= -->
<section id="section-header">
  <div id="inner-header" class="container-fluid vertical-center">
    <div id="user-data" class="d-flex vertical-center">
      <?php if(auth()->guard()->check()): ?>
      <a href="/profile"><img src="<?php echo e(asset('/img/profiles/'.Auth::user()->profile->image)); ?>" id="user-img" alt="" class="img-fluid rounded-circle"></a>
      <a href="/profile"><span id="user-name"><?php echo e(Auth::user()->profile->first_name); ?> <?php echo e(Auth::user()->profile->last_name); ?></span></a> | <span id="user-role"><?php echo e(ucfirst(Auth::user()->role)); ?></span>
      <?php endif; ?>
      <?php if(auth()->guard()->guest()): ?>
      <img src="<?php echo e(asset('/img/icons/male.png')); ?>" id="user-img" alt="" class="img-fluid rounded-circle">
      <span id="user-name">Guest</span>
      <?php endif; ?>
      <i id="user-icon" class='bx bx-chevron-down' type="button" id="user-menu" data-bs-toggle="dropdown" aria-expanded="false"></i>
      <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="user-menu">
        <?php if(auth()->guard()->check()): ?>
        <li><a class="dropdown-item" href="/profile">Profile</a></li>
        <li><a class="dropdown-item feedback" href="<?php echo e(Auth::user()->id); ?>">Message Admin</a></li>
        <li><a class="dropdown-item" href="/logout">Log out</a></li>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
        <li><a class="dropdown-item" href="/login">Log in</a></li>
        <li><a class="dropdown-item" href="/register">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</section>
<!-- ======= section header end ======= -->


<!-- Modal Message Admin -->
<div class="modal fade" id="modal-feedback" aria-hidden="true"> 
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="/feedback" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="user_id" name="user_id">
        <div class="modal-header">
          <h4 class="modal-title">Message Admin</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">Message</label>
            <textarea name="message" id="feedback-message" rows="3" class="form-control" placeholder="Message"></textarea>
          </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Cancel</button>
            <button type="submit" class="btn btn-primary" id="update-assignment"><i class='bx bx-mail-send' ></i> Send Message</button>
        </div>
      </form>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/layouts/partials/header_alt.blade.php ENDPATH**/ ?>