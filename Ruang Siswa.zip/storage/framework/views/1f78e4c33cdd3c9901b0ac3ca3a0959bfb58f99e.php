<section id="section-topbar" class="py-2 bg-dark" style="color:#37b3ed">
    <div class="container">
        <div class="d-flex justify-content-between">
            <div>
                <a href="" class="me-3"><i class='bx bx-buildings me-1' ></i> Tentang kami</a>
                <a href="" class="me-3"><i class='bx bx-message-dots me-1' ></i> Kontak</a>
            </div>
            <a href=""><i class='bx bxl-discord-alt me-1' ></i> Gabung Discord</a>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/layouts/partials/topbar.blade.php ENDPATH**/ ?>