

<?php $__env->startPush('css-styles'); ?>
<style>
body { background: #f1f1f1; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-verify" class="py-4">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 bg-white p-4 rounded shadow text-center">
                <?php if(session('resent')): ?>
                <div class="alert alert-success mb-3" role="alert">
                    <h5>Verification email sent</h5>
                    <p class="mb-0 fs-11">An email has been sent to your email, check your email to continue the verification process.</p>
                </div>
                <?php endif; ?>
                <img src="<?php echo e(asset('img/materials/mail-open.png')); ?>" alt="" class="mb-3" style="max-height: 120px">
                <h3 class="display-5 fs-32 mb-3">Verify your email</h3>
                <?php if(!session('resent')): ?>
                <p class="fs-11">We've send an email to <span class="text-primary fst-italic"><?php echo e(Auth::user()->email); ?></span> to verify your email address and activate your account. The link in the email will expire in 24 hours.</p>
                <?php endif; ?>
                <form id="resendVerification" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(session('resent')): ?>
                <p class="fs-11"><span class="text-primary fw-bold hover-pointer" onclick="resendVerification()">Click here</span> to resend if you did not receive the email.</p>
                <?php else: ?>
                <p class="fs-11"><span class="text-primary fw-bold hover-pointer" onclick="resendVerification()">Click here</span> to resend if you did not receive the email.</p>
                <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
$(document).ready(function(){
});

const resendVerification = () => {
    $('#resendVerification').submit();
}

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif 2.0\cvkreatif.com\resources\views/auth/verify.blade.php ENDPATH**/ ?>