

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/cropper/cropper.min.css')); ?>" rel="stylesheet">
<style>
body { background: #f9f9f9; min-height: 100vh; }
.alert { font-size: 10pt; }
.progress-container { gap: 3rem; }
.progress-list { 
    letter-spacing: 1px;
    font-weight: 600;
    font-size: 12pt;
    color: #374785;
 }
.progress-list-active .progress-icon, .progress-icon:hover  {
    background: #374785;
    color: #fff;
    transition: ease-in-out .3s;
    cursor: pointer;
}
.progress-icon {
    padding: 10px;
    border-radius: 50%;
    margin-bottom: 10px;
    font-size: 2.4rem;
    border: 2px solid #374785;
    color: #374785;
}
.progressbar-line {
	height: 2px;
    min-width: 40px;
	border-top: 2px solid #374785;
    margin-left: 12px;
    margin-right: 12px;
}

/* education start */
.education-item, .wh-item { border-bottom: 1px dashed #404040; }
.education-item .item-title { font-weight: 600; font-size: 22pt; text-transform: uppercase; letter-spacing: 1px; color: #202020; }
/* education end */

/* config start */
#container-cover_image {
    background-position: fixed;
    background-size: cover;
}
/* config end */

@media (max-width: 1199px) {
    .progress-container { gap: 1.4rem; }
    .progress-icon { padding: 8px; border: 1px solid #374785; font-size: 1.8rem; }
}
@media (max-width: 768px) {
    .progress-list { letter-spacing: .2; font-weight: 400; font-size: 8pt; }
    .progressbar-line, .progress-title { display: none; }
}
</style>

<?php if(Auth::user()->profile && Auth::user()->profile->cover_image != null): ?>
<style>
/* config start */
#container-cover_image { 
    background: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), url("<?php echo e(asset('img/covers/'.Auth::user()->profile->cover_image)); ?>") center; 
    background-size: cover;
}
/* config end */
</style>
<?php else: ?>
<style>
/* config start */
#container-cover_image { background: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), url("<?php echo e(asset('img/materials/1280x720.jpg')); ?>") center; }
/* config end */
</style>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-wizard" class="px-3 py-5">
    <div class="container">
        <div class="row justify-content-center bg-white py-5 rounded shadow">
            <div class="col-md-10 d-flex flex-wrap justify-content-center align-items-center mb-3 progress-container">
                <div id="progress-list-profile" class="text-center progress-list progress-list-active" role="button" onclick="navWizard('profile', 20)">
                    <i class='bx bxs-user progress-icon'></i>
                    <p class="progress-title">Profile</p>
                </div>
                <div class="fs-18" style="color:#374785"><i class='bx bx-chevron-right'></i></div>
                <div id="progress-list-education" class="text-center progress-list" role="button" onclick="navWizard('education', 40)">
                    <i class='bx bxs-graduation progress-icon'></i>
                    <p class="progress-title">Education</p>
                </div>
                <div class="fs-18" style="color:#374785"><i class='bx bx-chevron-right'></i></div>
                <div id="progress-list-experience" class="text-center progress-list" role="button" onclick="navWizard('experience', 60)">
                    <i class='bx bxs-briefcase progress-icon'></i>
                    <p class="progress-title">Experience</p>
                </div>
                <div class="fs-18" style="color:#374785"><i class='bx bx-chevron-right'></i></div>
                <div id="progress-list-skill" class="text-center progress-list" role="button" onclick="navWizard('skill', 80)">
                    <i class='bx bxs-brush progress-icon'></i>
                    <p class="progress-title">Skill</p>
                </div>
                <div class="fs-18" style="color:#374785"><i class='bx bx-chevron-right'></i></div>
                <div id="progress-list-config" class="text-center progress-list" role="button" onclick="navWizard('config', 100)">
                    <i class='bx bxs-cog progress-icon'></i>
                    <p class="progress-title">Config</p>
                </div>
            </div>
            <div class="col-md-10">
                <div class="progress">
                    <?php if(Auth::user()->profile): ?>
                    <div id="progress-bar-wizard" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
                    <?php else: ?>
                    <div id="progress-bar-wizard" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('dashboard.wizard.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.wizard.education', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.wizard.experience', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.wizard.skill', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.wizard.config', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/cropper/cropper.min.js')); ?>"></script>
<?php if(Auth::user()->profile): ?>
<script type="text/javascript">
var profile_exist = true;
</script>
<?php else: ?>
<script type="text/javascript">
var profile_exist = false;
</script>
<?php endif; ?>
<script type="text/javascript">
$(document).ready(function() {
    $('#link-wizard').addClass('active');
});

const navWizard = (destination, progress) => {
    if(profile_exist) {
        $('.progress-list').removeClass('progress-list-active');
        $('#progress-list-'+destination).addClass('progress-list-active');
        $('.section-wizard').hide();
        $('#section-wizard-'+destination).removeClass('d-none').slideDown('slow');
        $('#progress-bar-wizard').animate({width: progress+'%'}, 'fast').attr('aria-valuenow', progress);
    } else {
        return infoMessage('Please save the profile data to continue');
    }
};
</script>
<script src="<?php echo e(asset('/js/ScriptEducation.js')); ?>"></script>
<script src="<?php echo e(asset('/js/ScriptExperience.js')); ?>"></script>
<script src="<?php echo e(asset('/js/ScriptSkill.js')); ?>"></script>
<script src="<?php echo e(asset('/js/ScriptConfig.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif 2.0\cvkreatif.com\resources\views/dashboard/wizard.blade.php ENDPATH**/ ?>