<?php if(auth()->guard()->guest()): ?>
<?php header("Location: /?login=required"); die(); ?>
<?php endif; ?>



<?php $__env->startPush('css-styles'); ?>
<style>
#main { min-height: 100vh; background: #f9f9f9; }
.bl-darkblue-md { color: #374785; }
@media (max-width: 768px) {
    #section-form { padding-top: 20px; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-form" class="py-40">
    <div class="container">
        <?php echo $__env->make('cv.partials.wizard_progressbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('cv.partials.wizard_disclaimer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-------- form start -------->
        <form id="form-work_history" method="POST">

        <div class="row align-items-center"> <!-- row start -->
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold ps-3 fs-32 bl-darkblue-md">Riwayat Pekerjaan</h3>
            </div>
            <div class="col-md-12"> <!-- col form start -->
                
            <!-- work history  -->
            <div class="wh-container mb-4">

                <?php $i = 1; ?>
                <?php $__empty_1 = true; $__currentLoopData = $work_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div id="wh-list-item-<?php echo e($i); ?>" class="accordion shadow-sm">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="wh-heading-<?php echo e($i); ?>">
                        <div class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#wh-collapse-<?php echo e($i); ?>" aria-expanded="false" aria-controls="wh-collapse-<?php echo e($i); ?>">
                            <span class="text-primary me-2"><?php echo e($i); ?>.</span>
                            <span class="me-2"><?php echo e($wh->year_start); ?> <?php if(isset($wh->year_end)): ?> - <?php echo e($wh->year_end); ?> <?php endif; ?></span> |
                            <?php if(isset($wh->work_place)): ?><span class="fw-bold ms-2"><?php echo e($wh->work_place); ?></span><?php endif; ?>
                        </div>
                        </h2>
                        <div id="wh-collapse-<?php echo e($i); ?>" class="accordion-collapse collapse" aria-labelledby="wh-heading-<?php echo e($i); ?>" data-bs-parent="#wh-list-item-<?php echo e($i); ?>">
                            <div class="accordion-body">
                                <!-- ============================================= accordion body start ======================================== -->
                                <input type="hidden" name="wh_id-<?php echo e($i); ?>" value="<?php echo e($wh->id); ?>">
                                <div class="form-group col">
                                    <div class="d-flex mb-2 flex-remove-md">
                                        <div class="d-flex col align-middle align-items-center mb-2">
                                            <div class="form-floating col">
                                                <select name="month_start-<?php echo e($i); ?>" class="form-control form-select" required>
                                                    <?php if(isset($wh->month_start)): ?>
                                                    <option value="january" <?php if($wh->month_start === 'january'): ?> selected <?php endif; ?>>Januari</option>
                                                    <option value="february" <?php if($wh->month_start === 'february'): ?> selected <?php endif; ?>>Februari</option>
                                                    <option value="march" <?php if($wh->month_start === 'march'): ?> selected <?php endif; ?>>Maret</option>
                                                    <option value="april" <?php if($wh->month_start === 'april'): ?> selected <?php endif; ?>>April</option>
                                                    <option value="may" <?php if($wh->month_start === 'may'): ?> selected <?php endif; ?>>Mei</option>
                                                    <option value="june" <?php if($wh->month_start === 'june'): ?> selected <?php endif; ?>>Juni</option>
                                                    <option value="july" <?php if($wh->month_start === 'july'): ?> selected <?php endif; ?>>Juli</option>
                                                    <option value="august" <?php if($wh->month_start === 'august'): ?> selected <?php endif; ?>>Agustus</option>
                                                    <option value="september" <?php if($wh->month_start === 'september'): ?> selected <?php endif; ?>>September</option>
                                                    <option value="october" <?php if($wh->month_start === 'october'): ?> selected <?php endif; ?>>Oktober</option>
                                                    <option value="november" <?php if($wh->month_start === 'november'): ?> selected <?php endif; ?>>November</option>
                                                    <option value="desember" <?php if($wh->month_start === 'desember'): ?> selected <?php endif; ?>>Desember</option>
                                                    <?php else: ?>
                                                    <option value="january">Januari</option>
                                                    <option value="february">Februari</option>
                                                    <option value="march">Maret</option>
                                                    <option value="april">April</option>
                                                    <option value="may">Mei</option>
                                                    <option value="june">Juni</option>
                                                    <option value="july">Juli</option>
                                                    <option value="august">Agustus</option>
                                                    <option value="september">September</option>
                                                    <option value="october">Oktober</option>
                                                    <option value="november">November</option>
                                                    <option value="desember">Desember</option>
                                                    <?php endif; ?>
                                                </select>
                                                <label for="month_start-<?php echo e($i); ?>" class="form-label">Bulan bergabung</label>
                                            </div>
                                            <span>&ensp;</span>
                                            <div class="form-floating col">
                                                <input type="number" class="form-control" name="year_start-<?php echo e($i); ?>" placeholder="Tahun bergabung" value="<?php echo e($wh->year_start); ?>" required>
                                                <label for="year_start-<?php echo e($i); ?>" class="form-label">Tahun bergabung</label>
                                            </div>
                                        </div>
                                        <span class="remove-md mb-2" style="padding-top:20px;">&ensp;-&ensp;</span>
                                        <div class="d-flex col align-middle align-items-center mb-2">
                                            <div class="form-floating col">
                                                <select name="month_end-<?php echo e($i); ?>" class="form-control form-select">
                                                    <?php if(isset($wh->month_end)): ?>
                                                    <option value="january" <?php if($wh->month_end === 'january'): ?> selected <?php endif; ?>>Januari</option>
                                                    <option value="february" <?php if($wh->month_end === 'february'): ?> selected <?php endif; ?>>Februari</option>
                                                    <option value="march" <?php if($wh->month_end === 'march'): ?> selected <?php endif; ?>>Maret</option>
                                                    <option value="april" <?php if($wh->month_end === 'april'): ?> selected <?php endif; ?>>April</option>
                                                    <option value="may" <?php if($wh->month_end === 'may'): ?> selected <?php endif; ?>>Mei</option>
                                                    <option value="june" <?php if($wh->month_end === 'june'): ?> selected <?php endif; ?>>Juni</option>
                                                    <option value="july" <?php if($wh->month_end === 'july'): ?> selected <?php endif; ?>>Juli</option>
                                                    <option value="august" <?php if($wh->month_end === 'august'): ?> selected <?php endif; ?>>Agustus</option>
                                                    <option value="september" <?php if($wh->month_end === 'september'): ?> selected <?php endif; ?>>September</option>
                                                    <option value="october" <?php if($wh->month_end === 'october'): ?> selected <?php endif; ?>>Oktober</option>
                                                    <option value="november" <?php if($wh->month_end === 'november'): ?> selected <?php endif; ?>>November</option>
                                                    <option value="desember" <?php if($wh->month_end === 'desember'): ?> selected <?php endif; ?>>Desember</option>
                                                    <?php else: ?>
                                                    <option value="" selected disabled hidden>Bulan</option>
                                                    <option value="january">Januari</option>
                                                    <option value="february">Februari</option>
                                                    <option value="march">Maret</option>
                                                    <option value="april">April</option>
                                                    <option value="may">Mei</option>
                                                    <option value="june">Juni</option>
                                                    <option value="july">Juli</option>
                                                    <option value="august">Agustus</option>
                                                    <option value="september">September</option>
                                                    <option value="october">Oktober</option>
                                                    <option value="november">November</option>
                                                    <option value="desember">Desember</option>
                                                    <?php endif; ?>
                                                </select>
                                                <label for="month_end-<?php echo e($i); ?>" class="form-label">Bulan berhenti*</label>
                                            </div>
                                            <span>&ensp;</span>
                                            <div class="form-floating col">
                                                <input type="number" class="form-control" name="year_end-<?php echo e($i); ?>" placeholder="Tahun berhenti" value="<?php if(isset($wh->year_end)): ?><?php echo e($wh->year_end); ?><?php endif; ?>">
                                                <label for="year_end-<?php echo e($i); ?>" class="form-label">Tahun berhenti*</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex mb-3">
                                        <div class="form-floating col mb-1">
                                            <input type="text" class="form-control" name="work_place-<?php echo e($i); ?>" placeholder="Perusahaan" value="<?php if(isset($wh->work_place)): ?><?php echo e($wh->work_place); ?><?php endif; ?>" required>
                                            <label for="work_place-<?php echo e($i); ?>" class="form-label">Perusahaan</label>
                                        </div>
                                        <span>&ensp;</span>
                                        <div class="form-floating col mb-1">
                                            <select name="employment-<?php echo e($i); ?>" class="form-control form-select" required>
                                                <option value="full time" <?php if($wh->employment === 'full time'): ?> selected <?php endif; ?>>Full time</option>
                                                <option value="part time" <?php if($wh->employment === 'part time'): ?> selected <?php endif; ?>>Part time</option>
                                                <option value="self employed" <?php if($wh->employment === 'self employed'): ?> selected <?php endif; ?>>Self employed</option>
                                                <option value="freelance" <?php if($wh->employment === 'freelance'): ?> selected <?php endif; ?>>Freelance</option>
                                                <option value="contract" <?php if($wh->employment === 'contract'): ?> selected <?php endif; ?>>Contract</option>
                                                <option value="internship" <?php if($wh->employment === 'internship'): ?> selected <?php endif; ?>>Internship</option>
                                                <option value="apprenticeship" <?php if($wh->employment === 'apprenticeship'): ?> selected <?php endif; ?>>Apprenticeship</option>
                                                <option value="seasonal" <?php if($wh->employment === 'seasonal'): ?> selected <?php endif; ?>>Seasonal</option>
                                            </select>
                                            <label for="employment-<?php echo e($i); ?>" class="form-label">Tipe pekerjaan</label>
                                        </div>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" name="role-<?php echo e($i); ?>" placeholder="Peran" value="<?php if(isset($wh->role)): ?><?php echo e($wh->role); ?><?php endif; ?>" required>
                                        <label for="role-<?php echo e($i); ?>" class="form-label">Peran</label>
                                    </div>
                                    <div class="mb-3">
                                        <label for="description-<?php echo e($i); ?>" class="form-label text-secondary">Deskripsi*</label>
                                        <textarea name="description-<?php echo e($i); ?>" class="form-control mb-2" placeholder="Deskripsi singkat" style="height: 100px"><?php if(isset($wh->description)): ?><?php echo e($wh->description); ?><?php endif; ?></textarea>
                                        <span class="text-muted fst-italic fs-10">*gunakan simbol semicolon " ; " untuk membuat batas antar point</span>
                                    </div>
                                    <div class="text-end">
                                        <button type="button" class="btn btn-outline-danger btn-sm btn-wh-delete" data-item-id="<?php echo e($i); ?>" data-wh-id="<?php echo e($wh->id); ?>"><i class='bx bx-trash-alt' ></i> Hapus</button>
                                    </div>
                                </div>
                                <!-- ============================================= accordion body end ======================================== -->
                            </div>
                        </div>
                    </div>
                </div>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div id="wh-list-item-<?php echo e($i); ?>" class="d-flex flex-remove-md wh-list-item card bg-white p-4 shadow-sm mb-4"> <!-- item --> 
                    <input type="hidden" name="wh_id-<?php echo e($i); ?>" value="">
                    <div class="form-group col">
                        <div class="d-flex mb-2 flex-remove-md">
                            <div class="d-flex col align-middle align-items-center mb-2">
                                <div class="form-floating col">
                                    <select name="month_start-<?php echo e($i); ?>" class="form-control form-select" required>
                                        <option value="january">Januari</option>
                                        <option value="february">Februari</option>
                                        <option value="march">Maret</option>
                                        <option value="april">April</option>
                                        <option value="may">Mei</option>
                                        <option value="june">Juni</option>
                                        <option value="july">Juli</option>
                                        <option value="august">Agustus</option>
                                        <option value="september">September</option>
                                        <option value="october">Oktober</option>
                                        <option value="november">November</option>
                                        <option value="desember">Desember</option>
                                    </select>
                                    <label for="month_start-<?php echo e($i); ?>" class="form-label">Bulan bergabung</label>
                                </div>
                                <span>&ensp;</span>
                                <div class="form-floating col">
                                    <input type="number" class="form-control" name="year_start-<?php echo e($i); ?>" placeholder="Tahun bergabung" value="<?php echo e(old('year_start-'.$i)); ?>" required>
                                    <label for="year_start-<?php echo e($i); ?>" class="form-label">Tahun bergabung</label>
                                </div>
                            </div>
                            <span class="remove-md mb-2" style="padding-top:20px;">&ensp;-&ensp;</span>
                            <div class="d-flex col align-middle align-items-center mb-2">
                                <div class="form-floating col">
                                    <select name="month_end-<?php echo e($i); ?>" class="form-control form-select">
                                        <option value="" selected disabled hidden>Bulan</option>
                                        <option value="january">Januari</option>
                                        <option value="february">Februari</option>
                                        <option value="march">Maret</option>
                                        <option value="april">April</option>
                                        <option value="may">Mei</option>
                                        <option value="june">Juni</option>
                                        <option value="july">Juli</option>
                                        <option value="august">Agustus</option>
                                        <option value="september">September</option>
                                        <option value="october">Oktober</option>
                                        <option value="november">November</option>
                                        <option value="desember">Desember</option>
                                    </select>
                                    <label for="month_end-<?php echo e($i); ?>" class="form-label">Bulan berhenti*</label>
                                </div>
                                <span>&ensp;</span>
                                <div class="form-floating col">
                                    <input type="number" class="form-control" name="year_end-<?php echo e($i); ?>" placeholder="Tahun berhenti" value="<?php echo e(old('year_end-'.$i)); ?>">
                                    <label for="year_end-<?php echo e($i); ?>" class="form-label">Tahun berhenti*</label>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <div class="form-floating col mb-1">
                                <input type="text" class="form-control" name="work_place-<?php echo e($i); ?>" placeholder="Perusahaan" value="<?php echo e(old('work_place-'.$i)); ?>" required>
                                <label for="work_place-<?php echo e($i); ?>" class="form-label">Perusahaan</label>
                            </div>
                            <span>&ensp;</span>
                            <div class="form-floating col mb-1">
                                <select name="employment-<?php echo e($i); ?>" class="form-control form-select" required>
                                    <option value="full-time">Full time</option>
                                    <option value="part-time">Part time</option>
                                    <option value="self-employed">Self employed</option>
                                    <option value="freelance">Freelance</option>
                                    <option value="contract">Contract</option>
                                    <option value="internship">Internship</option>
                                    <option value="apprenticeship">Apprenticeship</option>
                                    <option value="seasonal">Seasonal</option>
                                </select>
                                <label for="employment-<?php echo e($i); ?>" class="form-label">Tipe pekerjaan</label>
                            </div>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" name="role-<?php echo e($i); ?>" placeholder="Peran" value="<?php echo e(old('role-'.$i)); ?>" required>
                            <label for="role-<?php echo e($i); ?>" class="form-label">Peran</label>
                        </div>
                        <div class="form-floating mb-1">
                            <textarea name="description-<?php echo e($i); ?>" class="form-control" placeholder="Deskripsi singkat" style="height: 100px"></textarea>
                            <label for="description-<?php echo e($i); ?>" class="form-label">Deskripsi</label>
                        </div>
                    </div>
                </div> <!-- item end -->
                <?php $i++; ?>
                <?php endif; ?>

            </div>
            <div class="wh-container-new"></div>
            <div class="mb-4">
                <div class="mb-4"><span class="text-muted fs-11 fst-italic">*Kosongkan bulan dan tahun berhenti apabila masih aktif</span></div>
                <div class="col text-center"><button type="button" class="btn btn-outline-primary w-100 btn-add-wh"><i class='bx bx-add-to-queue'></i> Tambahkan list</button></div>
            </div>
            <!-- work history end  -->

            </div> <!-- col form end -->
        </div> <!-- row end -->

        <div class="row"> <!-- row start -->
            <!-- form button -->
            <hr class="mb-3"/>
            <div class="form-group d-flex justify-content-end">
                <input type="hidden" name="count" value="<?php echo e($i); ?>">
                <button type="submit" class="btn btn-success me-2 disabled btn-form-save"><i class='bx bxs-save' ></i> Simpan</button>
                <a href="/wizard/education?from=60" class="btn btn-secondary me-2"><i class='bx bx-left-arrow-alt' ></i> Sebelumnya</a>
                <a href="/wizard/skill?from=60" class="btn btn-primary me-2"><i class='bx bx-right-arrow-alt' ></i> Selanjutnya</a>
            </div>
            <!-- form button end -->
        </div> <!-- row end -->

        </form>
        <!-------- form end -------->

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/js/ajax_wizard.js')); ?>"></script>
<script>
$(window).resize(function() {
    if($(window).width() < 992) {
        $('.flex-remove-md').removeClass('d-flex');
    } else {
        $('.flex-remove-md').removeClass('d-flex').addClass('d-flex');
    }
});
$(document).ready(function(){
    // Progressbar
    $('.progress-list').removeClass('progress-list-active');
    $('#progress-list-wh').addClass('progress-list-active');
    $('.progress-bar').css('width','60%').attr('aria-valuenow','60');

    // window size
    if($(window).width() < 992) {
        $('.flex-remove-md').removeClass('d-flex');
    } else {
        $('.flex-remove-md').removeClass('d-flex').addClass('d-flex');
    }
});

// Form
$('#form-work_history').change(function(e){
    $('.btn-form-save').removeClass('disabled');
});

// Work History
var wh_item_count = parseInt($("[name='count']").val());
$('.btn-add-wh').click(function(e){
    e.preventDefault();
    add_wh_item(wh_item_count);
    wh_item_count++;
    $('.btn-remove-item').click(function(e){
        e.preventDefault();
        let get_count = $(this).attr('data-count');
        $('#wh-list-item-' + get_count).remove();
    });
});
$('.btn-wh-delete').click(function(e){
    e.preventDefault();
    let item_id = $(this).attr('data-item-id');
    let wh_id = $(this).attr('data-wh-id');
      Swal.fire({
          title: 'Apakah anda yakin?',
          icon: 'warning',
          showCancelButton: true,
          cancelButtonText: 'Batalkan',
          cancelButtonColor: '#666',
          confirmButtonColor: '#dc3545',
          confirmButtonText: "Hapus"
          }).then((result) => {
          if (result.isConfirmed) {
              window.location.href = '/wizard/wh/delete/' + wh_id;
          }
      })
});
function add_wh_item(count) {
    let wh_container_new = $('.wh-container-new');
    wh_container_new.append(
        '<div id="wh-list-item-'+ count +'" class="d-flex flex-remove-md wh-list-item card bg-white p-4 shadow-sm mb-4">' +
            '<input type="hidden" name="wh_id-'+ count +'" value="">' +
            '<div class="w-100 d-flex justify-content-between mb-3"><span class="text-primary">Riwayat baru</span><button type="button" class="btn-close btn-remove-item btn-sm" aria-label="Close" data-count="'+ count +'"></button></div>' +
            '<div class="form-group col">' +
                '<div class="d-flex mb-2 flex-remove-md">' +
                    '<div class="d-flex col align-middle align-items-center mb-2">' +
                        '<div class="form-floating col">' +
                            '<select name="month_start-'+ count +'" class="form-control form-select" required>' +
                                '<option value="january">Januari</option>' +
                                '<option value="february">Februari</option>' +
                                '<option value="march">Maret</option>' +
                                '<option value="april">April</option>' +
                                '<option value="may">Mei</option>' +
                                '<option value="june">Juni</option>' +
                                '<option value="july">Juli</option>' +
                                '<option value="august">Agustus</option>' +
                                '<option value="september">September</option>' +
                                '<option value="october">Oktober</option>' +
                                '<option value="november">November</option>' +
                                '<option value="desember">Desember</option>' +
                            '</select>' +
                            '<label for="month_start-'+ count +'" class="form-label">Bulan bergabung</label>' +
                        '</div>' +
                        '<span>&ensp;</span>' +
                        '<div class="form-floating col">' +
                            '<input type="number" class="form-control" name="year_start-'+ count +'" placeholder="Tahun bergabung" required>' +
                            '<label for="year_start-'+ count +'" class="form-label">Tahun bergabung</label>' +
                        '</div>' +
                    '</div>' +
                    '<span class="remove-md mb-2" style="padding-top:20px;">&ensp;-&ensp;</span>' +
                    '<div class="d-flex col align-middle align-items-center mb-2">' +
                        '<div class="form-floating col">' +
                            '<select name="month_end-'+ count +'" class="form-control form-select">' +
                                '<option value="" selected disabled hidden>Bulan</option>' +
                                '<option value="january">Januari</option>' +
                                '<option value="february">Februari</option>' +
                                '<option value="march">Maret</option>' +
                                '<option value="april">April</option>' +
                                '<option value="may">Mei</option>' +
                                '<option value="june">Juni</option>' +
                                '<option value="july">Juli</option>' +
                                '<option value="august">Agustus</option>' +
                                '<option value="september">September</option>' +
                                '<option value="october">Oktober</option>' +
                                '<option value="november">November</option>' +
                                '<option value="desember">Desember</option>' +
                            '</select>' +
                            '<label for="month_end-'+ count +'" class="form-label">Bulan berhenti*</label>' +
                        '</div>' +
                        '<span>&ensp;</span>' +
                        '<div class="form-floating col">' +
                            '<input type="number" class="form-control" name="year_end-'+ count +'" placeholder="Tahun berhenti">' +
                            '<label for="year_end-'+ count +'" class="form-label">Tahun berhenti*</label>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
                '<div class="d-flex mb-3">' +
                    '<div class="form-floating col mb-1">' +
                        '<input type="text" class="form-control" name="work_place-'+ count +'" placeholder="Perusahaan" required>' +
                        '<label for="work_place-'+ count +'" class="form-label">Perusahaan</label>' +
                    '</div>' +
                    '<span>&ensp;</span>' +
                    '<div class="form-floating col mb-1">' +
                        '<select name="employment-'+ count +'" class="form-control form-select" required>' +
                            '<option value="full time">Full time</option>' +
                            '<option value="part time">Part time</option>' +
                            '<option value="self employed">Self employed</option>' +
                            '<option value="freelance">Freelance</option>' +
                            '<option value="contract">Contract</option>' +
                            '<option value="internship">Internship</option>' +
                            '<option value="apprenticeship">Apprenticeship</option>' +
                            '<option value="seasonal">Seasonal</option>' +
                        '</select>' +
                        '<label for="employment-'+ count +'" class="form-label">Tipe pekerjaan</label>' +
                    '</div>' +
                '</div>' +
                '<div class="form-floating mb-3">' +
                    '<input type="text" class="form-control" name="role-'+ count +'" placeholder="Peran" required>' +
                    '<label for="role-'+ count +'" class="form-label">Peran</label>' +
                '</div>' +
                '<div class="form-floating mb-3">' +
                    '<textarea name="description-'+ count +'" class="form-control" placeholder="Deskripsi singkat" style="height: 100px"></textarea>' +
                    '<label for="description-'+ count +'" class="form-label">Deskripsi</label>' +
                '</div>' +
            '</div>' +
        '</div>'
    );
}

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/wizard_exp.blade.php ENDPATH**/ ?>