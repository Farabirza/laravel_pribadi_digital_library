
<div class="mb-4 d-flex flex-wrap align-items-center">
    <span class="me-3"><i class='bx bx-error text-warning fs-24'></i></span>
    <span class="col text-secondary fs-11">Dengan mengisi form ini, anda dianggap telah menyetujui <a href="" class="text-primary">ketentuan dan kondisi</a> yang berlaku. Anda diperkenankan untuk <b>mengosongkan kotak isian yang anda rasa tidak perlu.</b></span>
</div><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/partials/wizard_disclaimer.blade.php ENDPATH**/ ?>