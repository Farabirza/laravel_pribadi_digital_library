<section id="section-topbar" class="py-2 bg-dark" style="color:#37b3ed">
    <div class="container">
        <div class="d-flex justify-content-between">
            <div class="d-flex">
                <a href="/dashboard/overview" class="me-3"><i class='bx bxs-dashboard me-1' ></i> Dashboard</a>
                <a href="/dashboard/analytics" class="me-3"><i class='bx bxs-bar-chart-alt-2 me-1' ></i> Analytics</a>
                <!-- <a href="/dashboard/edit/profile" class="me-3"><i class='bx bx-edit-alt me-1' ></i> Edit Data</a> -->
                <div class="dropdown me-3">
                    <span id="menu-edit-data" class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class='bx bx-edit-alt me-1' ></i> Edit Data</span>
                    <div class="dropdown-menu bg-dark" aria-labelledby="menu-edit-data">
                        <a class="dropdown-item text-light" href="/dashboard/edit/profile">Profil</a>
                        <a class="dropdown-item text-light" href="/dashboard/edit/education">Pendidikan</a>
                        <a class="dropdown-item text-light" href="/dashboard/edit/experience">Pengalaman</a>
                        <a class="dropdown-item text-light" href="/dashboard/edit/skill">Keterampilan</a>
                        <a class="dropdown-item text-light" href="/dashboard/edit/portfolio">Portofolio</a>
                    </div>
                </div>
                <a href="/dashboard/config" class="me-3"><i class='bx bx-cog me-1' ></i> Config</a>
            </div>
        </div>
    </div>
</section>
<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function(){
    $(".dropdown").hover(function(){
        $(this).css({ 'cursor': 'pointer' });
        var dropdownMenu = $(this).children(".dropdown-menu");
        dropdownMenu.toggleClass("show");
    });
    $(".dropdown-item").hover(function(){
        $(this).toggleClass("text-light");
    });
});     
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/layouts/partials/topbar_owner.blade.php ENDPATH**/ ?>