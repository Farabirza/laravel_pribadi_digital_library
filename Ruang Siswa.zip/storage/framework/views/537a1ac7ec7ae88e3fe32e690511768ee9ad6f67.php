<?php if(auth()->guard()->guest()): ?>
<?php header("Location: /?login=required"); die(); ?>
<?php endif; ?>



<?php $__env->startPush('css-styles'); ?>
<style>
    #main { min-height: 100vh; background: #f9f9f9; }
    @media (max-width: 768px) {
        #section-form { padding-top: 20px; }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-form" class="py-40">
    <div class="container">
        <?php echo $__env->make('cv.partials.wizard_progressbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('cv.partials.wizard_disclaimer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-------- form start -------->
        <form id="form-profession" action="/form/cv/profession" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row align-items-center"> <!-- row start -->
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold text-dark ps-3 fs-32 bl-dark-md">Riwayat Pekerjaan</h3>
            </div>
            <div class="col-md-12"> <!-- col form start -->
                
            <!-- profession  -->
            <label class="fw-bold mb-2">Profesi terakhir</label>
            <div class="form-group mb-4">
                <div class="form-floating">
                    <input type="text" class="form-control" name="profession" placeholder="profession" value="<?php echo e(old('profession')); ?>" required>
                    <label for="profession" class="form-label">Profesi</label>
                </div>
            </div>
            <div class="form-group d-flex mb-4 flex-remove-md">
                <div class="form-floating col">
                    <input type="text" class="form-control" name="profession" placeholder="profession" value="<?php echo e(old('profession')); ?>" required>
                    <label for="profession" class="form-label">Nama perusahaan / instansi</label>
                </div>
                <span>&ensp;</span>
                <div class="form-floating col">
                    <select id="job_status" name="job_status" class="form-control form-select">
                        <option value="select" selected disabled hidden>Job status</option>
                        <option value="full_time">Waktu penuh (full time)</option>
                        <option value="part_time">Paruh waktu (part time)</option>
                        <option value="freelance">Freelance</option>
                        <option value="intern">Magang</option>
                        <option value="lainnya">Lainnya</option>
                    </select>
                    <label for="job_status" class="form-label">Status pekerjaan</label>
                </div>
            </div>
            <!-- profession end -->

            <!-- profession history start -->
            <!-- <label class="fw-bold mb-2">Riwayat Pekerjaan</label>
            <div class="wh-container">
                <div id="wh-list-item-1" class="d-flex mb-3 wh-list-item">
                    <span class="pt-3 me-3 fs-16 remove-md" style="color:#374785"><i class='bx bxs-right-arrow' ></i></span>
                    <div class="form-group col">
                        <div class="d-flex mb-2 flex-remove-md">
                            <div class="d-flex col align-middle align-items-center mb-1">
                                <div class="form-floating col">
                                    <input type="number" class="form-control" name="wh_year_from-1" placeholder="year from" value="<?php echo e(old('wh_year_from-1')); ?>" required>
                                    <label for="wh_year_from-1" class="form-label">Tahun bergabung</label>
                                </div>
                                <span>&ensp;-&ensp;</span>
                                <div class="form-floating col">
                                    <input type="number" class="form-control" name="wh_year_to-1" placeholder="year to" value="<?php echo e(old('wh_year_to-1')); ?>" required>
                                    <label for="wh_year_to-1" class="form-label">Tahun berhenti</label>
                                </div>
                            </div>
                            <span class="remove-md">&ensp;</span>
                            <div class="form-floating col mb-1">
                                <input type="text" class="form-control" name="wh_company-1" placeholder="work history" value="<?php echo e(old('wh_company-1')); ?>" required>
                                <label for="wh_company-1" class="form-label">Nama perusahaan / instansi</label>
                            </div>
                        </div>
                        <div class="form-floating mb-1">
                            <input type="text" class="form-control" name="wh_title-1" placeholder="work history" value="<?php echo e(old('wh_title-1')); ?>" required>
                            <label for="wh_title-1" class="form-label">Profesi</label>
                        </div>
                        <div class="mb-3"><span class="text-muted fs-11 fst-italic">*Kosongkan tahun berhenti apabila masih aktif</span></div>
                    </div>
                </div>
            </div>
            <div class="d-flex mb-4">
                <span class="pt-1 me-3 hide fs-16 remove-md"><i class='bx bxs-right-arrow' ></i></span>
                <div class="col text-center"><button type="button" class="btn btn-outline-primary w-100 btn-add-wh"><i class='bx bx-add-to-queue'></i> Tambahkan</button></div>
            </div> -->
            <!-- profession history end -->

            </div> <!-- col form end -->
        </div> <!-- row end -->

        <div class="row"> <!-- row start -->
            <!-- form button -->
            <hr class="mb-3"/>
            <div class="form-group d-flex justify-content-end">
                <button type="button" class="btn btn-success me-2 disabled btn-form-save"><i class='bx bxs-save' ></i> Simpan</button>
                <a href="/wizard/education?from=60" class="btn btn-secondary me-2"><i class='bx bx-left-arrow-alt' ></i> Sebelumnya</a>
            </div>
            <!-- form button end -->
        </div> <!-- row end -->

        </form>
        <!-------- form end -------->

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/js/ajax_cv.js')); ?>"></script>
<script>
$(window).resize(function() {
    if($(window).width() < 992) {
        $('.flex-remove-md').removeClass('d-flex');
    } else {
        $('.flex-remove-md').removeClass('d-flex').addClass('d-flex');
    }
});
$(document).ready(function(){
    // Progressbar
    $('.progress-list').removeClass('progress-list-active');
    $('#progress-list-wh').addClass('progress-list-active');
    $('.progress-bar').css('width','60%').attr('aria-valuenow','60');

    // window size
    if($(window).width() < 992) {
        $('.flex-remove-md').removeClass('d-flex');
    } else {
        $('.flex-remove-md').removeClass('d-flex').addClass('d-flex');
    }
});

// Form
$('#form-profession').change(function(e){
    $('.btn-form-save').removeClass('disabled');
});

// Work History
var wh_item_count = 1;
$('.btn-add-wh').click(function(e){
    e.preventDefault();
    add_wh_item(wh_item_count + 1);
    wh_item_count++;
    $('.btn-remove-wh').click(function(e){
        e.preventDefault();
        let get_count = $(this).attr('data-count');
        $('#wh-list-item-' + get_count).remove();
    });
});
function add_wh_item(count) {
    let wh_container = $('.wh-container');
    wh_container.append(
        '<div id="wh-list-item-'+ count +'" class="d-flex mb-3 wh-list-item">' +
            '<span class="pt-3 me-3 fs-16 remove-md" style="color:#374785"><i class="bx bxs-right-arrow" ></i></span>' +
            '<div class="form-group col">' +
                '<div class="d-flex mb-2 flex-remove-md">' +
                    '<div class="d-flex col align-middle align-items-center mb-1">' +
                        '<div class="form-floating col">' +
                            '<input type="number" class="form-control" name="wh_year_from-'+ count +'" placeholder="year from" value="" required>' +
                            '<label for="wh_year_from-'+ count +'" class="form-label">Tahun bergabung</label>' +
                        '</div>' +
                        '<span>&ensp;-&ensp;</span>' +
                        '<div class="form-floating col">' +
                            '<input type="number" class="form-control" name="wh_year_to-'+ count +'" placeholder="year to" value="" required>' +
                            '<label for="wh_year_to-'+ count +'" class="form-label">Tahun berhenti</label>' +
                        '</div>' +
                    '</div>' +
                    '<span class="remove-md">&ensp;</span>' +
                    '<div class="form-floating col mb-1">' +
                        '<input type="text" class="form-control" name="wh_company-'+ count +'" placeholder="work history" value="" required>' +
                        '<label for="wh_company-'+ count +'" class="form-label">Nama perusahaan / instansi</label>' +
                    '</div>' +
                '</div>' +
                '<div class="form-floating mb-3">' +
                    '<input type="text" class="form-control" name="wh_title-'+ count +'" placeholder="work history" value="" required>' +
                    '<label for="wh_title-'+ count +'" class="form-label">Profesi</label>' +
                '</div>' +
                '<div class="col text-center mb-3"><button type="button" data-count="'+ count +'" class="btn btn-outline-danger w-100 btn-remove-wh"><i class="bx bx-trash" ></i> Hapus</button></div>' +
            '</div>' +
        '</div>'
    );
}

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/wizard_job.blade.php ENDPATH**/ ?>