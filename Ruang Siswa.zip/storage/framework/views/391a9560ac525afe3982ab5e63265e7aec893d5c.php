
<style>
#sidebar-preference h5 { font-size: 12pt; }
#sidebar-preference p { font-size: 9pt; }
#sidebar-preference input, #sidebar-preference textarea { font-size: 10pt; }
#sidebar-preference .form-label { color: var(--bs-primary); font-size: 10pt; }
#sidebar-preference .btn { display: flex; align-items: center; gap: 4px; }
</style>

<div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="sidebar-preference" aria-labelledby="sidebar-preferenceLabel">
  <div class="offcanvas-header">
    <h4 class="offcanvas-title" id="sidebar-preferenceLabel">Theme Preference</h4>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <!-- form typedjs start -->
    <form action="action/preference" method="post" id="form-pref-typedjs" class="m-0">
    <h5 class="mb-3">Typedjs</h5>
    <div class="mb-2 d-flex align-items-center justify-content-between">
        <label for="pref-typedjs_show" class="form-label">Show typed</label>
        <?php if($user->config->preference->typedjs_show == true): ?>
        <div class="form-check form-switch"><input id="pref-typedjs_show" class="form-check-input hover-pointer pref-switch" type="checkbox" role="switch" data-access="typedjs_show" checked></div>
        <input type="hidden" name="typedjs_show" value="1">
        <?php else: ?>
        <div class="form-check form-switch"><input id="pref-typedjs_show" class="form-check-input hover-pointer pref-switch" type="checkbox" role="switch" data-access="typedjs_show"></div>
        <input type="hidden" name="typedjs_show" value="0">
        <?php endif; ?>
    </div>
    <div class="mb-2">
        <label for="pref-typedjs_start" class="form-label">First half words</label>
        <input type="text" id="pref-typedjs_start" name="typedjs_start" class="form-control" value="<?php echo e($user->config->preference->typedjs_start); ?>">
    </div>
    <div class="mb-2">
        <label for="pref-typedjs_end" class="form-label">Second half words</label>
        <textarea name="typedjs_end" id="pref-typedjs_end" class="form-control mb-2"><?php echo e($user->config->preference->typedjs_end); ?></textarea>
        <p class="mb-0 fst-italic text-muted">*) use coma ',' as separator between words</p>
    </div>
    <div class="mb-4 d-flex align-items-center gap-3">
        <hr class="col">
        <button type="submit" class="btn btn-success btn-sm"><i class="bx bx-save"></i>Apply</button>
    </div>
    </form>
    <!-- form typedjs end -->
  </div>
</div>

<script type="text/javascript">
// typedjs start
$('#pref-typedjs_show').change(function(e) {
    var url = domain + 'action/preference';
    var value = ($('#pref-typedjs_show').is(':checked')) ? true : false;
    if($('#pref-typedjs_show').is(':checked')) {
        $('#typedjs-display').removeClass('d-none');
        $('[name="typedjs_show"]').val(1);
    } else {
        $('#typedjs-display').addClass('d-none');
        $('[name="typedjs_show"]').val(0);
    }
});
$('#pref-typedjs_start').keyup(function(e) { $('#show-typed_start').html($(this).val()); });
$('#form-pref-typedjs').submit(function(e) {
    e.preventDefault();
    var formData = new FormData($(this)[0]);
    formData.append('action', 'update_typedjs');
    var config = { method: $(this).attr('method'), url: domain + $(this).attr('action'), data: formData };
    axios(config)
    .then((response) => {
        successMessage(response.data.message);
        location.reload();
    })
    .catch((error) => {
        console.log(error);
    });
});
// typedjs end
</script><?php /**PATH C:\xampp\htdocs\CV Kreatif 2.0\cvkreatif.com\resources\views/themes/preference/preference_default.blade.php ENDPATH**/ ?>