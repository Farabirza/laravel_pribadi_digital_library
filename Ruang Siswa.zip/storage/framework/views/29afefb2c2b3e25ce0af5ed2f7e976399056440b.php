

<?php $__env->startPush('css-styles'); ?>
<style>
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content" class="p-5">
    <div class="container-fluid">
        <div class="row">
            <iframe src="https://pribadidepok.edunav.net/application-form" frameborder="0" width="800" height="1000"></iframe>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('/vendor/chart/chart.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/vendor/chart/chartjs-plugin-datalabels.min.js')); ?>" ></script>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: .2,
        delay: 0,
        once: true,
    });
});
</script>
<script>
$(document).ready(function(){ 
    $('.nav-link').removeClass('active'); $('#link-overview').addClass('active'); // nav-link active

});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/page/test.blade.php ENDPATH**/ ?>