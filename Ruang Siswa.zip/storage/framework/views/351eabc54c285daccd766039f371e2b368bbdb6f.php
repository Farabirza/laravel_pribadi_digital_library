

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/aos/aos.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<style>
:root {
  --sidebar-width: 100px;
}
img { max-height: 320px; }
.dashed-bottom { border-bottom: 1px dashed #404040; }

/* ========================== Navigation start ========================== */
#sidebar-theme {
    z-index: 999;
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: var(--sidebar-width);
    transition: all ease-in-out 0.5s;
    transition: all 0.5s;
    padding: 0 15px;
    overflow-y: auto;
} .mobile-nav-toggle {
  position: fixed;
  right: 15px;
  top: 15px;
  z-index: 9998;
  border: 0;
  font-size: 24px;
  transition: all 0.4s;
  outline: none !important;
  color: #fff;
  width: 40px;
  height: 40px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  line-height: 0;
  border-radius: 50px;
  cursor: pointer;
} .mobile-nav-active {
  overflow: hidden;
} .mobile-nav-active #sidebar-theme {
  left: 0;
}

.nav-link { font-size: 28pt; }

/* ========================== Navigation end ========================== */

/* ========================== section education & experience start ========================== */
.resume-title {
  font-size: 26px;
  font-weight: 700;
  margin-top: 20px;
  margin-bottom: 20px;
  color: #45505b;
}
.resume-item {
  padding: 0 0 30px 20px;
  margin-top: -2px;
  border-left: 2px solid #0563bb;
  position: relative;
}
.resume-item .resume-item-title {
  line-height: 18px;
  letter-spacing: 1px;
  font-size: 20px;
  font-weight: 600;
  text-transform: uppercase;
  color: #0563bb;
}
.resume-item h5 {
  font-size: 16px;
  background: #f7f8f9;
  padding: 5px 15px;
  display: inline-block;
  font-weight: 600;
}
.resume-item ul {
  padding-left: 20px;
}
.resume-item ul li {
  padding-bottom: 10px;
}
.resume-item:last-child {
  padding-bottom: 0;
}
.resume-item::before {
  content: "";
  position: absolute;
  width: 16px;
  height: 16px;
  border-radius: 50px;
  left: -9px;
  top: 0;
  background: #fff;
  border: 2px solid #0563bb;
}
/* ========================== section education & experience end ========================== */

#theme-content, #section-topbar {
    padding-left: var(--sidebar-width);
    transition: all ease-in-out 0.5s;
    transition: all 0.5s;
}

#section-intro {
    <?php if($user->profile->cover_image): ?>
    background: url("<?php echo e(asset('img/covers/'.$user->profile->cover_image)); ?>") center center fixed;
    background-size: cover;
    <?php else: ?>
    background: url("<?php echo e(asset('img/bg/default.jpg')); ?>") center center fixed;
    <?php endif; ?>
}

#section-about #container-about-picture { text-align: end; border-right: 1px dashed #404040; margin-right: 50px; padding-right: 50px; }

@media (max-width: 1199px) {
    #sidebar-theme {
        left: calc(var(--sidebar-width) * -1);
    }
    #theme-content, #section-topbar { padding-left: 0; }
    #section-about #container-about-picture { text-align: center; border-right: none; margin-right: 0; padding-right: 0; }
}
@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- ======= Mobile nav toggle button ======= -->
<i class="bi bi-list mobile-nav-toggle bg-dark d-xl-none"></i>

 <!-- ======================================= Theme sidebar start ================================================== -->
 <header>
 <div id="sidebar-theme" class="d-flex flex-column flex-shrink-0 bg-dark">
    <a href="/" class="d-block py-3 px-2 link-dark text-decoration-none">
        <img src="<?php echo e(asset('/img/logo/logo.png')); ?>" class="img-fluid"/>
        <span class="visually-hidden">CVKreatif.com</span>
    </a>
    <hr class="text-white"/>
    <ul class="nav nav-pills nav-flush flex-column mb-auto text-center">
        <li class="nav-item">
            <a href="#section-about" class="nav-link mb-2" aria-current="page" title="About" data-bs-toggle="tooltip" data-bs-placement="right"><i class="bx bx-user"></i></a>
        </li>
        <?php if(count($user->education) > 0): ?>
        <li class="nav-item">
            <a href="#section-education" class="nav-link mb-2" aria-current="page" title="Education" data-bs-toggle="tooltip" data-bs-placement="right"><i class="bx bxs-graduation"></i></a>
        </li>
        <?php endif; ?>
        <?php if(count($user->workHistory) > 0): ?>
        <li class="nav-item">
            <a href="#section-experience" class="nav-link mb-2" aria-current="page" title="Experience" data-bs-toggle="tooltip" data-bs-placement="right"><i class="bx bx-briefcase"></i></a>
        </li>
        <?php endif; ?>
        <?php if(count($user->certificate) > 0): ?>
        <li class="nav-item">
            <a href="#section-certificate" class="nav-link mb-2" aria-current="page" title="Certificate" data-bs-toggle="tooltip" data-bs-placement="right"><i class="bx bx-file"></i></a>
        </li>
        <?php endif; ?>
        <?php if(count($user->skill) > 0): ?>
        <li class="nav-item">
            <a href="#section-skill" class="nav-link mb-2" aria-current="page" title="Skill" data-bs-toggle="tooltip" data-bs-placement="right"><i class="bx bx-bulb"></i></a>
        </li>
        <?php endif; ?>
        <li class="nav-item">
            <a href="#section-portfolio" class="nav-link mb-2" aria-current="page" title="Portfolio" data-bs-toggle="tooltip" data-bs-placement="right"><i class="bx bx-image-alt"></i></a>
        </li>
    </ul>
</div>
</header>
<!-- ======================================= Theme sidebar end ================================================== -->

<!-- ======================================= Theme content start ================================================== -->
<div id="theme-content">

<!-- section intro start -->
<section id="section-intro">
    <div class="container vh-100">
        <div class="row d-flex h-100 justify-content-center align-items-center"> <!-- row start -->
            <div class="col-md-12 text-center mb-3">
                <div class="mb-5">
                    <h1 class="fw-semibold fs-48 mb-2" data-aos="fade-right" data-aos-duration="400"><?php echo e($user->profile->full_name); ?></h1>
                    <?php if($user->config->preference->typedjs_show == true): ?>
                    <h3 id="typedjs-display" class="display-5 text-uppercase fs-28" data-aos="fade-right" data-aos-duration="600"><span id="show-typed_start"><?php echo e($user->config->preference->typedjs_start); ?></span> <span id="typed" style="font-weight:500"></span></h3>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <?php if(isset($user->profile->prof_email)): ?>
                    <div class="d-flex align-items-center mx-2">
                        <a href="mailto:<?php echo e($user->profile->prof_email); ?>" class="popper" title="<?php echo e($user->profile->prof_email); ?>" target="_blank" rel="noopener noreferrer">
                            <span class="fs-16 text-white py-1 px-2 rounded me-2" style="background:#BB001B"><i class='bx bx-envelope'></i></span>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($user->profile->li_name)): ?>
                    <div class="d-flex align-items-center mx-2">
                        <a href="<?php echo e($user->profile->li_url); ?>" class="popper" title="<?php echo e($user->profile->li_name); ?>" target="_blank" rel="noopener noreferrer">
                            <span class="fs-16 text-white py-1 px-2 rounded me-2" style="background:#0e76a8"><i class='bx bxl-linkedin'></i></span>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($user->profile->ig_name)): ?>
                    <div class="d-flex align-items-center mx-2">
                        <a href="<?php echo e($user->profile->ig_url); ?>" class="popper" title="<?php echo e($user->profile->ig_name); ?>" target="_blank" rel="noopener noreferrer">
                            <span class="fs-16 text-white py-1 px-2 rounded me-2" style="background:#dd2a7b"><i class='bx bxl-instagram'></i></span>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($user->profile->web_name)): ?>
                    <div class="d-flex align-items-center mx-2">
                        <a href="<?php echo e($user->profile->web_url); ?>" class="popper" title="<?php echo e($user->profile->web_name); ?>" target="_blank" rel="noopener noreferrer">
                            <span class="fs-16 text-white py-1 px-2 rounded me-2" style="background:#404040"><i class='bx bx-link-alt'></i></span>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div> <!-- row end -->
    </div>
</section>
<!-- section intro end -->

<!-- section about me start -->
<section id="section-about" class="bg-light py-5">
    <div class="container py-5">
        <div class="row">  <!-- row start -->
            <div class="col-md-12 d-flex justify-content-center mb-5">
                <h1 class="display-5 d-flex gap-3 align-items-center"><i class="bx bx-user bx-border-circle bg-dark text-light"></i>About me</h1>
            </div>
            <div class="col-md-12 px-3 d-flex flex-remove-md align-items-center">
                <div id="container-about-picture" class="col mb-3">
                    <?php if($user->picture): ?>
                    <img src="<?php echo e(asset('img/profiles/'.$user->picture)); ?>" alt="" class="rounded-circle shadow" style="max-height: 280px" data-aos="fade-left" data-aos-duration="400">
                    <?php else: ?>
                    <img src="<?php echo e(asset('img/materials/user.jpg')); ?>" alt="" class="rounded-circle shadow" style="max-height: 280px" data-aos="fade-left" data-aos-duration="400">
                    <?php endif; ?>
                </div>
                <div class="col mb-3" data-aos="fade-right" data-aos-duration="800">
                    <p class="fs-12 text-muted mb-1">Full name</p>
                    <p class="fs-16 fw-semibold mb-3"><?php echo e($user->profile->full_name); ?></p>
                    <?php if($user->profile->biodata): ?>
                    <p class="fs-12 text-muted mb-1">Biodata</p>
                    <p class="fs-12 fst-italic fw-semibold mb-3"><?php echo e($user->profile->biodata); ?></p>
                    <?php else: ?>
                    <p class="fs-12 text-muted mb-1">Biodata</p>
                    <p class="fs-12 fst-italic fw-semibold mb-3">-</p>
                    <?php endif; ?>
                    <?php if($user->profile->languange): ?>
                    <p class="fs-12 text-muted mb-1">Languange</p>
                    <p class="fs-12 fst-italic fw-semibold mb-3"><?php echo e($user->profile->languange); ?></p>
                    <?php else: ?>
                    <p class="fs-12 text-muted mb-1">Languange</p>
                    <p class="fs-12 fst-italic fw-semibold mb-3">-</p>
                    <?php endif; ?>
                    <?php if($user->profile->interest): ?>
                    <p class="fs-12 text-muted mb-1">Interest</p>
                    <p class="fs-12 fst-italic fw-semibold mb-3"><?php echo e($user->profile->interest); ?></p>
                    <?php else: ?>
                    <p class="fs-12 text-muted mb-1">Interest</p>
                    <p class="fs-12 fst-italic fw-semibold mb-3">-</p>
                    <?php endif; ?>
                </div>
            </div>
        </div> <!-- row end -->
    </div>
</section>
<!-- section about me end -->

<div class="d-flex justify-content-center">
    <div style="width:75%; border-bottom: 1px solid #999;"></div>
</div>

<!-- section education start -->
<?php if(count($user->education) > 0): ?>
<section id="section-education" class="bg-light py-5">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-12 d-flex justify-content-center mb-5">
                <h1 class="display-5 d-flex gap-3 align-items-center"><i class="bx bxs-graduation bx-border-circle bg-dark text-light"></i>Education</h1>
            </div>
            <div id="container-educations" class="col-md-12">
                <?php $i = 1; ?>
                <?php $__currentLoopData = $user->education->sortByDesc('year_start'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="resume-item" data-aos="slide-up" data-aos-duration="<?php echo e($i*500); ?>">
                    <h4 class="resume-item-title mb-2"><?php echo e($education->institution); ?></h4>
                    <?php if($education->year_end): ?>
                    <h5><?php echo e($education->year_start); ?> - <?php echo e($education->year_end); ?></h5>
                    <?php else: ?>
                    <h5><?php echo e($education->year_start); ?> - Present</h5>
                    <?php endif; ?>
                    <p class="fst-italic mb-2"><?php echo e($education->major); ?></p>
                    <p class="fs-11 text-secondary mb-0"><?php echo e($education->description); ?></p>
                </div>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- separator start -->
<div class="d-flex justify-content-center">
    <div style="width:75%; border-bottom: 1px solid #999;"></div>
</div>
<!-- separator end -->
<?php endif; ?>
<!-- section education end -->


<!-- section experience start -->
<?php if(count($user->workHistory) > 0): ?>
<section id="section-experience" class="bg-light py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 d-flex justify-content-center mb-5">
                <h1 class="display-5 d-flex gap-3 align-items-center"><i class="bx bx-briefcase bx-border-circle bg-dark text-light"></i>Job Experience</h1>
            </div>
            <div id="container-workHistories" class="col-md-12">
                <?php $i = 1; ?>
                <?php $__currentLoopData = $user->workHistory->sortByDesc('year_start'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $workHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="resume-item" data-aos="slide-up" data-aos-duration="<?php echo e($i*500); ?>">
                    <p class="d-flex align-items-center gap-2 mb-2"><span class="resume-item-title"><?php echo e($workHistory->role); ?></span> <span class="badge bg-secondary"><?php echo e($workHistory->employment); ?></span></p>
                    <?php if($workHistory->year_end): ?>
                    <h5><?php echo e($workHistory->year_start); ?> - <?php echo e($workHistory->year_end); ?></h5>
                    <?php else: ?>
                    <h5><?php echo e($workHistory->year_start); ?> - Present</h5>
                    <?php endif; ?>
                    <p class="fst-italic mb-2"><?php echo e($workHistory->work_place); ?></p>
                    <p class="fs-11 text-secondary mb-0"><?php echo e($workHistory->description); ?></p>
                </div>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- separator start -->
<div class="d-flex justify-content-center">
    <div style="width:75%; border-bottom: 1px solid #999;"></div>
</div>
<!-- separator end -->
<?php endif; ?>
<!-- section experience end -->

<!-- section certificate start -->
<?php if(count($user->certificate) > 0): ?>
<section id="section-certificate" class="bg-light py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 d-flex justify-content-center mb-4">
                <h1 class="display-5 d-flex gap-3 align-items-center"><i class="bx bx-file bx-border-circle bg-dark text-light"></i>Certificate</h1>
            </div>
            <div class="col-md-12 mb-4 d-flex flex-wrap justify-content-center gap-3">
                <span role="button" class="pb-2 hover-underline" data-aos="fade-right" data-aos-duration="300">all</span>
                <?php $arr_certificate = []; ?>
                <?php $__currentLoopData = $user->certificate->pluck('category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!in_array($certificate, $arr_certificate)): ?>
                <span role="button" class="pb-2 hover-underline" data-aos="fade-right" data-aos-duration="<?php echo e(($key+1)*300); ?>"><?php echo e($certificate); ?></span>
                <?php $arr_certificate[] = $certificate; ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-12 d-flex flex-wrap justify-content-center gap-3">
                <?php $__currentLoopData = $user->certificate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="certificate-item px-3" data-aos="fade-right" data-aos-duration="<?php echo e(($key+1)*400); ?>">
                    <img src="<?php echo e(asset('img/certificate/'.$certificate->image)); ?>" class="rounded shadow" style="max-width:320px">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- separator start -->
<div class="d-flex justify-content-center">
    <div style="width:75%; border-bottom: 1px solid #999;"></div>
</div>
<!-- separator end -->
<?php endif; ?>
<!-- section certificate end -->

<!-- section skill start -->
<?php if(count($user->skill) > 0): ?>
<section id="section-skill" class="bg-light py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 d-flex justify-content-center mb-5">
                <h1 class="display-5 d-flex gap-3 align-items-center"><i class="bx bx-bulb bx-border-circle bg-dark text-light"></i>Skill</h1>
            </div>
            <div class="col-md-12 row">
                <?php $i = 1; ?>
                <?php $__currentLoopData = $user->skill->sortBy('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="skill-item-<?php echo e($key+1); ?>" class="col-md-6 px-4 mb-4" data-aos="fade-right" data-aos-duration="<?php echo e($i*400); ?>">
                    <div class="mb-2 d-flex align-items-center justify-content-between">
                        <span id="skill-name-<?php echo e($key+1); ?>" class="popper" title="<?php echo e($skill->description); ?>"><?php echo e($skill->name); ?></span>
                        <span id="skill-point-<?php echo e($key+1); ?>" class="badge bg-secondary"><?php echo e($skill->proficiency); ?>%</span>
                    </div>
                    <div class="progress">
                        <div id="skill-proficiency-<?php echo e($key+1); ?>" class="progress-bar" role="progressbar" aria-label="skill name" style="width: <?php echo e($skill->proficiency); ?>%" aria-valuenow="<?php echo e($skill->proficiency); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- separator start -->
<div class="d-flex justify-content-center">
    <div style="width:75%; border-bottom: 1px solid #999;"></div>
</div>
<!-- separator end -->
<?php endif; ?>
<!-- section skill end -->

<!-- section portfolio start -->
<section id="section-portfolio" class="bg-light py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 d-flex justify-content-center mb-5">
                <h1 class="display-5 d-flex gap-3 align-items-center"><i class="bx bx-image-alt bx-border-circle bg-dark text-light"></i>Portfolio</h1>
            </div>
        </div>
    </div>
</section>
<!-- section portfolio end -->

</div>
<!-- ======================================= Theme content end ================================================== -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/typed/typed.min.js')); ?>"></script>

<?php if($user->config->preference->typedjs_show == true): ?>
<script type="text/javascript">
var string = '<?php echo e($user->config->preference->typedjs_end); ?>';
var item = string.split(',');
var typed = new Typed('#typed', {
    strings: item, typeSpeed: 100, backSpeed: 50, backDelay: 2000, loop: true,
});
</script>
<?php endif; ?>
<script type="text/javascript">
const lightbox = GLightbox({
    selector: '.glightbox',
});
const lightbox1 = GLightbox({
    selector: '.glightbox1', touchNavigation: true, loop: true, autoplayVideos: true
});
$(window).resize(function() {
  if($(window).width() < 1199) {
  } else {
  }
});
$(document).ready(function() {
  if($(window).width() < 1199) {
  } else {
  }
  // Animate on scroll
  AOS.init({ once: true,  easing: 'ease-in-out-sine' });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif 2.0\cvkreatif.com\resources\views/themes/default.blade.php ENDPATH**/ ?>