<!-- Modal feedback -->
<div class="modal fade" id="modal-feedback" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title align-middle fw-bold"><i class='bx bx-star mr-2'></i> Feedback untuk Admin</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/new/feedback" id="form-feedback" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="form-floating mb-3">
                    <input type="text" name="feedback_username" class="form-control" value="<?php echo e(Auth::user()->username); ?>">
                    <label for="feedback_username" class="label">Username</label>
                </div>
                <div class="form-group mb-3">
                    <label for="score" class="form-label text-muted">Skor</label>
                    <div class="col d-flex">
                        <span class="fs-11 text-danger me-3">Kurang</span>
                        <input type="range" name="score" class="form-range col" min="1" max="10" step="1">
                        <span class="fs-11 text-primary ms-3">Mantap</span>
                    </div>
                    <p class="fs-10 text-muted mb-0">Point : <span id="score-point"></span></p>
                </div>
                <div class="form-group mb-3">
                    <label class="text-muted mb-2">Review</label>
                    <textarea name="review" cols="30" rows="3" class="form-control" placeholder=""></textarea>
                </div>
                <div class="form-outline mb-3">
                    <p class="text-muted" style="color: #393f81;"><input type="checkbox" name="anonymous" value="true" class="mr-8"> Sembunyikan identitas saya</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <button type="submit" class="btn btn-primary"><i class='bx bx-mail-send' ></i> Kirim</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal feedback end -->
<script type="text/javascript">
$(document).ready(function(){
    $('#score-point').html($('[name="score"]').val());
})
$('#show-modal-feedback').click(function(e){
  $('.modal').modal('hide');
  $('#modal-feedback').modal('show');
});
$('[name="score"]').change(function(e) {
    $('#score-point').html($(this).val());
});
$('[name="anonymous"]').change(function(e){
    if($(this).is(":checked")) {
        $('[name="feedback_username"]').prop('disabled', true);
    } else {
        $('[name="feedback_username"]').prop('disabled', false);
    }
});
</script><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Staff\resources\views/layouts/partials/modal_feedback.blade.php ENDPATH**/ ?>