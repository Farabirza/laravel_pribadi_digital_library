<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="description" content="cvkreatif.com" />
<meta name="keywords" lan="en" content="blank, laravel, template" />
<meta property="og:type" content="laravel app" />
<meta property="og:title" content="cvkreatif.com" />
<meta property="og:description" content="Buat halaman portofolio kamu di sini, gratis!" />
<meta property="og:url" content="https://www.cvkreatif.com/" />
<meta property="og:site_name" content="www.cvkreatif.com" />
<meta property="og:image" content="<?php echo e(asset('img/bg/office-1.jpg')); ?>" />
<meta property="og:image:type" content="image/jpg" />
<meta property="og:image:width" content="1366" />
<meta property="og:image:height" content="768" />

<meta name="twitter:image" content="<?php echo e(asset('img/bg/office-1.jpg')); ?>">

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.6.0.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>cvkreatif.com <?php if(isset($page_title)): ?>| <?php echo e($page_title); ?> <?php endif; ?></title>
  
<?php echo $__env->yieldPushContent('css-styles'); ?>
<style>
@media (max-width: 768px) {
}
</style>
</head>
<body>
<!-- ======= Mobile nav toggle button ======= -->
<!-- <i class="bi bi-list mobile-nav-toggle d-xl-none"></i> -->

<!-- ======= Header ======= -->
<?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======= Header end ======= -->

<!-- ======= Main content ======= -->
<main id="main">
<?php echo $__env->yieldContent('content'); ?> <!-- Contents here! -->

<!-- include('layouts.partials.footer') ======= Footer ======= -->
</main>
<!-- ======= Main content end ======= -->

<!-- <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a> -->

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>


<script type="text/javascript">
$(document).ready(function(){
  // tooltip
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
  })

  $('.popper').popover({ // require popper.js
      trigger: 'hover',
      html: true,
      placement: 'bottom',
      container: 'body'
  });
  <?php if(Route::currentRouteName() != 'index'): ?>
    var navbarHeight = $('#navbar').outerHeight();
    $('#main').css('padding-top',navbarHeight);
  <?php endif; ?>
  <?php if(session('success')): ?>
    successMessage("<?php echo e(session('success')); ?>");
  <?php elseif(session('error')): ?>
    errorMessage("<?php echo e(session('error')); ?>");
  <?php endif; ?>
  <?php if(isset($_GET['admin'])): ?>
    Swal.fire({
      icon: 'error',
      title: "Akses ditolak!",
      text: "Anda bukan admin!",
      showConfirmButton: false,
      timer: 2000
    });
  <?php endif; ?>
  <?php if(isset($_GET['info'])): ?>
    Swal.fire({
      icon: 'info',
      title: "<?php echo e($_GET['info']); ?>",
      showConfirmButton: false,
      timer: 3000
    });
  <?php endif; ?>
  <?php if(isset($_GET['login'])): ?>
    errorMessage('Anda perlu login terlebih dahulu');
    $('#modal-login').modal('show');
  <?php endif; ?>
  
});
function successMessage(message) { toastr.success(message, 'Success!'); } 
function infoMessage(message) { toastr.info(message, 'Info'); } 
function warningMessage(message) { toastr.error(message, 'Warning!'); } 
function errorMessage(message) { toastr.error(message, 'Error!'); } 
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com - Duplicate\resources\views/layouts/master.blade.php ENDPATH**/ ?>