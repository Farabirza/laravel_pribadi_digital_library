

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/aos/aos.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>" rel="stylesheet">
<style>
body { background: #f9f9f9; }
img { max-width: 100%; }
table tbody { font-size: 11pt; vertical-align: top; }
table thead th { font-weight: 500; }
#book-source a { color: var(--bs-primary) !important; }

.comment-text {
  background-color: #d2d6de;
  color: #444;
  margin: 5px 0 0 20px;
  padding: 10px;
  position: relative;
}
.comment-text::after, .comment-text::before {
  border: solid transparent;
  border-right-color: #d2d6de;
  content: " ";
  height: 0;
  pointer-events: none;
  position: absolute;
  right: 100%;
  top: 15px;
  width: 0;
}
.comment-text::after {
  border-width: 5px;
  margin-top: -5px;
}
.comment-text::before {
  border-width: 6px;
  margin-top: -6px;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content" class="py-4">
    <div class="container">
        <!-- breadcrumb start -->
        <div class="my-4">
            <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item">Book</li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($book->title); ?></li>
                </ol>
            </nav>
        </div>
        <!-- breadcrumb end -->

        <!-- report start -->
        <?php if(Auth::check() && Auth::user()->profile->role != 'student' && count($reports) > 0): ?>
        <div class="row my-4" data-aos="fade-right" data-aos-duration="100">
            <div class="col-md-12 p-4 bg-white rounded shadow">
                <form action="action/book" method="post" id="form-confirm" class="m-0">
                <h3 class="d-flex align-items-center gap-2 fs-18 mb-2"><i class="bx bx-flag"></i>User feedback</h3>
                <p class="fs-11 mb-3">users are noticing some issues with this book and reporting it, please check and confirm when it's solved</p>
                <div class="list-group mb-3">
                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group-item d-flex align-items-center justify-content-between">
                        <div class="col">
                            <table class="table-borderless fs-10">
                                <tr>
                                    <td class="text-primary">From</td>
                                    <td class="px-3">:</td>
                                    <td><?php echo e($item->user->profile->full_name); ?> | <span class="text-muted"><?php echo e($item->user->email); ?></span></td>
                                </tr>
                                <tr>
                                    <td class="text-primary">Subject</td>
                                    <td class="px-3">:</td>
                                    <td><?php echo e($item->subject); ?></td>
                                </tr>
                                <tr>
                                    <td class="text-primary">Additional comment</td>
                                    <td class="px-3">:</td>
                                    <td><?php echo e($item->comment); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="fs-14">
                            <i class="bx bx-check bx-border-circle border-success btn-outline-success p-1 popper" title="solved" role="button" onclick="solved('<?php echo e($item->id); ?>')"></i>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
        <!-- report end -->
        <!-- confirmation start -->
        <?php if(Auth::check() && Auth::user()->profile->role != 'student' && $book->status == 'confirmation'): ?>
        <div class="row my-4" data-aos="fade-right" data-aos-duration="200">
            <div class="col-md-12 p-4 bg-white rounded shadow">
                <form action="action/book" method="post" id="form-confirm" class="m-0">
                <h3 class="d-flex align-items-center gap-2 fs-18 mb-2"><i class="bx bx-check-square"></i>Confirm?</h3>
                <p class="fs-11 mb-3">make sure the information provided by the uploader is correct and the link is working perfectly.</p>
                <div class="mb-3 form-floating fs-11">
                    <input type="text" id="confirm-message" name="message" class="form-control form-control-sm" placeholder="message">
                    <label for="confirm-message" class="form-label">Additional message</label>
                </div>
                <div class="d-flex align-items-center gap-3 fs-18">
                    <i class="bx bx-x bx-border-circle border-danger btn-outline-danger p-1 popper" title="no, delete this book" role="button" onclick="confirmBook(false)"></i>
                    <i class="bx bx-check bx-border-circle border-success btn-outline-success p-1 popper" title="yes, publish this book" role="button" onclick="confirmBook(true)"></i>
                </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
        <!-- confirmation end -->

        <!-- book data start -->
        <div class="row justify-content-center align-items-center p-4 rounded-3 shadow bg-white" data-aos="fade-right" data-aos-duration="300">
            <?php if(count($alerts) > 0): ?>
            <div class="col-md-12 px-4 pt-4 fs-11">
                <div class="alert alert-info">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo $alert; ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
            <div class="col-md-6 p-4">
                <?php if($book->image != null): ?>
                <img src="<?php echo e(asset('img/covers/'.$book->image)); ?>" id="book-image-preview" class="shadow rounded mb-4">
                <?php else: ?>
                <img src="<?php echo e(asset('img/covers/cover-'.rand(1,3).'.jpg')); ?>" id="book-image-preview" class="shadow rounded mb-4">
                <?php endif; ?>
            </div>
            <div class="col-md-6 p-4">
                <div class="d-flex flex-wrap gap-3 mb-3">
                    <a href="/book?search=<?php echo e($book->category->name); ?>" class="bg-primary text-light py-1 px-3 rounded-pill fs-9"><?php echo e($book->category->name); ?></a>
                    <?php if($keywords[0] != null): ?>
                    <?php $__currentLoopData = $keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/book?search=<?php echo e($keyword); ?>" class="btn btn-outline-secondary py-1 px-3 rounded-pill fs-9"><?php echo e($keyword); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="mb-4">
                    <h3 id="book-title" class="display-5 pb-2" style="font-size:28pt;"><?php echo e($book->title); ?></h3>
                    <hr class="w-25 border border-primary border-1 opacity-75">
                </div>
                <?php $book_rating = floor(($rating ? $rating/count($book->review) : 0)); ?>
                <div class="d-flex gap-2 mb-3 fs-18">
                    <?php for($i=1; $i <= 5; $i++): ?>
                    <?php if($i > $book_rating): ?>
                    <i class="bx bxs-star"></i>
                    <?php else: ?>
                    <i class="bx bxs-star" style="color:#ffa723"></i>
                    <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <p class="fs-11 mb-3">Rating : <b><?php echo e(($rating ? number_format((float)($rating/count($book->review)), 2, '.', '') : 0)); ?></b> | <?php echo e(count($book->review)); ?> review(s) | <?php echo e(count($book->logVisit)); ?> visitor(s)</p>
                <?php if(Auth::check() && $book->status == 'active'): ?>
                <div class="mb-3 d-flex gap-3">
                    <?php if($bookmark): ?>
                    <i id="btn-bookmark" class="bx bxs-bookmark bx-border-circle btn-success p-2 popper" title="Bookmark" role="button" onclick="toggleBookmark()"></i>
                    <?php else: ?>
                    <i id="btn-bookmark" class="bx bxs-bookmark bx-border-circle border-success btn-outline-success p-2 popper" title="Bookmark" role="button" onclick="toggleBookmark()"></i>
                    <?php endif; ?>
                    <?php if($report != null && $report->solved == 0): ?>
                    <i class="bx bxs-flag-alt bx-border-circle btn-danger p-2 popper" title="Report problem" role="button" onclick="modalReport('<?php echo e($book->id); ?>')"></i>
                    <?php else: ?>
                    <i class="bx bxs-flag-alt bx-border-circle border-danger btn-outline-danger p-2 popper" title="Report problem" role="button" onclick="modalReport('<?php echo e($book->id); ?>')"></i>
                    <?php endif; ?>
                    <?php if($review != null): ?>
                    <i class="bx bxs-message bx-border-circle btn-primary p-2 popper" title="Review" role="button" onclick="modalReview('<?php echo e($book->id); ?>')"></i>
                    <?php else: ?>
                    <i class="bx bxs-message bx-border-circle border-primary btn-outline-primary p-2 popper" title="Review" role="button" onclick="modalReview('<?php echo e($book->id); ?>')"></i>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <div class="fs-11 mb-0 d-flex flex-wrap gap-2">
                    <?php if($book->author): ?>
                    <span class="fw-bold ls-1"><?php echo e($book->author); ?></span>
                    <?php endif; ?>
                    <?php if($book->publisher): ?>
                    | <span class=""><?php echo e($book->publisher); ?></span>
                    <?php endif; ?>
                    <?php if($book->publication_year): ?>
                    | <span class=""><?php echo e($book->publication_year); ?></span>
                    <?php endif; ?>
                </div>
                <p class="fs-11 text-secondary mb-3"><?php echo e(($book->description ? $book->description : '-')); ?></p>
                <table class="table-borderless mb-4">
                    <tr>
                        <td>ISBN</td>
                        <td class="px-3">:</td>
                        <td><?php echo e(($book->isbn ? $book->isbn : '-')); ?></td>
                    </tr>
                    <tr>
                        <td>Source</td>
                        <td class="px-3">:</td>
                        <td id="book-source"><?php echo ($book->source ? $book->source : '-'); ?></td>
                    </tr>
                    <tr>
                        <td>Posted by</td>
                        <td class="px-3">:</td>
                        <td><a href="" class="text-primary"><?php echo e($book->user->profile->full_name); ?></a> <span class="text-secondary">on <?php echo e(date('F jS, Y', strtotime($book->created_at))); ?></span></td>
                    </tr>
                    <tr>
                        <td>Last update</td>
                        <td class="px-3">:</td>
                        <td class="text-secondary"><?php echo e(date('F jS, Y', strtotime($book->updated_at))); ?></td>
                    </tr>
                </table>
                <div class="d-flex flex-wrap align-items-center gap-3">
                    <?php if(Auth::check() && Auth::user()->profile->role != 'student'): ?>
                    <a href="/book/<?php echo e($book->id); ?>/delete" class="btn btn-sm btn-danger gap-2 btn-warn" data-warning="Once deleted everything related to this book will be lost"><i class="bx bx-trash-alt"></i>Delete</a>
                    <a href="/book/<?php echo e($book->id); ?>/edit" class="btn btn-sm btn-success gap-2"><i class="bx bx-edit-alt"></i>Edit</a>
                    <?php endif; ?>
                    <a target="_blank"  href="/<?php echo e($book->id); ?>/0/read" class="btn btn-sm btn-primary gap-2"><i class="bx bx-book-content"></i>Read</a>
                </div>
            </div>
            <div class="col-md-12 p-4">
                <h3 class="d-flex align-items-center gap-2 fs-18 mb-3"><i class="bx bx-list-ul"></i>Chapters</h3>
                <div class="mb-3 list-group">
                    <a target="_blank" href="/<?php echo e($book->id); ?>/0/read" class="list-group-item list-group-item-action d-flex align-items-center gap-2 fs-12 text-primary"><i class="bx bx-book-content"></i>Full content</a>
                </div>
                <?php $i = 1; ?>
                <div class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $book->chapter->sortBy('number'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a target="_blank" href="/<?php echo e($book->id); ?>/<?php echo e($chapter->id); ?>/read" class="list-group-item list-group-item-action fs-11 text-primary mb-0"><?php echo e($chapter->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="list-group-item fs-11 fst-italic text-secondary">No chapter listed</p>
                <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- book data end -->

        <?php if($book->status == 'active'): ?>
        <!-- section review start -->
        <div class="row my-4" data-aos="fade-right" data-aos-duration="400">
            <div class="col-md-12 p-4 bg-white rounded shadow">
                <h3 class="d-flex align-items-center gap-2 fs-18 mb-3"><i class="bx bx-message"></i>Reviews</h3>
                <!-- my review start -->
                <?php if($review != null): ?>
                <div class="mb-3 d-flex align-items-center gap-4 border rounded p-4">
                    <div class="">
                        <?php if(Auth::user()->picture): ?>
                        <img src="<?php echo e(asset('img/profiles/'.Auth::user()->picture)); ?>" class="img-fluid border rounded-circle" style="max-height:120px">
                        <?php else: ?>
                        <img src="<?php echo e(asset('img/profiles/user.jpg')); ?>" class="img-fluid border rounded-circle" style="max-height:120px">
                        <?php endif; ?>
                    </div>
                    <div class="col fs-11">
                        <p class="mb-1">
                            <span class="fw-bold"><?php echo e(Auth::user()->profile->full_name); ?></span> | <?php echo e(Auth::user()->email); ?>

                        </p>
                        <div class="d-flex align-items-center gap-2 mb-2 fs-11">
                            <?php for($i=1; $i <= 5; $i++): ?>
                            <?php if($i > $review->rating): ?>
                            <i class="bx bxs-star"></i>
                            <?php else: ?>
                            <i class="bx bxs-star" style="color:#ffa723"></i>
                            <?php endif; ?>
                            <?php endfor; ?>
                            <span class="fs-11 text-secondary ms-2"><?php echo e(date('d/m/Y', strtotime($review->created_at))); ?></span>
                        </div>
                        <p class="fs-11 text-secondary mb-3"><?php echo e($review->comment); ?></p>
                        <p class="fs-11 d-flex gap-2 mb-0">
                            <span class="hover-underline" role="button" onclick="modalReview('<?php echo e($book->id); ?>')">Edit</span> | <a href="/review/<?php echo e($book->id); ?>/delete" class="hover-underline btn-warn" data-warning="">Delete</a>
                        </p>
                    </div>
                </div>
                <?php endif; ?>
                <!-- my review end -->
                <!-- reviews start -->
                <div id="container-reviews" class="mb-3">
                    <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if(Auth::check() && $item->user->id != Auth::user()->id): ?>
                    <div class="review-comment mb-3">
                        <div class="d-flex">
                            <img class="comment-img img-fluid rounded-circle border" src="<?php echo e(asset('/img/profiles/'.($item->user->picture ? $item->user->picture : 'user.jpg'))); ?>" style="max-height:100px">
                            <div class="comment-text rounded fs-11">
                                <p class="mb-1">
                                    <span class="fw-bold"><?php echo e($item->user->profile->full_name); ?></span> | <?php echo e($item->user->email); ?>

                                </p>
                                <div class="d-flex align-items-center gap-1 mb-2">
                                    <?php for($i=1; $i <= 5; $i++): ?>
                                    <?php if($i > $item->rating): ?>
                                    <i class="bx bxs-star"></i>
                                    <?php else: ?>
                                    <i class="bx bxs-star" style="color:#ffa723"></i>
                                    <?php endif; ?>
                                    <?php endfor; ?>
                                    <span class="fs-11 text-secondary ms-2"><?php echo e(date('d/m/Y', strtotime($item->created_at))); ?></span>
                                    <?php $__currentLoopData = $item->user->bookmark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookmark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($bookmark->book_id == $book->id): ?>
                                    <i class="bx bx-bookmark bx-border-circle border-success bg-success text-light ms-1 p-1"></i>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <p class="mb-0"><?php echo e($item->comment); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="fs-11 mb-0 d-flex"><span class="btn btn-sm btn-outline-primary gap-2" role="button" onclick="modalReview('<?php echo e($book->id); ?>')">Be the first to review this book!</span></p>
                    <?php endif; ?>
                </div>
                <!-- reviews end -->
            </div>
        </div>
        <!-- section review end -->
        <!-- section record start -->
        <div class="row my-4" data-aos="fade-right" data-aos-duration="600">
            <div class="col-md-12 p-4 bg-white rounded shadow">
                <h3 class="d-flex align-items-center gap-2 fs-18 mb-3"><i class="bx bx-history"></i>Visit record</h3>
                <div class="table-container mb-3">
                    <table id="table-record" class="table table-striped">
                        <thead>
                            <th>Date of visit</th>
                            <th>Name</th>
                            <th>Role</th>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(date('l, j F Y | h:i A', strtotime($record->created_at))); ?></td>
                                <td><?php echo e($record->user->profile->full_name); ?></td>
                                <?php if($record->user->profile->role != 'student'): ?>
                                <td><?php echo e($record->user->profile->role); ?></td>
                                <?php else: ?>
                                <td>Grade <?php echo e($record->user->profile->grade + date('Y', time()) - $record->user->profile->year_join); ?></td>
                                <?php endif; ?>
                            </tr>
                            <?php $i++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- section record end -->
        <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('layouts.partials.modal_book', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script type="text/javascript">
<?php if(auth()->guard()->check()): ?>
const solved = (report_id) => {
    let formData = { action: 'solved', report_id: report_id, }
    let config = {
        method: 'post', url: domain + 'action/report', data: formData,
    }
    axios(config)
    .then((response) => {
        successMessage(response.data.message);
        return location.reload();
    })
    .catch((error) => {
        console.log(error);
        errorMessage(error.response.data.message);
    });
}

const confirmBook = (confirmed) => {
    let formData = {
        action: 'confirm_book', book_id: "<?php echo e($book->id); ?>", 
        confirmed: confirmed, message: $('#confirm-message').val(),
    }
    console.log(formData);
    let config = {
        method: 'post', url: domain + 'action/book', data: formData,
    }
    axios(config)
    .then((response) => {
        successMessage(response.data.message);
        return location.reload();
    })
    .catch((error) => {
        console.log(error);
        errorMessage(error.response.data.message);
    });
}

const toggleBookmark = () => {
    let formData = {
        user_id: '<?php echo e(Auth::user()->id); ?>', book_id: '<?php echo e($book->id); ?>',
    }
    let config = {
        method: 'post', url: domain + 'bookmark', data: formData,
    }
    axios(config)
    .then((response) => {
        successMessage(response.data.message);
        if(response.data.exist) {
            $('#btn-bookmark').removeClass('border-success btn-outline-success').addClass('btn-success');
        } else {
            $('#btn-bookmark').removeClass('btn-success').addClass('border-success btn-outline-success');
        }
    })
    .catch((error) => {
        errorMessage(error.response.data);
        console.log(error);
    });
};
<?php endif; ?>

var tablerecord = $('#table-record').dataTable();
// Animate on scroll
AOS.init({ once: true,  easing: 'ease-in-out-sine' });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital Library - New\Pribadi Depok Digital Library\resources\views/book/show.blade.php ENDPATH**/ ?>