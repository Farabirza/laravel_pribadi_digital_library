

<!-- Modal Login -->
<div class="modal fade" id="modal-login" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center fw-bold"><i class='bx bx-log-in-circle me-2'></i><span>Masuk ke akun kamu</span></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/login" id="form-login" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="form-floating mb-3">
                    <input type="email" name="email" id="modal-login-email" class="form-control form-control-sm" placeholder="Email" value="" required>
                    <label for="modal-login-email" class="label">Email</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" name="password" id="modal-login-password" class="form-control form-control-sm" placeholder="Password" value="" required>
                    <label for="modal-login-password" class="label">Password</label>
                </div>
                <div class="form-outline mb-3">
                    <p class="text-muted" style="color: #393f81;"><input type="checkbox" name="remember" value="true" class="mr-8"> Ingat saya</p>
                </div>
                <p class="text-muted">Belum punya akun? <a class="btn-modal-register text-primary" href="#">Daftar</a></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <button type="submit" class="btn btn-sm btn-primary"><i class='bx bx-log-in-circle' ></i> Sign in</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal Login end -->
<!-- Modal Register -->
<div class="modal fade" id="modal-register" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center fw-bold"><i class='bx bxs-user-plus me-2'></i><span>Buat akun baru</span></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/register" id="form-register" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="form-floating mb-3">
                    <input type="text" name="username" id="modal-register-username" class="form-control form-control-sm" placeholder="Username" value="" required>
                    <label for="modal-register-username" class="label">Username</label>
                </div>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="alert-danger-username" class="alert alert-danger mb-3"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="text-muted fst-italic fs-9 mb-2">*username akan menjadi acuan alamat CV anda, contoh: https://cvkreatif.com/cv/john_doe</p>
                <p class="text-muted fst-italic fs-9 mb-3">*hanya gunakan kombinasi huruf, angka, atau underscore ('_')</p>
                <div class="form-floating mb-3">
                    <input type="email" name="email" id="modal-register-email" class="form-control form-control-sm" placeholder="Email" value="" required>
                    <label for="modal-register-email" class="label">Email</label>
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="alert-danger-email" class="alert alert-danger mb-3"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-floating mb-3">
                    <input type="password" name="password" id="modal-register-password" class="form-control form-control-sm" placeholder="Password" value="" required>
                    <label for="modal-register-password" class="label">Password</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" id="modal-register-password_confirmation" class="form-control form-control-sm" name="password_confirmation" placeholder="Confirm Password" required>
                    <label for="modal-register-password_confirmation" class="form-label">Confirm password</label>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="alert-danger-password" class="alert alert-danger mb-3"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="text-muted fst-italic fs-9 mb-3">*Password minimal terdiri dari 6 karakter</p>
                <div class="form-outline mb-3">
                    <p class="" style="color: #393f81;"><input type="checkbox" name="agreement" value="true" class="mr-8"> Saya setuju dengan <a class="btn-terms-show text-primary" href="#">syarat dan ketentuan</a> yang berlaku</p>
                </div>
                <p class="text-muted">Sudah punya akun? <a class="btn-modal-login text-primary" href="#">Masuk</a></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Batalkan</button>
                <button type="submit" class="btn btn-sm btn-primary"><i class='bx bx-log-in-circle' ></i> Daftar</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal Register end -->

<!-- Modal Terms start -->
<div class="modal fade" id="modal-terms" aria-hidden="true"> 
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center"><i class='bx bx-file me-2'></i>Terms of Service Agreement</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <ol>
                <li>
                    <p>Pendahuluan: Persyaratan ini menetapkan ketentuan dan syarat yang berlaku untuk penggunaan <b>CVKreatif</b>. Dengan mengakses atau menggunakan Layanan, Anda mengakui bahwa Anda telah membaca, memahami, dan setuju untuk terikat oleh persyaratan ini.</p>
                </li>
                <li>
                    <p>Deskripsi Layanan: Layanan adalah aplikasi web yang memungkinkan pengguna untuk membuat dan mengedit resume dan surat lamaran profesional. Kami berhak untuk memodifikasi atau menghentikan Layanan kapan saja tanpa pemberitahuan kepada Anda.</p>
                </li>
                <li>
                    <p>Penggunaan Layanan: Anda hanya dapat menggunakan Layanan sesuai dengan ketentuan dalam persyaratan ini dan semua undang-undang dan peraturan yang berlaku. Anda bertanggung jawab untuk mempertahankan kerahasiaan akun dan kata sandi Anda dan untuk membatasi akses ke akun Anda.</p>
                </li>
                <li>
                    <p>Hak Atas Kekayaan Intelektual: Layanan, termasuk semua perangkat lunak, konten, dan bahan lain, dilindungi oleh hukum hak atas kekayaan intelektual dan merupakan milik <b>CVKreatif</b> atau pemegang lisensinya. Anda tidak diperbolehkan menggunakan Layanan untuk tujuan komersial tanpa persetujuan tertulis dari <b>CVKreatif</b>.</p>
                </li>
                <li>
                    <p>Batasan Tanggung Jawab: <b>CVKreatif</b> tidak bertanggung jawab atas kerugian yang timbul dari penggunaan Layanan, termasuk namun tidak terbatas pada kerugian tidak langsung, insidental, khusus, atau akibat.</p>
                </li>
                <li>
                    <p>Pencabutan: <b>CVKreatif</b> berhak, atas kebijakannya sendiri, kapan saja mengakhiri atau menangguhkan seluruh atau sebagian dari Layanan, atau penggunaan seluruh atau sebagian dari Layanan, dengan atau tanpa pemberitahuan dan dengan atau tanpa alasan.</p>
                </li>
                <li>
                    <p>Perubahan pada Persyaratan Layanan: <b>CVKreatif</b> berhak memodifikasi persyaratan ini kapan saja. Penggunaan Anda terus-menerus dari Layanan setelah modifikasi apapun merupakan pengakuan Anda untuk terikat oleh ketentuan dari persyaratan yang dimodifikasi.</p>
                </li>
                <!-- <li>
                    <p>Hukum Yang Berlaku: Persyaratan ini akan ditentukan oleh hukum [masukkan yurisdiksi].</p>
                </li> -->
                <li>
                    <p>Keseluruhan Persetujuan: Persyaratan ini merupakan keseluruhan persetujuan antara Anda dan <b>CVKreatif</b> dan menggantikan semua perjanjian sebelumnya dan kesepakatan sehubungan dengan Layanan.</p>
                </li>
                <li>
                    <p>Pemisahan: Jika salah satu bagian dari persyaratan ini ditemukan tidak sah oleh pengadilan, bagian tersebut akan dicabut dan tidak mempengaruhi validitas bagian lain dari persyaratan ini.</p>
                </li>
                <li>
                    <p>Kontak Kami: Jika Anda memiliki pertanyaan atau komentar tentang Persyaratan Layanan ini, silakan menghubungi kami melalui <b>adm.cvkreatif@gmail.com</b>.</p>
                </li>
            </ol>
            <p>Dengan menggunakan Layanan ini, Anda mengakui bahwa Anda telah membaca perjanjian ini, memahami dan setuju untuk terikat oleh ketentuannya.</p>
            </div>
            <div class="modal-footer">
                <button class="btn-modal-register btn btn-success mr-3">Saya mengerti</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal Terms end -->

<script type="text/javascript">
$('.btn-modal-login').click(function(e){
  e.preventDefault();
  $('.modal').modal('hide');
  $('#modal-login').modal('show');
});
$('.btn-modal-register').click(function(e){
  e.preventDefault();
  $('.modal').modal('hide');
  $('#modal-register').modal('show');
});
$('.btn-terms-show').click(function(e){
    e.preventDefault();
  $('.modal').modal('hide');
  $('#modal-terms').modal('show');
});
$('#form-register').submit(function(e){
    e.preventDefault();
    if($('input[name="agreement"]').is(":checked")) {
        e.currentTarget.submit();
    } else {
        Swal.fire({
            icon: 'error',
            title: "Tidak dapat melanjutkan!",
            text: "Anda perlu konfirmasi persetujuan syarat dan ketentuan untuk dapat melanjutkan proses registrasi",
            showConfirmButton: true,
        });
    }
});
$(document).ready(function(){
    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    errorMessage('Username error : <?php echo e($message); ?>');
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    errorMessage('Email error : <?php echo e($message); ?>');
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    errorMessage('Password error : <?php echo e($message); ?>');
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
});
</script><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/layouts/partials/modal_auth.blade.php ENDPATH**/ ?>