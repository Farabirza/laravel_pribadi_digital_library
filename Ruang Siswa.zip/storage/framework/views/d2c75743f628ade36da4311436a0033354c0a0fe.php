<?php if(auth()->guard()->guest()): ?>
<?php header("Location: /?login=required"); die(); ?>
<?php endif; ?>



<?php $__env->startPush('css-styles'); ?>
<style>
#main { min-height: 100vh; background: #f9f9f9; }
.bl-darkblue-md { color: #374785; }

@media (max-width: 768px) {
    #section-form { padding-top: 20px; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<section id="section-form" class="py-40">
    <div class="container">

        <?php echo $__env->make('cv.partials.wizard_progressbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('cv.partials.wizard_disclaimer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-------- form start -------->
        <form id="form-profile" action="/form/cv/profile" method="POST">

        <div class="row mb-5 align-items-center">
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold ps-3 mb-3 fs-32 bl-darkblue-md">Data Pribadi</h3>
            </div>

            <div class="col-md-12 card bg-white p-4 shadow-sm"> <!-- col form start -->

                <!-- name  -->
                <div class="form-group d-flex flex-remove-md mb-4">
                    <div class="form-floating col">
                        <input type="text" class="form-control" name="first_name" placeholder="Nama depan" value="<?php if($profile->first_name): ?><?php echo e($profile->first_name); ?><?php else: ?><?php echo e(old('first_name')); ?><?php endif; ?>" required>
                        <label for="first_name" class="form-label">Nama depan*</label>
                    </div>
                    <span>&ensp;</span>
                    <div class="form-floating col">
                        <input type="text" class="form-control" name="last_name" placeholder="Nama belakang" value="<?php if($profile->last_name): ?><?php echo e($profile->last_name); ?><?php else: ?><?php echo e(old('last_name')); ?><?php endif; ?>">
                        <label for="last_name" class="form-label">Nama belakang</label>
                    </div>
                </div>
                <!-- name end -->

                <!-- gender & birth data  -->
                <div class="form-group mb-4">
                    <div class="d-flex flex-remove-md">
                        <div class="form-floating col">
                            <select id="gender" name="gender" class="form-control form-select" required>
                                <!-- <option value="select" selected disabled hidden>Gender</option> -->
                                <?php if(isset($profile->gender)): ?>
                                <option value="male" <?php if($profile->gender === 'male'): ?> selected <?php endif; ?>>Laki-laki</option>
                                <option value="female" <?php if($profile->gender === 'female'): ?> selected <?php endif; ?>>Perempuan</option>
                                <?php else: ?>
                                <option value="select" selected disabled hidden>Gender</option>
                                <option value="male">Laki-laki</option>
                                <option value="female">Perempuan</option>
                                <?php endif; ?>
                            </select>
                            <label for="gender" class="form-label">Jenis kelamin*</label>
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <span>&ensp;</span>
                        <div class="form-floating col">
                            <input type="date" min="1950-01-01" max="<?php echo e(date('Y-m-d', time())); ?>" id="birth_date" class="form-control" name="birth_date" value="<?php if(isset($profile->birth_date)): ?><?php echo e($profile->birth_date); ?><?php endif; ?>">
                            <label for="birth_date" class="form-label">Tanggal lahir</label>
                        </div>
                    </div>
                </div>
                <!-- gender & birth data end -->
                
                <!-- address -->
                <div class="form-group mb-4">
                    <label class="text-muted mb-2">Domisili</label>
                    <div class="d-flex flex-remove-md">
                        <div class="form-floating col">
                            <input type="text" class="form-control" name="address_city" placeholder="City" value="<?php if(isset($profile->address_city)): ?><?php echo e($profile->address_city); ?><?php else: ?><?php echo e(old('city')); ?><?php endif; ?>">
                            <label for="city" class="form-label">Kota / kabupaten</label>
                        </div>
                        <span>&ensp;</span>
                        <div class="form-floating col">
                            <input type="text" class="form-control" name="address_province" placeholder="Province" value="<?php if(isset($profile->address_province)): ?><?php echo e($profile->address_province); ?><?php else: ?><?php echo e(old('address_province')); ?><?php endif; ?>">
                            <label for="province" class="form-label">Provinsi</label>
                        </div>
                        <span>&ensp;</span>
                        <div class="form-floating col">
                            <input type="number" class="form-control" name="address_zip" placeholder="ZIP" value="<?php if(isset($profile->address_zip)): ?><?php echo e($profile->address_zip); ?><?php else: ?><?php echo e(old('address_zip')); ?><?php endif; ?>" maxlength="5">
                            <label for="address_zip" class="form-label">Kode pos</label>
                        </div>
                    </div>
                </div>
                <!-- address -->

                <!-- profession  -->
                <div class="form-group mb-4">
                    <div class="form-floating col">
                        <input type="text" class="form-control" name="profession" placeholder="Profesi" value="<?php if(isset($profile->profession)): ?><?php echo e($profile->profession); ?><?php else: ?><?php echo e(old('profession')); ?><?php endif; ?>" required>
                        <label for="profession" class="form-label">Profesi*</label>
                    </div>
                </div>
                <!-- profession end -->

                <!-- biodata -->
                <div class="form-group mb-4">
                    <label class="text-muted mb-2">Biodata</label>
                    <textarea name="biodata" id="biodata" cols="30" rows="4" class="form-control" placeholder="Ceritakan secara singkat tentang dirimu"><?php if(isset($profile->biodata)): ?><?php echo e($profile->biodata); ?><?php else: ?><?php echo e(old('biodata')); ?><?php endif; ?></textarea>
                </div>
                <!-- biodata end -->

                <div class="form-group"><span class="text-muted fst-italic fs-11">*Wajib diisi</span></div>

            </div><!-- col form start end -->
        </div> <!-- row end -->

        <div class="row justify-content-center mb-5"> <!-- row start -->
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold ps-3 mb-3 fs-32 bl-darkblue-md">Media Sosial</h3>
            </div>
            <div class="col-md-12 card bg-white py-4 px-5 shadow-sm">

                <!-- linkedin -->
                <div class="form-group mb-4">
                    <label class="text-muted mb-2">Email*</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#BB001B"><i class='bx bx-envelope'></i></span>
                        <input type="text" name="prof_email" class="form-control" placeholder="Email" value="<?php if(isset($profile->prof_email)): ?><?php echo e($profile->prof_email); ?><?php else: ?><?php echo e(Auth::user()->email); ?><?php endif; ?>">
                    </div>
                    <p class="fst-italic text-muted fs-11 mb-0">*alamat email yang akan ditayangkan pada halaman CV</p>
                </div>
                <!-- linkedin end -->

                <!-- linkedin -->
                <div class="form-group mb-4">
                    <label class="text-muted mb-2">LinkedIn</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#0e76a8"><i class='bx bxl-linkedin'></i></span>
                        <input type="text" name="li_username" class="form-control" placeholder="Username" value="<?php if(isset($profile->li_username)): ?><?php echo e($profile->li_username); ?><?php else: ?><?php echo e(old('li_username')); ?><?php endif; ?>">
                    </div>
                    <input type="text" name="li_url" class="form-control" placeholder="Profile URL" value="<?php if(isset($profile->li_url)): ?><?php echo e($profile->li_url); ?><?php else: ?><?php echo e(old('li_url')); ?><?php endif; ?>">
                </div>
                <!-- linkedin end -->

                <!-- twitter -->
                <div class="form-group mb-4">
                    <label class="text-muted mb-2">Twitter</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#1DA1F2"><i class='bx bxl-twitter'></i></span>
                        <input type="text" name="tw_username" class="form-control" placeholder="Username" value="<?php if(isset($profile->tw_username)): ?><?php echo e($profile->tw_username); ?><?php else: ?><?php echo e(old('tw_username')); ?><?php endif; ?>">
                    </div>
                    <input type="text" name="tw_url" class="form-control" placeholder="Profile URL" value="<?php if(isset($profile->tw_url)): ?><?php echo e($profile->tw_url); ?><?php else: ?><?php echo e(old('tw_url')); ?><?php endif; ?>">
                </div>
                <!-- linkedin end -->

                <!-- instagram -->
                <div class="form-group mb-4">
                    <label class="text-muted mb-2">Instagram</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#dd2a7b"><i class='bx bxl-instagram'></i></span>
                        <input type="text" name="ig_username" class="form-control" placeholder="Username" value="<?php if(isset($profile->ig_username)): ?><?php echo e($profile->ig_username); ?><?php else: ?><?php echo e(old('ig_username')); ?><?php endif; ?>">
                    </div>
                    <input type="text" name="ig_url" class="form-control" placeholder="Profile URL" value="<?php if(isset($profile->ig_url)): ?><?php echo e($profile->ig_url); ?><?php else: ?><?php echo e(old('ig_url')); ?><?php endif; ?>">
                </div>
                <!-- instagram end -->

                <!-- facebook -->
                <div class="form-group mb-4">
                    <label class="text-muted mb-2">Facebook</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#3b5998"><i class='bx bxl-facebook'></i></span>
                        <input type="text" name="fb_username" class="form-control" placeholder="Username" value="<?php if(isset($profile->fb_username)): ?><?php echo e($profile->fb_username); ?><?php else: ?><?php echo e(old('fb_username')); ?><?php endif; ?>">
                    </div>
                    <input type="text" name="fb_url" class="form-control" placeholder="Profile URL" value="<?php if(isset($profile->fb_url)): ?><?php echo e($profile->fb_url); ?><?php else: ?><?php echo e(old('fb_url')); ?><?php endif; ?>">
                </div>
                <!-- facebook end -->

                <!-- Website -->
                <div class="form-group mb-4">
                    <label class="text-muted mb-2">Website</label>
                    <div class="input-group rounded mb-3">
                        <span class="input-group-text text-white" style="background:#404040"><i class='bx bx-link-alt'></i></span>
                        <input type="text" name="web_name" class="form-control" placeholder="Site name" value="<?php if(isset($profile->web_name)): ?><?php echo e($profile->web_name); ?><?php else: ?><?php echo e(old('web_name')); ?><?php endif; ?>">
                    </div>
                    <input type="text" name="web_url" class="form-control" placeholder="Site URL" value="<?php if(isset($profile->web_url)): ?><?php echo e($profile->web_url); ?><?php else: ?><?php echo e(old('web_url')); ?><?php endif; ?>">
                </div>
                <!-- Website end -->

            </div>
        </div> <!-- row end -->


        <div class="row"> <!-- row start -->
            <!-- form button -->
            <hr class="mb-3"/>
            <div class="form-group d-flex justify-content-end">
                <button type="submit" class="btn btn-success me-2 disabled btn-form-save"><i class='bx bxs-save' ></i> Simpan</button>
                <a href="/wizard/education?from=10" class="btn btn-primary me-2"><i class='bx bx-right-arrow-alt' ></i> Selanjutnya</a>
            </div>
            <!-- form button end -->
        </div> <!-- row end -->

        </form>
        <!-------- form end -------->

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function(e){
    // Progressbar
    $('.progress-list').removeClass('progress-list-active');
    $('#progress-list-profile').addClass('progress-list-active');
    $('.progress-bar').css('width','10%').attr('aria-valuenow','10');

    // Form
    $('#form-profile').change(function(e){
        $('.btn-form-save').removeClass('disabled');
    });
});
</script>
<script src="<?php echo e(asset('/js/script_progressbar.js')); ?>"></script>
<script src="<?php echo e(asset('/js/ajax_wizard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/wizard_profile.blade.php ENDPATH**/ ?>