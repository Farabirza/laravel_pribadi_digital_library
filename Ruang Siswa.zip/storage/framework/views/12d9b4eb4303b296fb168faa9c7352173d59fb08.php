

<?php $__env->startPush('css-styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-username" class="py-4">
    <div class="container">
        <form action="/auth/google/register" method="post">
        <?php echo csrf_field(); ?>
        <div class="row justify-content-center">
            <div class="col-md-12 card shadow p-4">
                <h3 class="display-5 fs-32 mb-3">Create username</h3>
                <?php if(isset($user)): ?>
                <div class="mb-3 text-primary">
                    <b><?php echo e($user->name); ?></b> | <?php echo e($user->email); ?>

                </div>
                <input type="hidden" name="google_email" value="<?php echo e($user->email); ?>">
                <input type="hidden" name="google_id" value="<?php echo e($user->google_id); ?>">
                <?php endif; ?>
                <div class="input-group form-floating mb-3">
                    <input type="text" name="username" id="modal-register-username" class="form-control form-control-sm" placeholder="Username" value="" required>
                    <span class="input-group-text hover-pointer fs-10" onclick="handleUsername()">Check username</span>
                    <label for="modal-register-username" class="label">Username</label>
                </div>
                <div class="mb-3">
                    <p id="username-check-result" class="mb-0 fs-10"><span class="fst-italic text-secondary">*please check the username availability first</span></p>
                </div>
                <div class="d-flex justify-content-end">
                    <a href="/" class="btn btn-secondary d-flex align-items-center me-3"><i class='bx bx-arrow-back me-2'></i>Back</a>
                    <button type="submit" id="btn-submit-username" class="btn btn-primary d-flex align-items-center disabled"><i class='bx bx-user-plus me-2' ></i>Submit</button>
                </div>
            </div>
        </div>
        </form>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
$(document).ready(function(){
    $('#btn-auth-signin').css('display', 'none');
});

$('[name="username"]').keyup(function(){
    $('#btn-submit-username').removeClass('disabled').addClass('disabled');
    $('#username-check-result').html('<span class="fst-italic text-secondary">*please check username availability first</span>');
})

const handleUsername = () => {
    let result = $('#username-check-result');
    let username = $('[name="username"]').val();
    result.html('<span class="btn spinner"></span>');
    var config = {
        method: 'post', url: this.domain + 'api/user',
        data: {
            action: 'check_username', username: username,
        },
    }
    axios(config)
    .then((response) => {
        if(response.data.available) {
            result.html('<span class="fs-bold text-success"><i class="bx bx-check-double me-1" ></i>' + response.data.response_message + '</span>');
            $('#btn-submit-username').removeClass('disabled');
        } else {
            if(response.data.response_message.length > 1) {
                result.html('');
                response.data.response_message.forEach(messages);
                function messages(item, index) {
                    result.append('<span class="fs-bold text-danger"><i class="bx bx-error me-1" ></i>' + item + '</span><br/>');
                }
            } else {
                result.html('<span class="fs-bold text-danger"><i class="bx bx-error me-1" ></i>' + response.data.response_message + '</span>');
            }
            $('#btn-submit-username').removeClass('disabled').addClass('disabled');
        }
    })
    .catch((error) => {
        console.log(error);
    });
}

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Staff\resources\views/user/create_username.blade.php ENDPATH**/ ?>