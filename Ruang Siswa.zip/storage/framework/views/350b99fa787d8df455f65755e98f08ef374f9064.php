<?php if(auth()->guard()->guest()): ?>
<?php header("Location: /?login=required"); die(); ?>
<?php endif; ?>



<?php $__env->startPush('css-styles'); ?>
<style>
#main { min-height: 100vh; background: #f9f9f9; }
.bl-darkblue-md { color: #374785; }

.certif-item-add { min-height: 240px; }
.certif-item .card:hover { 
    cursor: pointer; 
    color: #fff;
    background-color: #0d6efd;
    transition: ease-in-out .3s;
} .certif-img { max-height: 240px; }
@media (max-width: 768px) {
    #section-form { padding-top: 20px; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-form" class="py-40">
    <div class="container">
        <?php echo $__env->make('cv.partials.wizard_progressbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('cv.partials.wizard_disclaimer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-------- form start -------->
        <form id="form-education" method="POST" class="mb-5">

        <div class="row align-items-center mb-3"> <!-- row start -->
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold ps-3 fs-32 bl-darkblue-md">Riwayat Pendidikan</h3>
            </div>
            <div class="col-md-12"> <!-- col form start -->

            <!-- education history start -->
            <div class="edu-container">
                <?php $i = 1; ?>
                <?php $__empty_1 = true; $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div id="edu-list-item-<?php echo e($i); ?>" class="d-flex flex-remove-md list-item card bg-white p-4 shadow-sm mb-4"> <!-- item --> 
                    <input type="hidden" name="education_id-<?php echo e($i); ?>" value="<?php echo e($edu->id); ?>">
                    <div class="form-group col">
                        <div class="d-flex mb-2 flex-remove-md">
                            <div class="d-flex col align-middle align-items-center mb-2">
                                <div class="form-floating col">
                                    <input type="number" class="form-control" name="year_start-<?php echo e($i); ?>" placeholder="year from" value="<?php echo e($edu->year_start); ?>" required>
                                    <label for="year_start-<?php echo e($i); ?>" class="form-label">Tahun masuk</label>
                                </div>
                                <span>&ensp;-&ensp;</span>
                                <div class="form-floating col">
                                    <input type="number" class="form-control" name="year_end-<?php echo e($i); ?>" placeholder="year to" value="<?php echo e($edu->year_end); ?>">
                                    <label for="year_end-<?php echo e($i); ?>" class="form-label">Tahun lulus*</label>
                                </div>
                            </div>
                            <span class="remove-md">&ensp;</span>
                            <div class="form-floating col mb-1">
                                <input type="text" class="form-control" name="institution-<?php echo e($i); ?>" placeholder="education history" value="<?php echo e($edu->institution); ?>" required>
                                <label for="institution-<?php echo e($i); ?>" class="form-label">Institusi pendidikan</label>
                            </div>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" name="major-<?php echo e($i); ?>" placeholder="education history" value="<?php echo e($edu->major); ?>" required>
                            <label for="major-<?php echo e($i); ?>" class="form-label">Program Studi</label>
                        </div>
                        <div class="text-end">
                            <button type="button" class="btn btn-outline-danger btn-sm btn-education-delete mb-1" data-item-id="<?php echo e($i); ?>" data-education-id="<?php echo e($edu->id); ?>"><i class='bx bx-trash-alt' ></i> Hapus</button>
                        </div>
                    </div>
                </div> <!-- item end -->
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div id="edu-list-item-<?php echo e($i); ?>" class="d-flex mb-3 edu-list-item"> <!-- item --> 
                    <input type="hidden" name="education_id-<?php echo e($i); ?>" value="">
                    <span class="pt-3 me-3 fs-16 remove-md" style="color:#374785"><i class='bx bxs-right-arrow' ></i></span>
                    <div class="form-group col">
                        <div class="d-flex mb-2 flex-remove-md">
                            <div class="d-flex col align-middle align-items-center mb-2">
                                <div class="form-floating col">
                                    <input type="number" class="form-control" name="year_start-<?php echo e($i); ?>" placeholder="year from" value="<?php echo e(old('year_start-'.$i)); ?>" required>
                                    <label for="year_start-<?php echo e($i); ?>" class="form-label">Tahun masuk</label>
                                </div>
                                <span>&ensp;-&ensp;</span>
                                <div class="form-floating col">
                                    <input type="number" class="form-control" name="year_end-<?php echo e($i); ?>" placeholder="year to" value="<?php echo e(old('year_end-'.$i)); ?>">
                                    <label for="year_end-<?php echo e($i); ?>" class="form-label">Tahun lulus*</label>
                                </div>
                            </div>
                            <span class="remove-md">&ensp;</span>
                            <div class="form-floating col mb-1">
                                <input type="text" class="form-control" name="institution-<?php echo e($i); ?>" placeholder="education history" value="<?php echo e(old('institution-'.$i)); ?>" required>
                                <label for="institution-<?php echo e($i); ?>" class="form-label">Institusi pendidikan</label>
                            </div>
                        </div>
                        <div class="form-floating mb-1">
                            <input type="text" class="form-control" name="major-<?php echo e($i); ?>" placeholder="education history" value="<?php echo e(old('major-'.$i)); ?>" required>
                            <label for="major-<?php echo e($i); ?>" class="form-label">Program Studi</label>
                        </div>
                    </div>
                </div> <!-- item end -->
                <?php $i++; ?>
                <?php endif; ?>

            </div>
            <div class="edu-container-new"></div>
            <div class="mb-4">
                <div class="mb-4"><span class="text-muted fs-11 fst-italic">*Kosongkan tahun lulus apabila masih aktif</span></div>
                <div class="col text-center"><button type="button" class="btn btn-outline-primary w-100 btn-add-edu"><i class='bx bx-add-to-queue'></i> Tambahkan list</button></div>
            </div>
            <!-- education history end -->

            </div> <!-- col form end -->
        </div> <!-- row end -->

        <div class="row"> <!-- row start -->
            <!-- form button -->
            <hr class="mb-3"/>
            <div class="form-group d-flex justify-content-end">
                <input type="hidden" name="count" value="<?php echo e($i); ?>">
                <button type="submit" class="btn btn-success me-2 disabled btn-form-save"><i class='bx bxs-save' ></i> Simpan</button>
            </div>
            <!-- form button end -->
        </div> <!-- row end -->

        </form>
        <!-------- form end -------->
        
        <div class="row align-items-center mb-3"> <!-- row start -->
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold ps-3 fs-32 bl-darkblue-md">Sertifikat Pelatihan</h3>
            </div>
            <div class="col-md-12 certif-container d-flex flex-wrap mb-2">
                <!-- certif-item start -->
                <?php if($certificates): ?>
                <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="certif-item me-3 mb-3 bg-light text-primary">
                    <div class="certif-item-edit certif-card card rounded shadow-sm" data-id="<?php echo e($certif->id); ?>">
                        <div class="my-auto text-center p-3">
                            <img src="<?php echo e(asset('img/certificates/'.$certif->image)); ?>" class="certif-img img-fluid mb-3"/>
                            <p class="fs-10 mb-0"><?php echo e($certif->title); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <label for="certif_image">
                <div class="certif-item me-3 mb-3 bg-light text-primary">
                    <div class="certif-item-add certif-card card px-5 rounded shadow-sm">
                        <div class="my-auto">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            <span class="fs-14 fw-bold">Tambahkan</span>
                        </div>
                    </div>
                </div>
                </label>
                <!-- certif-item end -->
            </div>
            <div class="col-md-12">
                <p class="fs-11 fst-italic text-muted">*lampirkan file dalam format ".png, .jpg, dan jpeg" dengan ukuran maksimal 10mb</p>
            </div>
        </div> <!-- row end -->

        <div class="row"> <!-- row start -->
            <!-- form button -->
            <hr class="mb-3"/>
            <div class="form-group d-flex justify-content-end">
                <a href="/wizard/profile?from=40" class="btn btn-secondary me-2"><i class='bx bx-left-arrow-alt' ></i> Sebelumnya</a>
                <a href="/wizard/experience?from=40" class="btn btn-primary me-2"><i class='bx bx-right-arrow-alt' ></i> Selanjutnya</a>
            </div>
            <!-- form button end -->
        </div> <!-- row end -->

    </div>
</section>

<!-- modal new certificate-training start -->
<div class="modal fade" id="modal-certif-training" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center"><i class='bx bxs-file-plus me-2'></i> Upload File Sertifikat</h4>
                <button type="button" class="btn-close modal-certif-cancel" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/upload/certif_training" id="form-certif-training" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="col mb-3">
                    <img src="" id="certif_preview" class="img-fluid">
                </div>
                <hr/>
                <input id="certif_image" class="absolute w-full h-full d-none" name="certif_image" accept="image/png, image/jpeg, image/jpg" type="file">
                <div class="form-floating mb-3">
                    <input type="text" name="title" class="form-control" placeholder="title" value="">
                    <label for="title" class="form-label">Judul</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" name="issued_by" class="form-control" placeholder="issued by" value="">
                    <label for="title" class="form-label">Dikeluarkan oleh</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" name="category" class="form-control form-sm" placeholder="category" value="">
                    <label for="category" class="form-label">Kategori</label>
                </div>
                <div class="form-group mb-3">
                    <label for="description" class="form-label">Deskripsi</label>
                    <textarea name="description" rows="3" class="form-control"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-certif-cancel btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back me-1'></i>Batalkan</button>
                <button type="submit" id="modal-certif-submit" class="btn btn-primary"><i class='bx bxs-file-plus me-1'></i>Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- modal new certificate-training end -->

<!-- modal edit certif start -->
<div class="modal fade" id="modal-certif-edit" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center"><i class='bx bx-file me-2'></i> Edit Detail Sertifikat</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/update/certif_training" id="form-certif-edit" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="edit-certif_id" value=""/>
            <div class="modal-body">
                <div id="certif-edit-preview" class="col mb-3"></div>
                <div class="form-floating mb-3">
                    <input type="text" name="edit-title" class="form-control" placeholder="title" value="">
                    <label for="edit-title" class="form-label">Judul</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" name="edit-issued_by" class="form-control" placeholder="issued by" value="">
                    <label for="title" class="form-label">Dikeluarkan oleh</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" name="edit-category" class="form-control form-sm" placeholder="category" value="">
                    <label for="edit-category" class="form-label">Kategori</label>
                </div>
                <div class="form-group mb-3">
                    <label for="edit-description" class="form-label">Deskripsi</label>
                    <textarea name="edit-description" rows="3" class="form-control"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back me-1'></i>Batalkan</button>
                <a href="/delete/certif_training" id="modal-certif-delete" class="btn btn-danger btn-warn-delete"><i class='bx bx-trash-alt me-1'></i>Hapus</a>
                <button type="submit" id="modal-certif-update" class="btn btn-primary"><i class='bx bx-edit-alt me-1'></i>Update</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- modal edit certif end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
var user_id = <?php echo e(Auth::user()->id); ?>;
$(window).resize(function() {
    if($(window).width() < 992) {
        $('.flex-remove-md').removeClass('d-flex');
    } else {
        $('.flex-remove-md').removeClass('d-flex').addClass('d-flex');
    }
});
$(document).ready(function(){
    // Progressbar
    $('.progress-list').removeClass('progress-list-active');
    $('#progress-list-edu').addClass('progress-list-active');
    $('.progress-bar').css('width','40%').attr('aria-valuenow','40');

    // window size
    if($(window).width() < 992) {
        $('.flex-remove-md').removeClass('d-flex');
    } else {
        $('.flex-remove-md').removeClass('d-flex').addClass('d-flex');
    }

    // certificate item height
    var maxHeight = Math.max.apply(null, $("div.certif-card").map(function () {
        return $(this).height();
    }).get());
    $('.certif-card').css('height', maxHeight);
});

// Form
$('#form-education').change(function(e){
    $('.btn-form-save').removeClass('disabled');
});

// education history
var edu_item_count = parseInt($("[name='count']").val());
$('.btn-add-edu').click(function(e){
    e.preventDefault();
    add_edu_item(edu_item_count);
    edu_item_count++;
    $('.btn-remove-item').click(function(e){
        e.preventDefault();
        let get_count = $(this).attr('data-count');
        $('#edu-list-item-' + get_count).remove();
    });
});
$('.btn-education-delete').click(function(e){
    e.preventDefault();
    let item_id = $(this).attr('data-item-id');
    let education_id = $(this).attr('data-education-id');
      Swal.fire({
          title: 'Apakah anda yakin?',
          icon: 'warning',
          showCancelButton: true,
          cancelButtonText: 'Batalkan',
          cancelButtonColor: '#666',
          confirmButtonColor: '#dc3545',
          confirmButtonText: "Hapus"
          }).then((result) => {
          if (result.isConfirmed) {
              window.location.href = '/wizard/education/delete/' + education_id;
          }
      })
});
function add_edu_item(count) {
    var edu_container_new = $('.edu-container-new');
    edu_container_new.append(
        '<div id="edu-list-item-'+ count +'" class="d-flex flex-remove-md list-item card bg-white p-4 shadow-sm mb-4">' +
            '<input type="hidden" name="education_id-'+ count +'" value="">' +
            '<div class="w-100 d-flex justify-content-between mb-3"><span class="text-primary">Riwayat baru</span><button type="button" class="btn-close btn-remove-item btn-sm" aria-label="Close" data-count="'+ count +'"></button></div>' +
            '<div class="form-group col mb-3">' +
                '<div class="d-flex mb-2 flex-remove-md">' +
                    '<div class="d-flex col align-middle align-items-center mb-2">' +
                        '<div class="form-floating col">' +
                            '<input type="number" class="form-control" name="year_start-'+ count +'" placeholder="year from" value="" required>' +
                            '<label for="year_start-'+ count +'" class="form-label">Tahun masuk</label>' +
                        '</div>' +
                        '<span>&ensp;-&ensp;</span>' +
                        '<div class="form-floating col">' +
                            '<input type="number" class="form-control" name="year_end-'+ count +'" placeholder="year to" value="">' +
                            '<label for="year_end-'+ count +'" class="form-label">Tahun lulus*</label>' +
                        '</div>' +
                    '</div>' +
                    '<span class="remove-md">&ensp;</span>' +
                    '<div class="form-floating col mb-1">' +
                        '<input type="text" class="form-control" name="institution-'+ count +'" placeholder="education history" value="" required>' +
                        '<label for="institution-'+ count +'" class="form-label">Institusi pendidikan</label>' +
                    '</div>' +
                '</div>' +
                '<div class="form-floating mb-1">' +
                    '<input type="text" class="form-control" name="major-'+ count +'" placeholder="education history" value="" required>' +
                    '<label for="major-'+ count +'" class="form-label">Program Studi</label>' +
                '</div>' +
            '</div>' +
        '</div>'
    );
    resize_control();
}

function resize_control () {
    if($(window).width() < 992) {
        $('.flex-remove-md').removeClass('d-flex');
    } else {
        $('.flex-remove-md').removeClass('d-flex').addClass('d-flex');
    }
}

</script>
<script src="<?php echo e(asset('/js/ajax_wizard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/wizard_education.blade.php ENDPATH**/ ?>