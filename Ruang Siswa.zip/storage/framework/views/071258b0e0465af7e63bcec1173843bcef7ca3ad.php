

<?php $__env->startPush('css-styles'); ?>
<style>
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="section bg-light">
    <div class="container">
        <div id='calendar'></div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/js/ajax_calendar.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function(){
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project - Calendar\iCalendar\resources\views/schedule/calendar.blade.php ENDPATH**/ ?>