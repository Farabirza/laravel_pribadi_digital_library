

<?php $__env->startPush('css-styles'); ?>
<style>
#navbar { display: none;  }
#main { min-height: 100vh; background: #f8e9a1; padding: 0 !important; }
@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content" class="vh-100 py-40">
    <div class="container h-100">

        <div class="row d-flex h-100 justify-content-center align-items-center"> <!-- row start -->
            <div class="col-md-8 card bg-light p-4">
                <div class="d-flex justify-content-between mb-4">
                    <a href="/"><img src="<?php echo e(asset('img/logo/logo_cvkreatif.com.png')); ?>" alt="" style="height:40px"/></a>
                </div>
                <h3 class="mb-3">Selamat datang <span class="fw-bold text-primary"></span></h3>
                <p class="fs-11">Sebelum melanjutkan, silahkan tentukan username anda.</p>
                <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <span class="input-group-text text-white bg-primary"><i class='bx bx-user'></i></span>
                    <input type="text" name="username" class="form-control" placeholder="username">
                    <!-- <label for="username" class="form-label">Username</label> -->
                </div>
                <p class="fs-11 fst-italic text-muted">*username akan menjadi acuan alamat CV anda, contoh: https://cvkreatif.com/cv/john_doe</p>
                </form>
            </div>
        </div> <!-- row end -->

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="texy/javascript">
$(document).ready(function(){
    // $('#main').css('margin-top', -$('#section-navbar').height());
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com - experiment\resources\views/user/edit_username.blade.php ENDPATH**/ ?>