

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/aos/aos.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<style>
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content" class="py-4">
    <div class="container">
        <!-- ------------------------------------- Row start ------------------------------------- -->
        <div class="row justify-content-center">
            <div class="col-md-10 mb-2">
                <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item"><a href="/cv/<?php echo e($portfolio->user->username); ?>"><?php echo e($portfolio->user->username); ?></a></li>
                        <li class="breadcrumb-item active" aria-current="page">Portofolio</li>
                    </ol>
                </nav>
            </div>
            <div class="col-md-10 mb-3">
                <img src="<?php echo e(asset('img/portfolios/'.$portfolio->image)); ?>" alt="" class="border rounded shadow-sm mb-4">
                <h3 class="d-flex justify-content-between align-items-center fw-bold ps-3 border-start border-primary border-5 mb-3"><?php echo e($portfolio->title); ?></h3>
                <p class="mb-0">Kategori : <b><?php echo e($portfolio->category); ?></b></p>
            </div>
            <div class="col-md-10 py-2 mb-4">
                <?php echo $portfolio->description; ?>

                <?php if($portfolio->url): ?>
                <p class="mb-0">Link eksternal : <a href="<?php echo e('//'.$portfolio->url); ?>" target=”_blank” class="text-primary fst-italic"><?php echo e($portfolio->url); ?></a></p>
                <?php endif; ?>
            </div>
            <?php if(count($portfolio_gallery) > 0): ?>
            <div class="col-md-12 d-flex flex-wrap gap-4 justify-content-center mb-4">
                <?php $j=200; ?>
                <?php $__currentLoopData = $portfolio_gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(asset('img/portfolios/'.$portfolio->id.'/'.$gallery->image)); ?>" class="glightbox" data-glightbox="title: <?php echo e($gallery->caption); ?>" data-aos="fade-right" data-aos-duration="<?php echo e($j); ?>">
                    <img src="<?php echo e(asset('img/portfolios/'.$portfolio->id.'/'.$gallery->image)); ?>" alt="" class="shadow mb-2" style="max-height:320px">
                </a>
                <?php $j+=200; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        </div>
        <!-- ------------------------------------- Row end ------------------------------------- -->
    </div>
</section>

<!-- section footer start -->
<section id="section-footer" class="bg-dark">
    <div class="container">
        <div class="row d-flex justify-content-center align-items-center py-4"> <!-- row start -->
            <div class="col-md-8 text-center">
                <span class="text-light">Powered by : <b>cvkreatif.com</b></span>
            </div>
        </div> <!-- row end -->
    </div>
</div>
<!-- section footer end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script type="text/javascript">
const lightbox = GLightbox({
    touchNavigation: true,
    loop: true,
    autoplayVideos: true
});
$('document').ready(function(){
    AOS.init({ once: true,  easing: 'ease-in-out-sine' });
    // $('#navbar').removeClass('fixed-top ');
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/cv/portfolio.blade.php ENDPATH**/ ?>