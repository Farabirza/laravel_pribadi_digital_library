

<?php $__env->startPush('css-styles'); ?>
<style>
#section-hero {
    height: 100vh;
    background: url('../img/bg/bg_trans-80.png') top left repeat, url("../img/bg/mitraleipzig-min.png") top center transparent fixed;
    background-size: cover;
    color: white;
    text-align: center;
}
.btn-hero1 { margin-right: 20px; padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: white; color: #202020; }
.btn-hero1:hover { background: transparent; color: white; transition: ease .4s; }
.btn-hero2 { padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: transparent; }
.btn-hero2:hover { background: white; color: #202020; transition: ease .4s; }

.section-title {
  margin-bottom: 20px;
  padding-bottom: 20px;
  position: relative;
}
.section-title::after {
    content: "";
    position: absolute;
    display: block;
    width: 50px;
    height: 3px;
    background: #124265;
    bottom: 0;
    left: 0;
}

.img-logo-md { width: 120px; }

@media (max-width: 768px) {
    #section-hero { padding: 40px 0; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section start -->
<section id="section-start" class="ptb-60">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <img class="img-logo-md mb-3" src="<?php echo e(asset('img/logo/logo.png')); ?>" alt="">
                <h1>Welcome <b><?php echo e(Auth::user()->profile->first_name.' '.Auth::user()->profile->last_name); ?></b></h1>
            </div>
            <!-- <div class="col-md-12 mb-4 text-center">
                <h1 class="display-4 title-dark"><?php echo e($today); ?></h1>
                <h5 class="display-5 title-dark"><span id="clock"></span></h5>
            </div>     -->
        </div> <!-- row end -->
    </div>
</section>
<!-- section end -->

<!-- section-about -->
<section id="section-about" class="ptb-60 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 mb-3">
                <h1 class="section-title title-dark">About Us</h1>
            </div>
            <div class="col-md-10 mb-3">
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc lacinia congue lacus, quis congue turpis placerat quis. Pellentesque in lorem sit amet dolor interdum fringilla. Ut lobortis sit amet elit ut cursus. Quisque viverra velit a tortor sollicitudin laoreet. Curabitur a tellus vitae urna venenatis scelerisque et ut velit. Phasellus ut ipsum diam. Nullam eu nunc mauris. Suspendisse quis faucibus orci. Integer gravida metus a dignissim ultrices. Donec vitae libero non quam bibendum fermentum. Aenean mauris leo, scelerisque eget metus in, dignissim cursus nunc. Maecenas id fermentum neque, ac viverra arcu. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut at interdum mi.</p>
                <p>Integer in efficitur est. Vestibulum in sem vel eros mollis accumsan. Praesent quam ante, dictum sit amet efficitur gravida, vulputate eget nunc. Nunc consectetur id diam nec tincidunt. Nam sed maximus ipsum. Duis facilisis non elit ut maximus. Morbi ullamcorper quis purus in tempor. Vestibulum et tempus tellus. Maecenas porta vel sem sed bibendum. Pellentesque accumsan aliquam ipsum auctor euismod. Nullam venenatis viverra lorem, non consectetur lectus ullamcorper quis. </p>
            </div>
        </div> <!-- row end -->
    </div>
</section>
<!-- section-about end -->

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
$(document).ready(function(){
    startTime();
    $('.popper').popover({
        trigger: 'hover',
        html: true,
        placement: 'bottom',
        container: 'body'
    });
});
function startTime() {
  const today = new Date();
  let h = today.getHours();
  let m = today.getMinutes();
  let s = today.getSeconds();
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById('clock').innerHTML =  h + ":" + m + ":" + s;
  setTimeout(startTime, 1000);
}

function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Template - Blank Laravel\Laravel 9\resources\views/home.blade.php ENDPATH**/ ?>