

<?php $__env->startPush('css-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>">
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/fontawesome/fontawesome.js')); ?>" crossorigin="anonymous"></script>
<style>
    
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- section-profile -->
<section id="section-profile" class="section">
    <div class="container">
        <div class="row">
            <h1>Hello World</h1>
        </div>
    </div>
</section>
<!-- section-profile end -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
$(document).ready(function(){
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project - Calendar\iCalendar\resources\views/user/profile.blade.php ENDPATH**/ ?>