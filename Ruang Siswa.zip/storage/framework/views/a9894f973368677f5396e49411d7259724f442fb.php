<?php if(!Route::is('home')): ?>
<style>
    #navbar { box-shadow: 0 0 1px rgba(0,0,0,.125),0 1px 3px rgba(0,0,0,.2); }
</style>
<?php endif; ?>
<style>
.navbar-brand img { max-height: 40px; }
.nav-item { margin-left: 6px; }
#user-img { width: 40px; }
@media (max-width: 768px) {
  .navbar-collapse { padding-top: 15px; }
  .navbar-nav { margin-bottom: 4px; }
}
</style>

<div id="section-navbar">
    <nav id="navbar" class="navbar <?php if(!Route::is('home')): ?> fixed-top <?php endif; ?> navbar-expand-lg py-3 navbar-light bg-white">
        <div class="container">
            <a href="/" class="navbar-brand"><img id="navbar-logo-img" class="py-1" src="<?php echo e(asset('/img/logo/logo_cvkreatif.com.png')); ?>" alt="site_logo"/></a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav justify-content-center col">
                    <!-- <form class="d-flex px-2 w-75">
                        <div class="input-group rounded me-2">
                            <span class="input-group-text text-white bg-primary"><i class='bx bx-search'></i></span>
                            <input class="form-control" type="search" placeholder="Cari portofolio berdasarkan kata kunci" aria-label="Search">
                            <button class="btn btn-primary">Search</button>
                        </div>
                    </form> -->
                </div>
                <div class="navbar-nav ">
                    <?php if(auth()->guard()->check()): ?>
                        <div class="dropdown nav-item d-flex vertical-center">
                            <img src="<?php echo e(asset('/img/profiles/male.png')); ?>" id="user-img" alt="" class="img-fluid rounded-circle box-shadow-2 me-2">
                            <span class="me-2"><?php echo e(Auth::user()->username); ?></span>
                            <i id="user-icon" class='bx bx-chevron-down' type="button" id="user-menu" data-bs-toggle="dropdown" aria-expanded="false"></i>
                            <ul class="dropdown-menu" aria-labelledby="user-menu">
                                <li><a class="dropdown-item" href="/cv/<?php echo e(Auth::user()->username); ?>"><i class='bx bx-file mr-3'></i> Halaman CV</a></li>
                                <li><a class="dropdown-item" href="/wizard/profile"><i class='bx bx-edit-alt mr-3'></i> Edit data</a></li>
                                <li class="mb-2"><hr class="dropdown-divider"></li>
                                <li id="show-modal-feedback" class="mb-2"><span class="dropdown-item btn"><i class='bx bx-star mr-3'></i> Feedback</span></li>
                                <li class="mb-2"><a class="dropdown-item" href="/logout"><i class='bx bx-log-out mr-3' ></i> Logout</a></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                        <div class="nav-item nav-link align-middle"><a href="/login" class="btn btn-outline-primary btn-modal-login px-4 rounded"><i class='bx bxs-user me-1' ></i> Login</a></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
</div>

<?php echo $__env->make('layouts/partials/modal_feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts/partials/modal_auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>