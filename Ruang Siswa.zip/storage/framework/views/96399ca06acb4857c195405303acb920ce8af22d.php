

<?php $__env->startPush('css-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/vendor/fullcalendar/fullcalendar.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>">
<script src="<?php echo e(asset('/vendor/fullcalendar/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/fullcalendar/fullcalendar.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/fontawesome/fontawesome.js')); ?>" crossorigin="anonymous"></script>
<style>
    thead, tr { vertical-align: middle; }
    .calendar-container { border-top: 8px solid #fac863; }
    .btn { border-width: 2px; }
    .event-time { color: #0d6efd !important; font-weight: 500; }
    .event-title { font-weight: 600; }
    .label { color: #149ddd; }
    
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section id="section-calendar" class="section bg-light">
    <div class="container">
        <div class="row mb-20">
            <div class="calendar-container card padd-40">
                <div id='calendar'></div>
            </div>

            <!-- Floating window button new calendar -->
            <div class="modal fade" id="modal-add" aria-hidden="true"> 
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header d-flex justify-content-between vertical-center">
                            <h4 class="modal-title">New Event</h4>
                            <button type="button" class="btn-close cancel-btnAdd" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="form-newEvent-manual" name="form-newEvent-manual" data-action="/calendar_ajax" enctype="multipart/form-data" method="POST" novalidate="">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="type" value="add_manual">
                                <div class="form-group">
                                    <label class="label mb-2">Select color</label><br>
                                    <input type="radio" class="check-color btn-check" name="color" id="opt1" value="#3a87ad" checked>
                                    <label class="btn btn-outline-primary mr-4" for="opt1">&emsp;</label>
                                    <input type="radio" class="check-color btn-check" name="color" id="opt2" value="#198754" autocomplete="off">
                                    <label class="btn btn-outline-success mr-4" for="opt2">&emsp;</label>
                                    <input type="radio" class="check-color btn-check" name="color" id="opt3" value="#6c757d" autocomplete="off">
                                    <label class="btn btn-outline-secondary mr-4" for="opt3">&emsp;</label>
                                    <input type="radio" class="check-color btn-check" name="color" id="opt4" value="#ffc107" autocomplete="off">
                                    <label class="btn btn-outline-warning mr-4" for="opt4">&emsp;</label>
                                    <input type="radio" class="check-color btn-check" name="color" id="opt5" value="#dc3545" autocomplete="off">
                                    <label class="btn btn-outline-danger mr-4" for="opt5">&emsp;</label>
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="btnAdd-title" name="title" placeholder="Event title" required>
                                    <label for="btnAdd-title" class="label">Event title</label>
                                </div>
                                <div class="form-group">
                                    <p class="label mb-2">Target group</p>
                                    <p class="mb-2"><input type="checkbox" name="group" value="0" id="check-group-all" class="form-check-input" checked>
                                    <label for="check-group-all" class="form-check-label mr-8">All group</label></p>
                                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="mb-2"><input type="checkbox" name="group" value="<?php echo e($group->id); ?>" id="check-group-<?php echo e($group->id); ?>" class="check-group form-check-input" checked>
                                    <label for="check-group-<?php echo e($group->id); ?>" class="form-check-label mr-8"><?php echo e($group->name); ?></label></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="form-group">
                                    <div class="d-flex">
                                        <div class="col form-floating">
                                            <input type="date" min="1997-01-01" class="form-control" name="start_date" id="btnAdd-start_date" value="<?php echo e($today); ?>" required>
                                            <label for="btnAdd-start_date" class="label">Start date</label>
                                        </div>
                                        <span>&ensp;</span>
                                        <div class="col form-floating">
                                            <input type="date" min="1997-01-01" class="form-control" name="end_date" id="btnAdd-end_date" value="<?php echo e($today); ?>" required>
                                            <label for="btnAdd-end_date" class="label">End date</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="allday" id="btnAdd-allday" class="mr-8">All day
                                </div>
                                <div id="btnAdd-time" class="form-group">
                                    <div class="d-flex">
                                        <div class="col form-floating">
                                            <input type="time" class="form-control" id="btnAdd-start_time" name="start_time" value="00:00">
                                            <label for="btnAdd-start" class="label">Start from</label>
                                        </div>
                                        <span>&ensp;</span>
                                        <div class="col form-floating">
                                            <input type="time" class="form-control" id="btnAdd-end_time" name="end_time" value="23:59">
                                            <label id="btnAdd-end" class="label">Ended at</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="btnAdd-description" class="label mb-2">Description</label>
                                    <textarea name="description" id="btnAdd-description" class="form-control" style="height:100px" placeholder="Description"></textarea>
                                </div>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="btnAdd-link" name="link" placeholder="Link" value="">
                                    <label for="btnAdd-link" class="label">Event link</label>
                                </div>
                        </div>
                        <div class="modal-footer">
                                <a type="cancel" class="cancel-btnAdd btn btn-secondary mr-4"><i class='bx bx-arrow-back'></i> Cancel</a>
                                <button type="submit" class="btn btn-primary" id="submit-btnAdd" value="add"><i class='bx bx-paper-plane' ></i> Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Floating window button new calendar end -->

            <!-- Floating window select new calendar -->
            <div class="modal fade" id="modal-newEvent-select" aria-hidden="true"> 
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header d-flex justify-content-between vertical-center">
                            <h4 class="modal-title">New Event</h4>
                            <button type="button" class="cancel-event btn btn-secondary btn-sm mr-4"><i class="fa-solid fa-x"></i></button>
                        </div>
                        <div class="modal-body">
                            <form id="form-newEvent-select" name="form-newEvent-select" novalidate="">
                                <div class="form-group">
                                    <label class="label mb-2">Select color</label><br>
                                    <input type="radio" class="btn-check" name="event-color" id="option1" value="#3a87ad" checked>
                                    <label class="btn btn-outline-primary mr-4" for="option1">&emsp;</label>
                                    <input type="radio" class="btn-check" name="event-color" id="option2" value="#198754" autocomplete="off">
                                    <label class="btn btn-outline-success mr-4" for="option2">&emsp;</label>
                                    <input type="radio" class="btn-check" name="event-color" id="option3" value="#6c757d" autocomplete="off">
                                    <label class="btn btn-outline-secondary mr-4" for="option3">&emsp;</label>
                                    <input type="radio" class="btn-check" name="event-color" id="option4" value="#ffc107" autocomplete="off">
                                    <label class="btn btn-outline-warning mr-4" for="option4">&emsp;</label>
                                    <input type="radio" class="btn-check" name="event-color" id="option5" value="#dc3545" autocomplete="off">
                                    <label class="btn btn-outline-danger mr-4" for="option5">&emsp;</label>
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="event-title" name="event-title" placeholder="Event title" required>
                                    <label for="event-title" class="label">Event title</label>
                                </div>
                                <div class="form-group">
                                    <p class="label mb-2">Target group</p>
                                    <p class="mb-2"><input type="checkbox" name="event-group" value="0" id="event-group-all" class="form-check-input" checked>
                                    <label for="event-group-all" class="form-check-label mr-8">All group</label></p>
                                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="mb-2"><input type="checkbox" name="event-group" value="<?php echo e($group->id); ?>" id="event-group-<?php echo e($group->id); ?>" class="event-group form-check-input" checked>
                                    <label for="event-group-<?php echo e($group->id); ?>" class="form-check-label mr-8"><?php echo e($group->name); ?></label></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="allday" id="allday" class="mr-8">All day
                                </div>
                                <div id="event-time" class="form-group">
                                    <div class="d-flex">
                                        <div class="col form-floating mr-8">
                                            <input type="time" class="form-control" id="event-start" name="event-start" value="00:00">
                                            <label for="event-start" class="label">Start from</label>
                                        </div>
                                        <div class="col form-floating">
                                            <input type="time" class="form-control" id="event-end" name="event-end" value="23:59">
                                            <label for="event-end" class="label">Ended at</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="label mb-2">Description</label>
                                    <textarea name="event-description" id="event-description" class="form-control" rows="4" placeholder="Description"></textarea>
                                </div>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="event-link" name="event-link" placeholder="Link" value="">
                                    <label for="event-link" class="label">Event link</label>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                                <button type="button" class="cancel-event btn btn-secondary mr-4"><i class='bx bx-arrow-back'></i> Cancel</button>
                                <button type="button" class="btn btn-primary" id="submit-event" value="add"><i class='bx bx-paper-plane' ></i> Submit</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Floating window select new calendar end -->

        </div> <!-- end of row -->
        
        <div id="agenda" class="row ptb-20">
            <div class="col-md-12 card padd-20 box-shadow-2">
                <h3 id="agenda-title" class="align-center">Today's Agenda</h3><hr class="mb-20">

                <!-- agenda-table -->
                <div class="table-responsive-md">
                    <table id="agenda-table" class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Event</th>
                                <th>Description</th>
                                <th>Link</th>
                            </tr>
                        </thead>
                        <tbody id="event-table">
                            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="event-time"><?php if($event->start_time == '00:00'): ?> All day <?php elseif($event->start_time == ''): ?> All day <?php else: ?> <?php echo e($event->start_time); ?> - <?php echo e($event->end_time); ?> <?php endif; ?></td>
                                <td><a href="<?php echo e($event->id); ?>" class="event-title"><?php echo e($event->title); ?></a></td>
                                <td><?php if($event->description): ?> <?php echo e($event->description); ?> <?php else: ?> - <?php endif; ?></td>
                                <td class="d-flex"><?php if($event->link): ?><a href="<?php echo e($event->link); ?>" class="btn btn-primary btn-sm" target="_blank">Visit Link</a><?php else: ?> - <?php endif; ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">No agenda for today</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- agenda-table end -->

                <!-- Floating window Event Details -->
                <div class="modal fade" id="modal-edit" aria-hidden="true"> 
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header d-flex justify-content-between vertical-center">
                                <h4 class="modal-title">Event Details</h4>
                                <button type="button" class="cancel-update btn btn-secondary btn-sm mr-4"><i class="fa-solid fa-x"></i></button>
                            </div>
                            <div class="modal-body">
                                <form id="form-editEvent" method="POST" novalidate="">
                                    <div class="form-group">
                                        <label class="label mb-2">Select color</label><br>
                                        <input type="radio" class="btn-check" name="detail-color" id="color-3a87ad" value="#3a87ad" checked>
                                        <label class="btn btn-outline-primary mr-4" for="color-3a87ad">&emsp;</label>
                                        <input type="radio" class="btn-check" name="detail-color" id="color-198754" value="#198754" autocomplete="off">
                                        <label class="btn btn-outline-success mr-4" for="color-198754">&emsp;</label>
                                        <input type="radio" class="btn-check" name="detail-color" id="color-6c757d" value="#6c757d" autocomplete="off">
                                        <label class="btn btn-outline-secondary mr-4" for="color-6c757d">&emsp;</label>
                                        <input type="radio" class="btn-check" name="detail-color" id="color-ffc107" value="#ffc107" autocomplete="off">
                                        <label class="btn btn-outline-warning mr-4" for="color-ffc107">&emsp;</label>
                                        <input type="radio" class="btn-check" name="detail-color" id="color-dc3545" value="#dc3545" autocomplete="off">
                                        <label class="btn btn-outline-danger mr-4" for="color-dc3545">&emsp;</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="detail-title" name="updated_title" placeholder="Event title" required>
                                        <label for="detail-title" class="label">Event title</label>
                                    </div>
                                    <div class="form-group">
                                        <p class="label mb-2">Target group</p>
                                        <p class="mb-2"><input type="checkbox" name="detail-group" value="0" id="detail-group-all" class="form-check-input">
                                        <label for="detail-group-all" class="form-check-label mr-8">All group</label></p>
                                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="mb-2"><input type="checkbox" name="detail-group" value="<?php echo e($group->id); ?>" id="detail-group-<?php echo e($group->id); ?>" class="detail-group form-check-input">
                                        <label for="detail-group-<?php echo e($group->id); ?>" class="form-check-label mr-8"><?php echo e($group->name); ?></label></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="checkbox" name="detail-allday" id="detail-allday" class="mr-8">All day
                                    </div>
                                    <div id="detail-time" class="form-group">
                                        <div class="d-flex">
                                            <div class="col mr-8 form-floating">
                                                <input type="time" class="form-control" id="detail-start" name="detail-start" value="00:00">
                                                <label for="detail-start" class="label">Start from</label>
                                            </div>
                                            <div class="col form-floating">
                                                <input type="time" class="form-control" id="detail-end" name="detail-end" value="23:59">
                                                <label for="detail-end" class="label">Ended at</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="label mb-2">Description</label>
                                        <textarea name="updated_description" id="detail-description" class="form-control" rows="3" placeholder="Description"></textarea>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="detail-link" name="detail-link" placeholder="Link" value="">
                                        <label for="detail-link" class="label">Event link</label>
                                    </div>
                                    <div class="form-group">
                                        <label class="label mb-2">Created by</label>
                                        <input type="name" id="detail-createdBy" class="form-control" disabled>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="cancel-update btn btn-secondary mr-4"><i class='bx bx-arrow-back'></i> Cancel</button>
                                <button type="button" id="delete-update" class="btn btn-danger mr-4"><i class='bx bxs-trash'></i> Delete</button>
                                <button type="button" id="submit-update" class="btn btn-primary" value="add"><i class='bx bx-edit-alt' ></i> Update</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Floating window Event Details end -->
            
            </div>
        </div>
    </div> <!-- end of container -->
</section>

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if(Auth::user()->role != 'user'): ?> 
<script src="<?php echo e(asset('/js/ajax_calendar_admin.js')); ?>"></script>
<?php else: ?> 
<script src="<?php echo e(asset('/js/ajax_calendar_user.js')); ?>"></script> 
<?php endif; ?>
<script type="text/javascript">
$(document).ready(function(){
    $('.nav-link').removeClass('active');
    $('.nav-link-calendar').addClass('active');
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/calendar/calendar.blade.php ENDPATH**/ ?>