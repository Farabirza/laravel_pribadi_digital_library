<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta content="Sprachschule Mitra Leipzig" name="description">
<meta content="Sprachschule Mitra Leipzig" name="keywords">
<meta property="og:image" content="http://calendar.irzafarabi.com/img/bg/mitraleipzig-min.png" />

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.1.1.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>Sprachschule Mitra Leipzig | Sign in</title>
  
<style>
#section-login {
    height: 100vh;
    background: url('../img/bg/bg_trans-80.png') top left repeat, url("../img/bg/mitraleipzig-min.png") top center transparent fixed;
    background-size: cover;
}
#form-login { background: #fff; padding: 60px 40px; border-radius: 8px; }
</style>
</head>
<body>

<section id="section-login">
    <div class="container py-5 h-100">
        <div class="row d-flex h-100 justify-content-center align-items-center">
            <div id="form-login" class="col-md-8">
                <?php if(session('resent')): ?>
                    <div class="alert alert-success mb-3" role="alert">
                        <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                    </div>
                <?php endif; ?>
                <h1 class="display-5">Sprachschule Mitra Leipzig</h1>
                <p class="mb-3">Verify email address</p>

                <p class="mb-1">Before proceeding, please check your email for a verification link.</p>
                <p class="mb-3">If you <span class="text-danger">did not receive the email</span>, click the button below.</p>
                <form method="POST" action="<?php echo e(route('verification.resend')); ?>">
                <?php echo csrf_field(); ?>
                    <?php if(session('resent')): ?>
                        <p><button type="submit" class="btn btn-primary mr-8"><i class='bx bx-envelope'></i> Resend verification code to my email</button> <a href="https://mail.google.com/" class="btn btn-primary"><i class='bx bxs-envelope'></i> Go to Gmail.com</a></p>
                    <?php else: ?>
                        <p><button type="submit" class="btn btn-outline-primary mr-8"><i class='bx bx-envelope'></i> Send verification code to my email</button> <a href="https://mail.google.com/" class="btn btn-primary disabled"><i class='bx bxs-envelope'></i> Go to Gmail.com</a></p>
                    <?php endif; ?>
                    <p><a href="/" class="btn btn-secondary mr-8"><i class='bx bx-arrow-back'></i> Back to index</a> <a href="/logout" class="btn btn-danger"><i class='bx bx-log-out'></i> Log out</a></p>
                </form>

            </div>
        </div>
    </div>
</section>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>


<script type="text/javascript">
$(document).ready(function(){
});
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\Template - Blank Laravel\Laravel 9\resources\views/auth/verify.blade.php ENDPATH**/ ?>