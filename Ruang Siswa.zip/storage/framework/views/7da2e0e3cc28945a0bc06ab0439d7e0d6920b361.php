<!DOCTYPE html>
<html lang="en">

<head>
<?php echo $__env->make('layouts.partials.metaTags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.6.0.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<?php if(isset($page_title)): ?>
<title><?php echo e($page_title); ?></title>
<?php else: ?>
<title>Company Website</title>
<?php endif; ?>
  
<?php echo $__env->yieldPushContent('css-styles'); ?>
<style>
:root {
  --sidebar-width: 240px;
}
/* ========================== Navigation start ========================== */
/* Desktop Navigation */
.nav-menu * { margin: 0; padding: 0; list-style: none; }
.nav-menu ul { width: 100%; }
.nav-menu > ul > li {
  position: relative;
  white-space: nowrap;
}
.nav-menu .nav-link, .nav-menu li:focus {
  display: flex;
  align-items: center;
  color: var(--color-3);
  margin-bottom: 8px;
  transition: 0.3s;
  font-size: 15px;
}
.nav-menu li i, .nav-menu li:focus i {
  font-size: 24px;
  padding-right: 8px;
}
.nav-menu li:hover, .nav-menu .active, .nav-menu .active:focus, .nav-menu li:hover > a {
  text-decoration: none;
  font-weight: 600;
  cursor: pointer;
}
.nav-menu li:hover i, .nav-menu .active i, .nav-menu .active:focus i, .nav-menu li:hover > a i { color: var(--color-3); }
.dropdown-divider { margin: 0 20px; }
.nav-drop { position: absolute; right: 0; }

.nav-submenu { color: #aaa; font-size: 10pt; text-indent: 2em; margin-bottom: 10px; }
.nav-submenu a:hover { color: var(--bs-dark); }

.nav-list { font-size: 11pt; padding-bottom: 15px; }

#sidebar {
    z-index: 999;
    position: fixed;
    top: 0;
    left: calc(var(--sidebar-width)*-1);
    bottom: 0;
    width: var(--sidebar-width);
    background: #fff;
    padding: 0 15px;
    transition: all ease-in-out 0.5s;
    transition: all 0.5s;
    overflow-y: auto;
} .mobile-nav-toggle {
  position: fixed;
  right: 15px;
  top: 15px;
  z-index: 9998;
  border: 0;
  font-size: 24px;
  transition: all 0.4s;
  outline: none !important;
  color: #fff;
  width: 40px;
  height: 40px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  line-height: 0;
  border-radius: 50px;
  cursor: pointer;
} .mobile-nav-active {
  overflow: hidden;
} .mobile-nav-active #sidebar {
  left: 0;
}

#section-header { position: relative; }

#main, #container-header {
    padding-left: 0px;
}

#section-content { padding: 30px 20px; }
@media (max-width: 768px) {
    #section-content { padding: 30px 1%; }
}

@media (max-width: 1199px) {
    #toggle-sidebar { display: none; }
    #main, #container-header { padding-left: 0 }
    #sidebar {
        left: calc(var(--sidebar-width) * -1);
    }
}
</style>
</head>
<body>
<!-- ======= Mobile nav toggle button ======= -->
<i class="bi bi-list mobile-nav-toggle bg-dark d-xl-none" onclick="toggleSidebar(sidebar_show)"></i>

 <!-- ======================================= sidebar start ================================================== -->
<header>
  <div id="sidebar" class="d-flex flex-column flex-shrink-0 shadow">
    <!-- <a href="/" class="py-3 px-2"><img src="<?php echo e(asset('img/logo/logo_mitraleipzig_trans.png')); ?>"/></a> -->
    <a href="/" class="py-3 px-2 fs-18"><span class="fw-bold">Company</span>Logo</a>
    <hr />
    <?php if(auth()->guard()->guest()): ?>
    <button id="btn-auth-signin" class="btn btn-success mb-3" onclick="modal_login_show()">Sign In</button>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
    <p class="mt-2 px-4 mb-3">
      <?php if(Auth::user()->picture): ?>
      <img id="sidebar-user-picture" src="<?php echo e(asset('img/profiles/'.Auth::user()->picture)); ?>" alt="" class="rounded rounded-circle shadow">
      <?php else: ?>
      <a href="/profile"><img src="<?php echo e(asset('img/profiles/user.jpg')); ?>" alt="" class="rounded rounded-circle shadow"></a>
      <?php endif; ?>
    </p>
    <p class="text-primary text-center mb-3"><a href="/profile" title="<?php echo e(Auth::user()->email); ?>"><?php echo e(Auth::user()->username); ?></a></p>
    <a href="/logout" id="btn-auth-signout" class="btn btn-outline-danger btn-sm mb-3">Sign Out</a>
    <?php if(Auth::user()->profile): ?>
    <hr/>
    <nav class="nav-menu navbar">
        <ul>
            <a href="/dashboard/overview"><li id="link-overview" class="nav-link mb-3"><i class="bx bxs-dashboard"></i><span>Overview</span></li></a>
            <a href="/dashboard/analytics"><li id="link-analytics" class="nav-link mb-3"><i class="bx bxs-bar-chart-alt-2"></i><span>Analytics</span></li></a>
            <a href="/dashboard/config"><li id="link-config" class="nav-link mb-3"><i class="bx bxs-cog"></i><span>Configs</span></li></a>
            <?php if(Auth::user()->role != 'user'): ?>
            <!-- admin -->
            <li id="link-edit" class="nav-link mb-3"><i class="bx bxs-star"></i><span role="button" data-bs-toggle="collapse" data-bs-target="#submenu-admin" aria-expanded="true" aria-controls="submenu-admin">Admin<i class='bx bx-chevron-down nav-drop'></i></span></li>
            <ul class="bx-ul collapse nav-submenu mb-3" id="submenu-admin">
                <li id="link-edit_profile" class="nav-list"><a href='/admin/dashboard/user'>User</a></li>
                <li id="link-edit_profile" class="nav-list"><a href='/admin/dashboard/analytic'>Analytic</a></li>
                <li id="link-edit_profile" class="nav-list"><a href='/admin/dashboard/config'>Config</a></li>
            </ul>
            <!-- admin -->
            <?php endif; ?>
        </ul>
    </nav>
    <?php endif; ?>
    <?php endif; ?>
  </div>
</header>
<!-- ======================================= sidebar end ================================================== -->

<section id="section-header" class="px-2 py-3 shadow-sm bg-white">
    <div id="container-header" class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-primary d-flex align-items-center">
                <span id="toggle-sidebar" onclick="toggleSidebar(sidebar_show)" role="button" class="btn me-2"><i class='bx bx-menu'></i></span>
                <h1 class="fs-18 display-5 d-flex align-items-center mb-0">
                  <?php if(isset($header_title)): ?>
                  <?php echo $header_title; ?>

                  <?php else: ?>
                  <i class="bx bxs-home me-3"></i><span>Home</span>
                  <?php endif; ?>
                </h1>
            </div>
        </div>
    </div>
</section>

<!-- ======= Main content ======= -->
<main id="main">
<?php echo $__env->yieldContent('content'); ?>
</main>
<!-- ======= Main content end ======= -->

<?php if(auth()->guard()->guest()): ?>
<?php echo $__env->make('layouts/partials/modal_auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/axios/axios.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>

<script type="text/javascript">
var domain = 'http://localhost:8000/';

// toggle sidebar
var sidebar_show = false;
var sidebar_width = $('#sidebar').outerWidth();
$(window).resize(function() {
    if($(window).width() < 1199) {
        $('#sidebar').css('left', sidebar_width*-1);
        $('#container-header').css('padding-left', 0);
        $('#main').css('padding-left', 0);
        sidebar_show = false;
    } else {
        // $('#sidebar').css('left', 0);
        // $('#container-header').css('padding-left', sidebar_width);
        // $('#main').css('padding-left', sidebar_width);
        // sidebar_show = true;
    }
});
const toggleSidebar = (show) => {
  if(show == true) {
      $('#sidebar').css('left', sidebar_width*-1);
      if($(window).width() > 1199) {
        $('#container-header').animate({'padding-left': 0});
        $('#main').animate({'padding-left': 0});
      }
      sidebar_show = false;
  } else {
      $('#sidebar').css('left', 0);
      if($(window).width() > 1199) {
        $('#container-header').animate({'padding-left': sidebar_width});
        $('#main').animate({'padding-left': sidebar_width});
      }
      sidebar_show = true;
  }
};
$(document).ready(function(){
  if($(window).width() < 1199) {
      $('#sidebar').removeClass('show');
      sidebar_show = false;
  } else {
      $('#sidebar').removeClass('show').addClass('show');
      sidebar_show = false;
  }
  // tooltip
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
  })
  // popperjs
  $('.popper').popover({
      trigger: 'hover',
      html: true,
      placement: 'bottom',
      container: 'body'
  });
  <?php if(session('success')): ?>
    successMessage("<?php echo e(session('success')); ?>");
  <?php elseif(session('error')): ?>
    errorMessage("<?php echo e(session('error')); ?>");
  <?php endif; ?>
});
function successMessage(message) { toastr.success(message, 'Success!'); } 
function infoMessage(message) { toastr.info(message, 'Info'); } 
function warningMessage(message) { toastr.error(message, 'Warning!'); } 
function errorMessage(message) { toastr.error(message, 'Error!'); } 
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Staff\resources\views/layouts/master.blade.php ENDPATH**/ ?>