<!-- Check login status -->
<?php if(auth()->guard()->check()): ?>
<?php header("Location: /home"); die(); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="description" content="Blank Laravel Template by irzafarabi.com" />
<meta name="keywords" lan="en" content="blank, laravel, template" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Blank Laravel Template" />
<meta property="og:description" content="Blank Laravel Template by irzafarabi.com" />
<meta property="og:url" content="https://www.irzafarabi.com/" />
<meta property="og:site_name" content="www.irzafarabi.com" />
<meta property="og:image" content="<?php echo e(asset('img/bg/office-1.jpg')); ?>" />
<meta property="og:image:type" content="image/jpg" />
<meta property="og:image:width" content="1366" />
<meta property="og:image:height" content="768" />

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.1.1.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>Blank Laravel Template</title>

<style>
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark { color: #124265; } .title-light { color: #f1f1f1; }
#section-hero {
    height: 100vh;
    background: url('../img/bg/bg_trans-60.png') top left repeat, url("../img/bg/office-1.jpg") top center transparent fixed;
    background-size: cover;
    color: white;
    text-align: center;
}
.hero-title {
    text-transform: uppercase;
    letter-spacing: 2px;
}
.btn-hero { padding: 10px 20px; border: 2px solid white; border-radius: 4px; color: #fff; font-weight: 500; letter-spacing: 2px; }
.btn-hero:hover { background: #fff; color: #0b82b9; transition: ease .2s; }
.btn-hero1 { margin-right: 20px; padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: white; color: #202020; }
.btn-hero1:hover { background: transparent; color: white; transition: ease .4s; }
.btn-hero2 { padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: transparent; }
.btn-hero2:hover { background: white; color: #202020; transition: ease .4s; }

.img-logo-sm { width: 60px; }
.img-logo-md { width: 120px; }

@media (max-width: 768px) {
}
</style>
</head>
<body>

<!-- section-hero -->
<section id="section-hero">
    <div class="container">
        <div class="row vh-100 vertical-center justify-content-center">
            <div class="col-md-8">
                <!-- <img class="img-logo-md" src="<?php echo e(asset('img/logo/logo.png')); ?>" alt=""> -->
                <h1 class="hero-title display-1 mb-20">IRZAFARABI.COM</h1><hr style="height:3px"/>
                <p class="mb-5 font-12">Some Good Stuff</p>
                <p><a href="" class="btn-hero">Explore</a></p>
            </div>
        </div>
    </div>
</section>
<!-- section-hero end -->

<!-- section-about -->
<section id="section-about">
    <div class="container">
        <div class="row justify-content-center ptb-60">
            <div class="col-md-10 mb-3">
                <h1 class="section-title title-dark">About Us</h1>
            </div>
            <div class="col-md-10 mb-3">
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc lacinia congue lacus, quis congue turpis placerat quis. Pellentesque in lorem sit amet dolor interdum fringilla. Ut lobortis sit amet elit ut cursus. Quisque viverra velit a tortor sollicitudin laoreet. Curabitur a tellus vitae urna venenatis scelerisque et ut velit. Phasellus ut ipsum diam. Nullam eu nunc mauris. Suspendisse quis faucibus orci. Integer gravida metus a dignissim ultrices. Donec vitae libero non quam bibendum fermentum. Aenean mauris leo, scelerisque eget metus in, dignissim cursus nunc. Maecenas id fermentum neque, ac viverra arcu. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut at interdum mi.</p>
                <p>Integer in efficitur est. Vestibulum in sem vel eros mollis accumsan. Praesent quam ante, dictum sit amet efficitur gravida, vulputate eget nunc. Nunc consectetur id diam nec tincidunt. Nam sed maximus ipsum. Duis facilisis non elit ut maximus. Morbi ullamcorper quis purus in tempor. Vestibulum et tempus tellus. Maecenas porta vel sem sed bibendum. Pellentesque accumsan aliquam ipsum auctor euismod. Nullam venenatis viverra lorem, non consectetur lectus ullamcorper quis. </p>
            </div>
        </div>
    </div>
</section>
<!-- section-about end -->

</body>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>

<!-- Purecounter -->
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
$(document).ready(function(){
  <?php if(session('success')): ?>
    successMessage("<?php echo e(session('success')); ?>");
  <?php elseif(session('error')): ?>
    errorMessage("<?php echo e(session('error')); ?>");
  <?php endif; ?>
  <?php if(isset($_GET['admin']) == 'false'): ?>
    Swal.fire({
      icon: 'error',
      title: "Access Denied!",
      text: "You are not an admin!",
      showConfirmButton: false,
      timer: 2000
    });
  <?php endif; ?>
  
});
  function successMessage(message) {
      toastr.success(message, 'Success!');
  } 
  function infoMessage(message) {
      toastr.info(message, 'Info');
  } 
  function warningMessage(message) {
      toastr.error(message, 'Warning!');
  } 
  function errorMessage(message) {
      toastr.error(message, 'Error!');
  } 
</script>
</html><?php /**PATH C:\xampp\htdocs\irzafarabi.com\irzafarabi\resources\views/index.blade.php ENDPATH**/ ?>