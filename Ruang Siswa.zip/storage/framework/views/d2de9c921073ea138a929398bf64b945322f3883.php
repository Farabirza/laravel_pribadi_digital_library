

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/cropper/cropper.min.css')); ?>" rel="stylesheet">
<style>
#section-content { padding: 30px 20px; }

#container-profile-img {
    <?php if(Auth::user()->profile->cover_image): ?>
    background: url("<?php echo e(asset('img/covers/'.Auth::user()->profile->cover_image)); ?>") center center fixed;
    background-size: cover;
    <?php else: ?>
    background: url("<?php echo e(asset('img/bg/default.jpg')); ?>") center center fixed;
    <?php endif; ?>
}
@media (max-width: 768px) {
    #section-content { padding: 30px 1%; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content" class="bg-light">
    <div class="container">
        <!------------------------------- row start ------------------------->
        <div class="row mb-4">
            <div id="container-profile-img" class="col-md-12 bg-white p-4 rounded shadow-sm"> <!-- col form start -->
                <?php if(Auth::user()->profile->cover_image): ?>
                <input type="hidden" name="get_bg_image" value="<?php echo e(asset('img/covers/'.Auth::user()->profile->cover_image)); ?>">
                <?php else: ?>
                <input type="hidden" name="get_bg_image" value="<?php echo e(asset('img/bg/default.jpg')); ?>">
                <?php endif; ?>
                <?php echo $__env->make('layouts.partials.profile_image_cropper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="d-flex justify-content-center">
                    <label id="btn-edit-cover-image" class="btn btn-light btn-sm d-flex align-items-center me-3" for="form-cover_image"><i class='bx bx-image-alt me-1' ></i>Gambar sampul</label>
                    <button id="btn-edit-background-layer" class="btn btn-light btn-sm d-flex align-items-center"><i class='bx bx-layer me-1' ></i>Background layer</button>
                </div>
            </div> <!-- col form end -->
        </div>
        <!------------------------------- row end ------------------------->

        <!------------------------------- row start ------------------------->
        <div class="row mb-4">

            <div class="col-md-12 card p-3 mb-4">
                <div class="card-body">
                    <table class="table table-borderless">
                        <tbody>
                            <!-- reset password start -->
                            <form action="/ajax/dashboard" method="post" id="form-password-reset" class="m-0">
                            <tr>
                                <th class='text-primary'>
                                    Reset Password
                                </th>
                            </tr>
                            <tr>
                                <td>
                                    <label for="password" class="form-label me-3">Password</label>
                                </td>
                                <td>
                                    <input type="password" name="password" class="form-control form-control-sm">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="password" class="form-label me-3">Konfirmasi password</label>
                                </td>
                                <td>
                                    <input type="password" name="password_confirmation" class="form-control form-control-sm">
                                </td>
                            </tr>
                            <tr class="error-password d-none">
                                <td></td>
                                <td class="error-password-message text-danger fs-11"></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <div class="d-flex justify-content-end align-items-center">
                                        <hr class="col me-3"/>
                                        <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-key me-2'></i>Reset</button>
                                    </div>
                                </td>
                            </tr>
                            </form>
                            <!-- reset password end -->
                            <tr></tr>
                            <!-- accessibility start -->
                            <tr>
                                <th class="text-primary">Aksesibilitas</th>
                            </tr>
                            <tr>
                                <td>
                                    Siapa saja yang dapat mengunjungi halaman CV anda? <i id="help-access" class='bx bx-help-circle' data-bs-toggle="tooltip" data-bs-placement="top" title="Penjelasan"></i>
                                </td>
                                <td>
                                    <select name="access" class="form-control form-select-sm form-select col select-access" required>
                                        <option value="public">Publik</option>
                                        <option value="draft">Hanya saya sendiri</option>
                                        <option value="registered">Pengunjung terdaftar</option>
                                        <option value="link">Pengunjung dengan link</option>
                                    </select>
                                </td>
                            </tr>
                            <tr><td colspan="2"><hr/></td></tr>
                            <!-- accessibility end -->
                            <tr></tr>
                            <!-- meta data start -->
                            <form action="/ajax/dashboard" method="post" id="form-meta-data" class="m-0">
                            <tr>
                                <th class="text-primary">Meta Data</th>
                            </tr>
                            <tr>
                                <td>Image</td>
                                <td>
                                    <?php if(Auth::user()->config->meta_image != null): ?>
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('img/materials/noimage.jpg')); ?>" class="border rounded" style="max-height:180px" alt="">
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="meta-title" class="form-label">Title</label>
                                </td>
                                <td>
                                    <input type="text" name="meta-title" class="form-control form-control-sm" value="<?php echo e(Auth::user()->config->meta_title); ?>"/>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="meta-description" class="form-label">Description</label>
                                </td>
                                <td>
                                    <textarea name="meta-description" rows="3" class="form-control"><?php echo e(Auth::user()->config->meta_description); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label for="meta-keywords" class="form-label">Keywords</label>
                                </td>
                                <td>
                                    <textarea name="meta-keywords" rows="2" class="form-control"><?php echo e(Auth::user()->config->meta_keywords); ?></textarea>
                                </td>
                            </tr>
                            <tr class="error-meta d-none">
                                <td></td>
                                <td class="error-meta-message text-danger fs-11"></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <div class="d-flex justify-content-end align-items-center">
                                        <hr class="col me-3"/>
                                        <button type="submit" class="btn btn-primary btn-sm"><i class='bx bxs-send me-2'></i>Submit</button>
                                    </div>
                                </td>
                            </tr>
                            </form>
                            <!-- meta data end -->
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        <!------------------------------- row end ------------------------->

    </div>
</section>

<!-- modal background layer start -->
<div class="modal fade" id="modal-edit-background-layer" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center"><i class='bx bx-layer me-2'></i>Edit background layer</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="form-edit-background-layer" action="/dashboard/update/background_layer" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="px-4 mb-3">
                    <div id="bg-layer-preview" class="card w-100" style="height:240px;background:#999"><div id="bg-layer-preview-inner" class="w-100 h-100"></div></div>
                </div>
                <div class="d-flex px-3 mb-3">
                    <span class="me-3" style="width:10%;background:red;"></span>
                    <input type="range" name="hero_layer_r" class="form-range col" min="1" max="255" step="1" value="0">
                </div>
                <div class="d-flex px-3 mb-3">
                    <span class="me-3" style="width:10%;background:green;"></span>
                    <input type="range" name="hero_layer_g" class="form-range col" min="1" max="255" step="1" value="0">
                </div>
                <div class="d-flex px-3 mb-3">
                    <span class="me-3" style="width:10%;background:blue;"></span>
                    <input type="range" name="hero_layer_b" class="form-range col" min="1" max="255" step="1" value="0">
                </div>
                <div class="d-flex px-3 mb-3">
                    <span class="border me-3" style="width:10%;background:white;"></span>
                    <input type="range" name="hero_layer_a" class="form-range col" min="0" max=".7" step=".05" value="0">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back me-1'></i>Batalkan</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-edit-alt me-1'></i>Update</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- modal background layer end -->

<!-- modal cover image start -->
<div class="modal fade" id="modal-edit-cover-image" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title d-flex align-items-center"><i class='bx bx-image-alt me-2'></i>Change cover image</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="form-edit-cover-image" action="/dashboard/update/cover_image" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <img src="<?php echo e(asset('img/bg/default.jpg')); ?>" id="cover_preview" class="img-fluid img-thumbnail mb-2" style="max-height:320px"/>
                <input type="file" id="form-cover_image" name="cover_image" class="form-control mb-3" accept="image/png, image/jpeg, image/jpg"/>
                <p class="fs-11 text-secondary fst-italic">*pilihlah gambar dengan format dimensi landscape</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back me-1'></i>Batalkan</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class='bx bx-upload me-1'></i>Upload</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- modal cover image end -->

<!-- Modal help access -->
<div class="modal fade" id="modal-help-access" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title fs-18 display-5"><i class='bx bx-help-circle me-1'></i> Penjelasan menu aksesibilitas</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h5 class="fw-bold">Publik</h5>
                <p class="fs-11">Semua orang dapat mengakses halaman CV tanpa perlu membuat akun CVKreatif.com. Halaman CV juga dapat diakses melalui fitur search.</p>
                <h5 class="fw-bold">Hanya saya sendiri</h5>
                <p class="fs-11">Hanya pemilik yang dapat mengakses halaman CV. Fitur ini digunakan apabila CV masih belum siap ditayangkan secara umum.</p>
                <h5 class="fw-bold">Pengunjung terdaftar</h5>
                <p class="fs-11">Dapat dicari melalui fitur search namun hanya pengunjung terdaftar yang dapat mengakses halaman CV.</p>
                <h5 class="fw-bold">Pengunjung dengan link</h5>
                <p class="fs-11">Tidak dapat dicari melalui fitur search namun siapa saja dapat mengakses halaman CV langsung melalui link yang dibagikan pemilik.</p>
            </div>
        </div>
    </div>
</div>
<!-- Modal help access end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/cropper/cropper.min.js')); ?>"></script>
<script>
$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }});

/* ---------------------------------------------- reset password start -------------------------------------- */
$('#form-password-reset').submit(function(e){
    e.preventDefault();
    var formData = new FormData(this);
    formData.append('action', 'password_reset');
    // var formData = { 
    //     action: 'password_reset',
    // };
    $.ajax({
        type: "POST",
        url: "/ajax/dashboard",
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'JSON',
        success: function (response) {
            if(response.error == true) {
                $('.error-password').removeClass('d-none');
                $('.error-password-message').html('');
                const error_messages = (element, index) => {
                    $('.error-password-message').append('<li>' + element + '</li>');
                }
                response.messages.forEach(error_messages);
            } else {
                successMessage(response.messages);
                $('.error-password-message').html('');
                $('.error-password').addClass('d-none');
                $('#form-password-reset').trigger('reset');
            }
        }, error:function(response) {
            errorMessage("Terdapat kesalahan");
        },
    });
});
/* ---------------------------------------------- reset password end -------------------------------------- */
/* ---------------------------------------------- meta data start -------------------------------------- */
$('#form-meta-data').submit(function(e){
    e.preventDefault();
    var formData = new FormData(this);
    formData.append('action', 'update_meta');
    $.ajax({
        type: "POST",
        url: "/ajax/dashboard",
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'JSON',
        success: function (response) {
            if(response.error == true) {
                $('.error-meta').removeClass('d-none');
                $('.error-meta-message').html('');
                const error_messages = (element, index) => {
                    $('.error-meta-message').append('<li>' + element + '</li>');
                }
                response.messages.forEach(error_messages);
            } else {
                successMessage(response.messages);
                $('.error-meta-message').html('');
                $('.error-meta').addClass('d-none');
                $('#form-meta').trigger('reset');
            }
        }, error:function(response) {
            errorMessage("Terdapat kesalahan");
        },
    });
});
/* ---------------------------------------------- meta data end -------------------------------------- */

/* ---------------------------------------------- cover image -------------------------------------- */
$('[name="cover_image"]').change(function() {
    let reader = new FileReader();
    reader.onload = (e) => { 
        $('#cover_preview').attr('src', e.target.result); 
    }
    reader.readAsDataURL(this.files[0]); 
    $('#modal-edit-cover-image').modal('show');
});

/* ---------------------------------------------- background layer start -------------------------------------- */
var bg_image = 'url('+$('[name="get_bg_image"]').val()+')';
var hero_layer_r = '<?php echo e($hero_layer->r); ?>'; var hero_layer_g = '<?php echo e($hero_layer->g); ?>'; var hero_layer_b = '<?php echo e($hero_layer->b); ?>'; var hero_layer_a = '<?php echo e($hero_layer->a); ?>';
$('[name="hero_layer_r"]').val(hero_layer_r);
$('[name="hero_layer_g"]').val(hero_layer_g);
$('[name="hero_layer_b"]').val(hero_layer_b);
$('[name="hero_layer_a"]').val(hero_layer_a);

$('#btn-edit-background-layer').click(function(){
    $('#bg-layer-preview-inner').css({
        'background': 'linear-gradient(rgba('+hero_layer_r+','+hero_layer_g+','+hero_layer_b+','+hero_layer_a+'), rgba('+hero_layer_r+','+hero_layer_g+','+hero_layer_b+','+hero_layer_a+')),'+ bg_image, 
        'background-size': 'cover'});
    $('#modal-edit-background-layer').modal('show');
});
$('[name="hero_layer_r"]').change(function(){
    var hero_layer_r = $(this).val();
    var hero_layer_g = $('[name="hero_layer_g"]').val();
    var hero_layer_b = $('[name="hero_layer_b"]').val();
    var hero_layer_a = $('[name="hero_layer_a"]').val();
    bg_layer_update(hero_layer_r, hero_layer_g, hero_layer_b, hero_layer_a);
});
$('[name="hero_layer_g"]').change(function(){
    var hero_layer_r = $('[name="hero_layer_r"]').val();
    var hero_layer_g = $(this).val();
    var hero_layer_b = $('[name="hero_layer_b"]').val();
    var hero_layer_a = $('[name="hero_layer_a"]').val();
    bg_layer_update(hero_layer_r, hero_layer_g, hero_layer_b, hero_layer_a);
});
$('[name="hero_layer_b"]').change(function(){
    var hero_layer_r = $('[name="hero_layer_r"]').val();
    var hero_layer_g = $('[name="hero_layer_g"]').val();
    var hero_layer_b = $(this).val();
    var hero_layer_a = $('[name="hero_layer_a"]').val();
    bg_layer_update(hero_layer_r, hero_layer_g, hero_layer_b, hero_layer_a);
});
$('[name="hero_layer_a"]').change(function(){
    var hero_layer_r = $('[name="hero_layer_r"]').val();
    var hero_layer_g = $('[name="hero_layer_g"]').val();
    var hero_layer_b = $('[name="hero_layer_b"]').val();
    var hero_layer_a = $(this).val();
    bg_layer_update(hero_layer_r, hero_layer_g, hero_layer_b, hero_layer_a);
});

const bg_layer_update = (r, g, b, a) => {
    var rgba_val = 'linear-gradient(rgba('+r+','+g+','+b+','+a+'), rgba('+r+','+g+','+b+','+a+')),'+ bg_image;
    $('#bg-layer-preview-inner').css({'background': rgba_val, 'background-size': 'cover'});
}
/* ---------------------------------------------- background layer end -------------------------------------- */

// access help
$('#help-access').click(function(){
    $('#modal-help-access').modal('show');
});

// change accessibility
$('[name="access"]').change(function(){
    var access = $(this).find(":selected").val();
    var formData = { 
        action: 'update_access', access: access,
    };
    $.ajax({
        type: "POST",
        url: "/ajax/dashboard",
        data: formData,
        dataType: 'JSON',
        success: function (data) {
            successMessage(data.message);
        }, error:function(data) {
            errorMessage('Terdapat kesalahan');
        },
    });
});

$(document).ready(function(){ 
    $('.nav-link').removeClass('active'); $('#link-config').addClass('active'); // nav-link active
    
    // setup background
    $('#container-profile-img').css({
        'background': 'linear-gradient(rgba('+ hero_layer_r +', '+ hero_layer_g +', '+ hero_layer_b +', '+ hero_layer_a +'), rgba('+ hero_layer_r +', '+ hero_layer_g +', '+ hero_layer_b +', '+ hero_layer_a +')),'+ bg_image + 'center center fixed',
        'background-size': 'cover',
    });

    // selected access
    let selected_access = '<?php echo e(Auth::user()->config->access); ?>';
    $("[name='access'] option[value='" + selected_access + "']").attr('selected', 'selected');
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/dashboard/config.blade.php ENDPATH**/ ?>