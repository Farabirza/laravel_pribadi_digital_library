<!-- Check login status -->

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="description" content="cvkreatif.com" />
<meta name="keywords" lan="en" content="blank, laravel, template" />
<meta property="og:type" content="laravel app" />
<meta property="og:title" content="cvkreatif.com" />
<meta property="og:description" content="Buat halaman portofolio kamu di sini, gratis!" />
<meta property="og:url" content="https://www.cvkreatif.com/" />
<meta property="og:site_name" content="www.cvkreatif.com" />
<meta property="og:image" content="<?php echo e(asset('img/theme_preview/default.png')); ?>" />
<meta property="og:image:type" content="image/jpg" />
<meta property="og:image:width" content="1366" />
<meta property="og:image:height" content="768" />

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.6.0.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/aos/aos.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>CVKreatif.com</title>

<style>
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark { color: #124265; } .title-light { color: #f1f1f1; }

#section-hero { background: #f8e9a1; padding-top: 60px; padding-bottom: 60px; }
#section-hero .row { height: 100%; }
/* .hero-category-item img:hover { box-shadow: 2px 2px 10px #333; cursor: pointer; } */

#section-users .users-container { padding-left: 40px; padding-right: 40px; }
#intro-menu a {
  display: inline-block;
  position: relative;
} #intro-menu a::after {
  content: '';
  position: absolute;
  width: 100%;
  transform: scaleX(0);
  height: 2px;
  bottom: 0;
  left: 0;
  background-color: #374785;
  transform-origin: bottom right;
  transition: transform 0.25s ease-out;
} #intro-menu a:hover::after {
  transform: scaleX(1);
  transform-origin: bottom left;
}

/* -------------------- fancy button start -------------------- */
/* -------------------- fancy button end -------------------- */

@media (max-width: 992px) {
  #section-hero { padding-top: 20px; padding-bottom: 20px; }
  #section-hero .container { display: flex; align-items: center; }
  #section-hero .row { height: initial; }
  #hero-intro img { padding-bottom: 20px; }
  #section-topbar, .hero-category-row { display: none; }
  #section-users .users-container { padding: 20px; }
}
</style>
</head>
<body>

<!-- section-hero -->
<section id="section-hero" class="vh-100">
    <div class="container h-100">
        <div id="hero-intro" class="row align-items-center justify-content-center mb-4">
          <div class="col-md-4 text-end px-4">
            <img class="img-fluid" src="<?php echo e(asset('/img/materials/gif-dekstop.gif')); ?>" style="max-height: 480px"/>
          </div>
          <div class="col-md-4 px-4">
            <?php if(auth()->guard()->guest()): ?>
            <h1 class="fw-bold text-capitalize mb-4" style="color:#374785; font-size:36pt; lettter-spacing:2em">Buat halaman portofolio kamu di sini, gratis!</h1>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
            <h1 class="fw-bold text-capitalize mb-4" style="color:#374785; font-size:36pt; lettter-spacing:2em">Selamat datang, <span class="text-primary text-lowercase"><?php echo e(Auth::user()->username); ?></span></h1>
            <?php if(isset(Auth::user()->profile) && isset(Auth::user()->config)): ?>
            <p id="intro-menu" class="d-flex flex-wrap justify-content-between" style="color:#374785">
              <a href="/cv/<?php echo e(Auth::user()->username); ?>">Halaman CV</a> &#8226; 
              <a href="/wizard/profile">Quick Setup</a> &#8226; 
              <a href="/dashboard/overview">Dashboard</a>
            </p>
              <?php if(Auth::user()->role->name != "user"): ?>
              <hr/>
              <p>
                <a href="/admin/overview" class="btn btn-sm btn-primary"><span class="d-flex align-items-center"><i class='bx bxs-star me-2'></i>Admin Dashboard</span></a>
              </p>
              <?php endif; ?>
            <?php else: ?>
            <!-- <a href="/wizard/profile" class="btn btn-outline-primary px-4 rounded rounded-circle"><i class='bx bx-message-square-add me-1' ></i> Buat halaman CV</a> -->
            <p id="intro-menu" class="d-flex justify-content-between fs-14" style="color:#374785">
              <a href="/wizard/profile" class="d-flex align-items-center"><i class='bx bx-right-arrow-alt me-2'></i> Buat halaman CV</a>
            </p>
            <?php endif; ?>
            <?php else: ?>
            <button class="btn btn-outline-primary w-100 mb-2 btn-modal-login">Sign in</button>
            <a href="/auth/google" class="btn btn-danger d-flex align-items-center justify-content-center mb-3 fs-10"><i class='bx bx-xs bxl-google-plus me-2'></i><span>Continue with Google</span></a>
            <p>Belum punya akun? <a href="#" class="text-primary btn-modal-register"><u>Sign up</u></a></p>
            <?php endif; ?>
          </div>
        </div>
    </div>
</section>
<!-- section-hero end -->

<?php echo $__env->make('layouts/partials/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="wrapper-content"> <!-- wrapper-content start -->

<!-- section-intro start  -->
<section id="section-intro" class="bg-white py-5">
  <div class="container">
    <div class="row py-5 align-items-center justify-content-center">
      <div class="col-md-5 px-3 text-end">
        <img src="<?php echo e(asset('img/materials/resume_2_man.jpg')); ?>" class="shadow" style="max-height:480px" alt="">
      </div>
      <div class="col-md-5 px-3">
        <h3 class="display-5 mb-3">Tentang CVKreatif</h3>
        <p>
            Portofolio online adalah alat vital bagi setiap profesional kreatif yang ingin memamerkan karya mereka dan membangun merek pribadi mereka. Dengan munculnya teknologi, membuat portofolio online menjadi lebih mudah dari sebelumnya. 
        </p><p>
            <b>CVKreatif.com</b> merupakan aplikasi web yang dirancang khusus untuk membuat portofolio yang menakjubkan dan terlihat profesional, memungkinkan pengguna menampilkan keahlian dan pengalaman mereka kepada dunia. 
        </p><p>
            Aplikasi web ini memberikan alternatif yang hemat biaya dan ramah pengguna untuk mempekerjakan seorang desainer web dan merupakan cara yang bagus bagi individu kreatif untuk mengendalikan kehadiran online mereka. Baik Anda seorang desainer grafis, fotografer, atau artis, portofolio online yang dibuat melalui aplikasi web harus dimiliki di era digital saat ini.
        </p>
      </div>
    </div>
  </div>
</section>
<!-- section intro end -->

<!-- section footer start -->
<section id="section-footer" class="bg-dark">
    <div class="container">
        <div class="row d-flex justify-content-center align-items-center py-4"> <!-- row start -->
            <div class="col-md-8 text-center">
                <span class="text-light">Powered by : <b>cvkreatif.com</b></span>
            </div>
        </div> <!-- row end -->
    </div>
</div>
<!-- section footer end -->

</div> <!-- wrapper-content end -->

<!-- =========================================== modals =========================================== -->
<div class="modal fade" id="modal-users-bio" aria-hidden="true"> 
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title align-middle fw-bold"><span class="px-2 py-1 bg-primary text-light rounded-circle me-1"><i class='bx bx-user'></i></span> Biodata</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p id="modal-users-bio-content"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Close</button>
            </div>
        </div>
    </div>
</div>

<!-- =========================================== modals end =========================================== -->

</body>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/scrollTo/jquery.scrollTo.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/aos/aos.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('/js/navbar.js')); ?>"></script>

<!-- Purecounter -->
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
$('.btn-modal-users-bio').click(function(e){
  let bio = $(this).html();
  $('#modal-users-bio-content').html(bio);
  $('#modal-users-bio').modal('show');
});

$(document).ready(function(){
  <?php if(session('success')): ?>
    successMessage("<?php echo e(session('success')); ?>");
  <?php elseif(session('error')): ?>
    errorMessage("<?php echo e(session('error')); ?>");
  <?php endif; ?>
  <?php if(isset($_GET['admin'])): ?>
    Swal.fire({
      icon: 'error',
      title: "Akses ditolak!",
      text: "Anda bukan admin!",
      showConfirmButton: false,
      timer: 2000
    });
  <?php endif; ?>
  <?php if(isset($_GET['info'])): ?>
    Swal.fire({
      icon: 'info',
      title: "<?php echo e($_GET['info']); ?>",
      showConfirmButton: false,
      timer: 3000
    });
  <?php endif; ?>
  <?php if(isset($_GET['login'])): ?>
    errorMessage('Anda perlu login terlebih dahulu');
    $('#modal-login').modal('show');
  <?php endif; ?>

  $('.hero-category-item').hover(function(){
    $('img', this).css('box-shadow', '2px 2px 10px #333'); $('h5', this).css({'font-weight': "bolder", "color": "#374785"});
  }, function(){
    $('img', this).css('box-shadow', 'none'); $('h5', this).css({'font-weight': "", "color": "#202020"});
  });

  /* Scroll function */
	$(document).scroll(function() {
		var y = $(this).scrollTop(); 
		var navbar_offset = $('#section-navbar').offset().top; 
		var section_hero = $('#section-hero'); 
    var wrapper_content = $('#wrapper-content');
    var p = $('#section-hero').outerHeight();
    if (y >= navbar_offset) { 
      $('#section-navbar').addClass('fixed-top').css('box-shadow', '0 0 1px rgba(0,0,0,.125),0 1px 3px rgba(0,0,0,.2)');
      $('#wrapper-content').css('padding-top', $('#navbar').outerHeight());
    } if (y <= wrapper_content.offset().top) { 
			$('#section-navbar').removeClass('fixed-top').css('box-shadow', 'none');
      $('#wrapper-content').css('padding-top', 0);
		}
	});
  /* Scroll function end */
  
});
function successMessage(message) {
    toastr.success(message, 'Success!');
} 
function infoMessage(message) {
    toastr.info(message, 'Info');
} 
function warningMessage(message) {
    toastr.error(message, 'Warning!');
} 
function errorMessage(message) {
    toastr.error(message, 'Error!');
} 
</script>
</html><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/index.blade.php ENDPATH**/ ?>