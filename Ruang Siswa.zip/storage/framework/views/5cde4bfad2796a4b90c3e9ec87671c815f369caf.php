

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/aos/aos.css')); ?>" rel="stylesheet">
<style>
.search-container {
  position: relative;
}

.search-container i {
  position: absolute;
  right: 15px;
  top: 12px;
  color: #ced4da;
}

.book-content {
  position: relative;
  border-radius: 10px;
  width: 258px;
  height: 360px;
  background-color: whitesmoke;
  transform: preserve-3d;
  perspective: 2000px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #000;
  margin: auto;
}

.book-content .book-cover {
  top: 0;
  overflow: hidden;
  position: absolute;
  background-color: lightgray;
  width: 100%;
  height: 100%;
  border-radius: 10px;
  transition: all 0.5s;
  transform-origin: 0;
}
.book-cover > img { height: 100%; }

.book-nav-in { display: flex; align-items: center; justify-content: center;  }
.book-nav-out { display: none; }

#pagination-books div { gap: 12px; }

@media (min-width: 1199px) {
    .book-content:hover .book-cover {
        transition: all 0.5s;
        transform: rotatey(-80deg);
    }
}
@media (max-width: 1199px) {
    h3 { font-size: 18pt; }
    .book-nav-in { display: none; }
    .book-nav-out { display: block; }
    .book-content {
        width: 194px;
        height: 270px;
    }
    .book-title {
        text-wrap: wrap;
        max-width: 194px;
    }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="">
    
    <!-- container start -->
    <div class="container mb-5">
        <div class="row justify-content-center py-5">
            <?php if(Auth::check() && Auth::user()->profile->role != 'student' && count($notification) > 0): ?>
            <div class="col-md-12 mb-3">
                <div class="alert alert-info fs-11">
                    <h5 class="display-5 fs-24 mb-2 d-flex align-items-center gap-2"><i class="bx bx-bell"></i>Attention</h5>
                    <ul>
                        <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo $message; ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
            <?php $catchphrases = [
                "Unlock the World of Knowledge, Journey into Boundless Collection of Literature!",
                "Explore, Engage, Empower: Dive into the Digital Library!",
                "Unlimited Knowledge at Your Fingertips: Your Digital Library Adventure Begins Now.",
                "Books in Bits: Your Gateway to the Digital Library Universe.",
                "Turn the Page, Swipe the Screen: Embrace the Future with the Digital Library.",
                "Read, Click, Learn: Your Personalized Digital Library Awaits.",
                "Beyond Boundaries, Within Reach: Discover the Magic of the Digital Library.",
                "Libraries Unchained: Your Passport to the World of Digital Reading.",
                "Scroll and Enroll: Enrich Your Mind with the Digital Library Experience.",
                "Reading Reimagined: Where Tradition Meets Technology in the Digital Library.",
                "Words Wired for Wonder: Immerse Yourself in the Digital Library Delight.",
                "Bytes of Brilliance: Unleash the Power of the Digital Library Today.",
                "E-Books, E-Learning, E-mpowerment: Welcome to the Digital Library Revolution.",
                "Flip to the Future: Your Reading Journey Elevated in the Digital Library.",
                "From Codex to Clicks: Elevate Your Reading with the Digital Library Evolution.",
                "More Than Just Pages: Experience the Interactive Joy of the Digital Library."
            ]; $randomIndex = array_rand($catchphrases); $randomCatchphrase = $catchphrases[$randomIndex]; ?>
            <div class="col-md-12 text-center mb-3">
                <p class="fs-12 mb-2">Welcome to</p>
                <h1 class="display-5 fs-24 text-uppercase mb-2">Pribadi School Depok <span id="typed" class="text-primary"></span></h1>
                <p class="fs-11 text-secondary fst-italic">"<?php echo e($randomCatchphrase); ?>"</p>
            </div>
            <div class="col-md-8">
                <form id="form-search" action="/book" method="get" class="form-search">
                    <div class="search-container">
                        <?php $studySubjects = [ 'mathematics', 'biology', 'physics', 'chemistry', 'history', 'geography', 'english', 'computer', 'literature', 'economics', 'art', 'foreign language', 'music', 'social studies']; ?>
                        <input  id="search-keyword" type="search" name="search" class="form-control" autocomplete="off" placeholder="search something, try <?php echo e($studySubjects[array_rand($studySubjects)]); ?>" value="<?php echo e((isset($_GET['search']) ? $_GET['search'] : '')); ?>"><i type="button" class="bx bx-search-alt-2" onclick="searchBook()"></i>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <!-- book container start -->
            <div id="container-books" class="col-md-12 d-flex flex-wrap justify-content-center gap-3 mb-5">
                <?php $i = 1; ?>
                <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="item-book p-3 my-2" data-aos="fade-down" data-aos-duration="<?php echo e($i*100); ?>">
                    <div class="book-content shadow">
                        <div class="text-center">
                            <div class="px-4 mb-3">
                                <h5 id="book-title-<?php echo e($i); ?>" class="display-5 fs-14 mb-2"><?php echo e($book->title); ?></h5>
                                <p class="fs-9 mb-1">
                                    <?php if($book->author): ?><a href="/book?search=<?php echo e($book->author); ?>"><?php echo e($book->author); ?></a><?php endif; ?>
                                    <?php if($book->publisher): ?>| <a href="/book?search=<?php echo e($book->publisher); ?>"><?php echo e($book->publisher); ?></a><?php endif; ?>
                                </p>
                                <p class="fs-9 text-secondary mb-3"><a href="/book?search=<?php echo e($book->category->name); ?>" id="book-category-<?php echo e($i); ?>"><?php echo e($book->category->name); ?></a></p>
                            </div>
                            <div class="book-nav-in flex-wrap gap-2">
                                <a href="/book/<?php echo e($book->id); ?>" class="btn btn-secondary btn-sm fs-9 px-2 py-1 gap-1"><i class="bx bx-info-circle"></i>Detail</a>
                                <span role="button" class="btn btn-primary btn-sm fs-9 px-2 py-1" onclick="modalChapters('<?php echo e($book->id); ?>', '<?php echo e($i); ?>')">Read &raquo;</span>
                            </div>
                            <?php if(Auth::check() && Auth::user()->authority->name != 'user'): ?>
                            <div class="d-flex justify-content-center mt-2">
                                <button class="btn btn-outline-dark btn-sm fs-9 px-2 py-1 gap-1" onclick="modalQuickEdit('<?php echo e($book->id); ?>', '<?php echo e($i); ?>')"><i class="bx bx-edit-alt"></i>Quick edit</button>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="book-cover d-flex align-items-center justify-content-center">
                            <?php if($book->image != null): ?>
                            <img src="<?php echo e(asset('img/covers/'.$book->image)); ?>" alt="">
                            <?php else: ?>
                            <img src="<?php echo e(asset('img/covers/cover-'.rand(1,3).'.jpg')); ?>" alt="">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="book-nav-out mt-4">
                        <div class="mb-2">
                            <h5 class="book-title display-5 fs-12 text-center"><?php echo e($book->title); ?></h5>
                        </div>
                        <div class="d-flex flex-wrap align-items-center justify-content-center gap-3 fs-11">
                            <a href="/book/<?php echo e($book->id); ?>" class="hover-underline">Detail</a>
                            -
                            <span role="button" class="hover-underline" onclick="modalChapters('<?php echo e($book->id); ?>', '<?php echo e($i); ?>')">Read</span>
                        </div>
                        <?php if(Auth::check() && Auth::user()->authority->name != 'user'): ?>
                        <div class="d-flex justify-content-center mt-2">
                            <button class="btn btn-outline-dark gap-1 fs-9 py-1" onclick="modalQuickEdit('<?php echo e($book->id); ?>', '<?php echo e($i); ?>')"><i class="bx bx-edit-alt"></i>Edit</button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <input type="hidden" id="book-id-<?php echo e($i); ?>" name="book_id" value="<?php echo e($book->id); ?>">
                <input type="hidden" id="book-publisher-<?php echo e($i); ?>" name="publisher" value="<?php echo e($book->publisher); ?>">
                <input type="hidden" id="book-publication_year-<?php echo e($i); ?>" name="publication_year" value="<?php echo e($book->publication_year); ?>">
                <input type="hidden" id="book-isbn-<?php echo e($i); ?>" name="isbn" value="<?php echo e($book->isbn); ?>">
                <input type="hidden" id="book-description-<?php echo e($i); ?>" name="description" value="<?php echo e($book->description); ?>">
                <input type="hidden" id="book-url-<?php echo e($i); ?>" name="url" value="<?php echo e($book->url); ?>">
                <input type="hidden" id="book-keywords-<?php echo e($i); ?>" name="keywords" value="<?php echo e($book->keywords); ?>">
                <input type="hidden" id="book-source-<?php echo e($i); ?>" name="source" value="<?php echo e($book->source); ?>">
                <input type="hidden" id="book-chapter-count-<?php echo e($i); ?>" name="chapter_count" value="<?php echo e(count($book->chapter)); ?>">
                <?php $j = 1; ?>
                <?php $__empty_2 = true; $__currentLoopData = $book->chapter->sortBy('number'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                <input type="hidden" id="book-chapter-id-<?php echo e($i); ?>-<?php echo e($j); ?>" name="chapter_id" value="<?php echo e($chapter->id); ?>">
                <input type="hidden" id="book-chapter-title-<?php echo e($i); ?>-<?php echo e($j); ?>" name="chapter_title" value="<?php echo e($chapter->title); ?>">
                <?php $j++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                <?php endif; ?>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="item-book w-100 p-3 text-center">
                    <span class="fs-11 text-muted fst-italic">Data not found</span>
                </div>
                <?php endif; ?>
            </div>
            <!-- book container end -->
            <!-- pagination start -->
            <div id="pagination-books" class="col-md-12 d-flex justify-content-center">
            <?php echo e($books->onEachSide(3)->appends($_GET)->links()); ?>

            </div>
            <!-- pagination end -->
        </div>
        <!-- row end -->
    </div>
    <!-- container end -->

    <!-- container most visited start -->
    <?php if(count($most_visited) > 0): ?>
    <div class="container-fluid bg-light">
        <div class="row p-5">
            <div class="col-md-12">
                <h3 class="display-5 text-center mb-0">Most visited books this week</h3>
                <div class="d-flex justify-content-center py-4">
                    <div class="border border-primary w-25"></div>
                </div>
                <div class="d-flex flex-wrap justify-content-center gap-3">
                    <?php $__currentLoopData = $most_visited; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-3">
                        <a href="/book/<?php echo e($book->id); ?>">
                            <figure class="hover-shine"><img src="<?php echo e(asset('img/covers/'.$book->image)); ?>" class="img-fluid rounded shadow" style="max-height: 280px;"></figure>
                        </a>
                        <div class="d-flex justify-content-center mt-2">
                            <p class="fs-11 text-wrap text-center mb-0" style="max-width: 180px"><a href="/book/<?php echo e($book->id); ?>"><?php echo e($book->title); ?></a></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- container most visited end -->

    <!-- container sign up and submit start -->
    <div class="container-fluid">
        <!-- row start -->
        <div class="row justify-content-center align-items-center" style="background:#fee396">
            <div class="col-md-5 py-2 px-4 text-end">
                <img src="<?php echo e(asset('img/materials/book-animate.gif')); ?>" alt="" class="img-fluid" style="max-height:480px">
            </div>
            <div class="col-md-5 p-4">
                <?php if(auth()->guard()->guest()): ?>
                <h5 class="display-5 fs-24">Can't find the book you're looking for?</h5>
                <p class="mb-3" style="font-weight:500"><span role="button" class="hover-underline fs-18" onclick="modal_login_show()">Sign up now!</span></p>
                <p class="mb-0 fs-11">Some books are limited to registered user. There are some benefits exclusive to user as well such as save the book to read later, review the content of the book, and request for a book to the community.</p>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                <h5 class="display-5 fs-24">Be a Part of an Ever Growing Reader Community!</h5>
                <p class="mb-3 fs-11">Our digital library is a treasure trove of knowledge and a sanctuary for readers of all ages, but we need your help to keep the shelves stocked with fresh, exciting, and diverse reads.</p>
                <p class="mb-0 fs-14">a total of <span class="purecounter fw-bold" data-purecounter-end="<?php echo e($books_count); ?>">0</span> books has been added so far</p>
                <p class="mb-0 fs-14"><a href="/book/create" class="hover-underline" style="font-weight:500">Contribute now!</a></p>
                <?php endif; ?>
            </div>
        </div>
        <!-- row end -->
    </div>
    <!-- container sign up and submit end -->
    

    <!-- container footer start -->
    <div class="container-fluid py-5 text-white fs-11" style="background:#404040">
        <!-- row start -->
        <div class="row justify-content-center">
            <div class="col-md-10 d-flex align-items-center justify-content-center gap-5">
                <a href="https://pribadidepok.sch.id/" target="_blank" class="btn btn-outline-light rounded-pill d-flex align-items-center gap-2"><i class="bx bx-globe"></i>pribadidepok.sch.id</a>
                <a href="https://www.instagram.com/sekolahpribadidepok/" target="_blank" class="btn btn-outline-light rounded-pill d-flex align-items-center gap-2"><i class="bx bxl-instagram"></i>@sekolahpribadidepok</a>
                <a href="https://www.youtube.com/@sekolahpribadidepok8225" target="_blank" class="btn btn-outline-light rounded-pill d-flex align-items-center gap-2"><i class="bx bxl-youtube"></i>Sekolah Pribadi Depok</a>
            </div>
        </div>
        <!-- row end -->
    </div>
    <!-- container footer start -->

</section>

<?php echo $__env->make('layouts.partials.modal_bookIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/typed/typed.min.js')); ?>"></script>
<script type="text/javascript">
var string = 'Digital Library, Online Archive, Cloud Repository';
var item = string.split(',');
var typed = new Typed('#typed', {
    strings: item, typeSpeed: 100, backSpeed: 50, backDelay: 2000, loop: true,
});

$(document).ready(function() {
    // var purecounter = new PureCounter({
    //     selector: ".purecounter",
    //     duration: 2,
    //     delay: 10,
    //     once: true,
    // });
    $('#link-book').addClass('active');
    $('#submenu-book').addClass('show');
    $('#link-book-index').addClass('active');
});

// Animate on scroll
AOS.init({ once: true,  easing: 'ease-in-out-sine' });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital Library - New\Pribadi Depok Digital Library\resources\views/index.blade.php ENDPATH**/ ?>