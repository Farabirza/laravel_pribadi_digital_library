

<?php $__env->startPush('css-styles'); ?>
<style>
:root {
  --sidebar-width: 100px;
}
img { max-height: 320px; }
td.fw-bold { color: #0563bb; }

/* ========================== Navigation start ========================== */
#theme-navbar {
    z-index: 999;
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: var(--sidebar-width);
    transition: all ease-in-out 0.5s;
    transition: all 0.5s;
    padding: 0 15px;
    overflow-y: auto;
} .mobile-nav-toggle {
  position: fixed;
  right: 15px;
  top: 15px;
  z-index: 9998;
  border: 0;
  font-size: 24px;
  transition: all 0.4s;
  outline: none !important;
  color: #fff;
  width: 40px;
  height: 40px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  line-height: 0;
  border-radius: 50px;
  cursor: pointer;
} .mobile-nav-active {
  overflow: hidden;
} .mobile-nav-active #theme-navbar {
  left: 0;
}
/* ========================== Navigation end ========================== */

#section-intro {
    <?php if($user->profile->cover_image): ?>
    background: url("<?php echo e(asset('img/covers/'.$user->profile->cover_image)); ?>") center center fixed;
    <?php else: ?>
    background: url("<?php echo e(asset('img/bg/default.jpg')); ?>") center center fixed;
    <?php endif; ?>
}

#section-about .about-img img { min-height: 320px; }

.edu-item {
  padding: 0 0 0 30px;
  margin-top: -2px;
  border-left: 2px solid #0563bb;
  position: relative;
} .edu-item h4 {
  line-height: 18px;
  font-size: 20px;
  font-weight: 600;
  letter-spacing: 1px;
  text-transform: uppercase;
  font-family: "Poppins", sans-serif;
  color: #0563bb;
} .edu-item::before {
  content: "";
  position: absolute;
  width: 16px;
  height: 16px;
  border-radius: 50px;
  left: -9px;
  top: 0;
  background: #fff;
  border: 2px solid #0563bb;
}

@media (max-width: 1199px) {
  #theme-navbar {
    left: calc(var(--sidebar-width) * -1);
  }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- ======= Mobile nav toggle button ======= -->
<i class="bi bi-list mobile-nav-toggle bg-dark d-xl-none"></i>

 <!-- ======================================= Theme sidebar start ================================================== -->
 <header>
 <div id="theme-navbar" class="d-flex flex-column flex-shrink-0 bg-dark">
    <a href="/" class="d-block py-3 px-2 link-dark text-decoration-none">
        <img src="<?php echo e(asset('/img/logo/logo.png')); ?>" class="img-fluid"/>
        <span class="visually-hidden">CVKreatif.com</span>
    </a>
    <hr class="text-white"/>
    <ul class="nav nav-pills nav-flush flex-column mb-auto text-center">
        <li class="nav-item">
            <a href="#section-intro" class="nav-link py-3 mb-3" aria-current="page" title="Home" data-bs-toggle="tooltip" data-bs-placement="right">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
            </a>
        </li>
        <li class="nav-item">
            <a href="#section-about" class="nav-link py-3 mb-3" aria-current="page" title="Tentang saya" data-bs-toggle="tooltip" data-bs-placement="right">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
            </a>
        </li>
        <?php if($educations): ?>
        <li class="nav-item">
            <a href="#section-edu" class="nav-link py-3 mb-3" aria-current="page" title="Pendidikan" data-bs-toggle="tooltip" data-bs-placement="right">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 14l9-5-9-5-9 5 9 5z"></path><path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222"></path></svg>
            </a>
        </li>
        <?php endif; ?>
        <?php if($work_histories): ?>
        <li class="nav-item">
            <a href="#section-exp" class="nav-link py-3 mb-3" aria-current="page" title="Pengalaman" data-bs-toggle="tooltip" data-bs-placement="right">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            </a>
        </li>
        <?php endif; ?>
        <?php if($skills): ?>
        <li class="nav-item">
            <a href="#section-skill" class="nav-link py-3 mb-3" aria-current="page" title="Keterampilan" data-bs-toggle="tooltip" data-bs-placement="right">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
            </a>
        </li>
        <?php endif; ?>
    </ul>
</div>
</header>
<!-- ======================================= Theme sidebar end ================================================== -->

<div id="theme-content" class=""> <!-- ======================================= Theme content start ================================================== -->

<section id="section-intro" class="bg-light vh-100">
    <div class="container h-100 justify-content-center align-items-center">
        <div class="row d-flex h-100 justify-content-center align-items-center"> <!-- row start -->
            <div class="col-md-12 text-center mb-3">
                <div class="mb-5">
                    <!-- <img src="<?php echo e(asset('/img/profiles/'.$user->profile->image)); ?>" class="rounded-circle shadow mb-3"/> -->
                    <h1 class="fw-bolder fs-48 mb-2"><?php echo e($user->profile->first_name.' '.$user->profile->last_name); ?></h1>
                    <h3 class="display-5 fs-28"><?php echo e($user->profile->profession); ?></h3>
                </div>
                <div class="d-flex justify-content-center">
                    <?php if(isset($user->profile->prof_email)): ?>
                    <div class="d-flex align-items-center mx-2">
                        <a href="mailto:<?php echo e($user->profile->prof_email); ?>" class="popper" title="<?php echo e($user->profile->prof_email); ?>" target="_blank" rel="noopener noreferrer">
                            <span class="fs-16 text-white py-1 px-2 rounded me-2" style="background:#BB001B"><i class='bx bx-envelope'></i></span>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($user->profile->li_username)): ?>
                    <div class="d-flex align-items-center mx-2">
                        <a href="<?php echo e($user->profile->li_url); ?>" class="popper" title="<?php echo e($user->profile->li_username); ?>" target="_blank" rel="noopener noreferrer">
                            <span class="fs-16 text-white py-1 px-2 rounded me-2" style="background:#0e76a8"><i class='bx bxl-linkedin'></i></span>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($user->profile->ig_username)): ?>
                    <div class="d-flex align-items-center mx-2">
                        <a href="<?php echo e($user->profile->ig_url); ?>" class="popper" title="<?php echo e($user->profile->ig_username); ?>" target="_blank" rel="noopener noreferrer">
                            <span class="fs-16 text-white py-1 px-2 rounded me-2" style="background:#dd2a7b"><i class='bx bxl-instagram'></i></span>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(isset($user->profile->web_name)): ?>
                    <div class="d-flex align-items-center mx-2">
                        <a href="<?php echo e($user->profile->web_url); ?>" class="popper" title="<?php echo e($user->profile->web_name); ?>" target="_blank" rel="noopener noreferrer">
                            <span class="fs-16 text-white py-1 px-2 rounded me-2" style="background:#404040"><i class='bx bx-link-alt'></i></span>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div> <!-- row end -->
    </div>
</section>

<section id="section-about" class="bg-light py-5">
    <div class="container py-5">
        <div class="row d-flex justify-content-center align-items-center"> <!-- row start -->
            <div class="col-md-10 text-center mb-5">
                <h3 class="display-5 text-primary mb-4">Tentang Saya</h3>
                <?php if($user->profile->biodata): ?>
                <p class="fs-11 mb-0"><?php echo e($user->profile->biodata); ?></p>
                <?php endif; ?>
            </div>
            <div class="col-md-10 d-flex justify-content-center align-items-center flex-remove-md">
                <div class="about-img text-center mb-3">
                    <img src="<?php echo e(asset('/img/profiles/'.$user->profile->image)); ?>" class="rounded shadow mb-3"/>
                </div>
                <div class="about-data col ps-5 mb-3">
                    <table class="table table-borderless">
                        <tbody>
                            <tr>
                                <td class="fw-bold">Nama Lengkap</td>
                                <td><?php echo e($user->profile->first_name.' '.$user->profile->last_name); ?></td>
                            </tr>
                            <?php if(isset($user->profile->birth_date)): ?>
                            <tr>
                                <td class="fw-bold">Tanggal Lahir</td>
                                <td><?php echo e(date('d F Y', strtotime($user->profile->birth_date))); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if(isset($user->profile->address_city)): ?>
                            <tr>
                                <td class="fw-bold">Domisili</td>
                                <td><?php echo e($user->profile->address_city.', '.$user->profile->address_province); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if(isset($user->profile->contact)): ?>
                            <tr>
                                <td class="fw-bold">Kontak</td>
                                <td><?php echo e($user->profile->contact); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if(isset($user->profile->prof_email)): ?>
                            <tr>
                                <td class="fw-bold">Email</td>
                                <td><?php echo e($user->profile->prof_email); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if(isset($user->profile->web_url)): ?>
                            <tr>
                                <td class="fw-bold">Website</td>
                                <td><a href="<?php echo e($user->profile->web_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo e($user->profile->web_name); ?></a></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- row end -->
    </div>
</section>

<?php if($educations || $certifs_training): ?>
<section id="section-edu" class="bg-white py-5">
    <div class="container py-5">
        <div class="row d-flex justify-content-center align-items-center"> <!-- row start -->
            <div class="col-md-10 text-center mb-5">
                <h3 class="display-5 text-primary">Pendidikan</h3>
            </div>
            <?php if($educations): ?>
            <div class="col-md-12 mb-3">
                <h3 class="border-start border-4 border-primary ps-3 text-primary mb-4">Riwayat Pendidikan</h3>
                <?php $i = 300 ?>
                <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- item start -->
                <div class="edu-item-container card p-4 rounded shadow-sm mb-4" data-aos="fade-right" data-aos-duration="<?php echo e($i); ?>">
                    <div class="edu-item">
                        <h4 class="mb-2"><?php echo e($edu->institution); ?></h4>
                        <p class="fst-italic text-secondary fs-12 mb-1"><?php echo e($edu->year_start.' - '.$edu->year_end); ?></p>
                        <p class="fs-14 mb-0"><?php echo e($edu->major); ?></p>
                        <?php if($edu->description): ?><p class="mb-0"><?php echo e($edu->description); ?></p><?php endif; ?>
                    </div>
                </div>
                <!-- item end -->
                <?php $i += 300 ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if($certifs_training): ?>
            <div class="col-md-12">
                <h3 class="border-start border-4 border-primary ps-3 text-primary mb-4">Sertifikat Pelatihan</h3>
                <div class="certif_training-container d-flex flex-wrap">
                    <?php $j = 300 ?>
                    <?php $__currentLoopData = $certifs_training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- item start -->
                    <div class="certif_training-item me-4 mb-3 bg-light text-primary" data-aos="fade-up" data-aos-duration="<?php echo e($j); ?>">
                        <div class="card rounded shadow-sm" data-id="<?php echo e($certif->id); ?>">
                            <div class="my-auto text-center p-3">
                                <a href="<?php echo e(asset('img/certificates/'.$certif->image)); ?>" class="glightbox" data-glightbox="gallery: certificate_training; title: <?php echo e($certif->title); ?> <?php if($certif->issued_by): ?>by <?php echo e($certif->issued_by); ?><?php endif; ?>; description: <?php echo e($certif->description); ?>;">
                                    <img src="<?php echo e(asset('img/certificates/'.$certif->image)); ?>" class="certif-img img-fluid mb-3"/>
                                </a>
                                <p class="fs-10 mb-0"><?php echo e($certif->title); ?></p>
                            </div>
                        </div>
                    </div>
                    <!-- item end -->
                    <?php $j += 300 ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        </div> <!-- row end -->
    </div>
</section>
<?php endif; ?>

<?php if($work_histories): ?>
<section id="section-exp" class="bg-light py-5">
    <div class="container py-5">
        <div class="row d-flex justify-content-center align-items-center"> <!-- row start -->
            <div class="col-md-10 text-center mb-5">
                <h3 class="display-5 text-primary mb-4">Pengalaman</h3>
            </div>
            <div class="col-md-12">
                <h3 class="border-start border-4 border-primary ps-3 text-primary mb-4">Riwayat Pekerjaan</h3>
                <?php $k = 300 ?>
                <?php $__currentLoopData = $work_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- item start -->
                <div class="wh-item-container card p-4 rounded shadow-sm mb-4" data-aos="fade-right" data-aos-duration="<?php echo e($k); ?>">
                    <div class="wh-item">
                        <h5 class="mb-2">
                            <span class="text-primary me-1"><?php echo e($wh->year_start); ?><?php if($wh->year_end): ?> - <?php echo e($wh->year_end); ?><?php else: ?> - Sekarang <?php endif; ?></span> | 
                            <span class="ms-1"><?php echo e($wh->work_place); ?></span>
                        </h5>
                        <p class="d-flex align-items-center fs-14 mb-0">
                            <span class="fw-bold me-2"><?php echo e($wh->role); ?></span>
                            <span class="fs-10 text-white bg-primary px-2 rounded"><?php echo e($wh->employment); ?></span>
                        </p>
                        <?php if($wh->description): ?><p class="text-secondary mb-0"><ul>
                            <?php $wh_descriptions = explode(';', $wh->description); foreach($wh_descriptions as $wh_description) { ?>
                            <?php if($wh_description != null): ?><li><?php echo e($wh_description); ?></li><?php endif; ?>
                            <?php } ?>
                        </ul></p><?php endif; ?>
                    </div>
                </div>
                <!-- item end -->
                <?php $k += 300 ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div> <!-- row end -->
    </div>
</section>
<?php endif; ?>

<?php if($skills || $portfolios): ?>
<section id="section-skill" class="bg-white py-5">
    <div class="container py-5">
        <div class="row d-flex justify-content-center"> <!-- row start -->
            <div class="col-md-10 text-center mb-5">
                <h3 class="display-5 text-primary">Keterampilan</h3>
            </div>
            <div class="col-md-12">
                <h3 class="border-start border-4 border-primary ps-3 text-primary">Keahlian</h3>
            </div>
            <!-- skill item start -->
            <?php $l = 300 ?>
            <?php if($skills): ?>
            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 skill-item p-3 mb-2" data-aos="fade-right" data-aos-duration="<?php echo e($l); ?>">
                <div class="d-flex justify-content-between">
                    <span class="text-primary"><?php echo e($skill->skill); ?></span>
                    <span class="fs-10"><?php echo e($skill->proficiency); ?>0 point</span>
                </div>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-label="<?php echo e($skill->skill); ?>" style="width: <?php echo e($skill->proficiency); ?>0%" aria-valuenow="<?php echo e($skill->proficiency); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
            <?php $l += 300 ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!-- skill item end -->
            <!-- portfolio gallery start -->
            <?php if($portfolios): ?>
            <div class="col-md-12 mt-5">
                <h3 class="border-start border-4 border-primary ps-3 text-primary mb-4">Galeri Portofolio</h3>
                <div class="portfolio-categories d-flex flex-wrap justify-content-center mb-4">
                    <ul id="portfolio-filters">
                    <li data-filter="*" class="btn btn-primary btn-sm mx-2 mb-2">Semua</li>
                    <?php $arr_portfolios = array(); ?>
                    <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!in_array($item->category, $arr_portfolios)): ?>
                    <li data-filter=".filter-<?php echo e(str_replace(' ', '', $item->category)); ?>" class="btn btn-primary btn-sm mx-2 mb-2"><?php echo e($item->category); ?></li>
                    <?php array_push($arr_portfolios, $item->category); ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="portfolio-container ">
                    <?php $m = 300 ?>
                    <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- item start -->
                    <div class="portfolio-item me-3 mb-3 bg-light text-primary filter-<?php echo e(str_replace(' ', '', $portfolio->category)); ?>" data-aos="fade-up" data-aos-duration="<?php echo e($m); ?>">
                        <div class="card rounded shadow-sm" data-id="<?php echo e($portfolio->id); ?>">
                            <div class="my-auto text-center p-2">
                                <a href="<?php echo e(asset('img/portfolios/'.$portfolio->image)); ?>" class="glightbox" data-glightbox="gallery: portfolio; title: <?php echo e($portfolio->title); ?>; description: <?php echo e($portfolio->description); ?>;">
                                    <img src="<?php echo e(asset('img/portfolios/'.$portfolio->image)); ?>" class="portfolio-img img-fluid" style="height:220px"/>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- item end -->
                    <?php $m += 300 ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
            <!-- portfolio gallery end -->
        </div> <!-- row end -->
    </div>
</section>
<?php endif; ?>

<section id="section-footer" class="bg-dark py-5">
    <div class="container">
        <div class="row d-flex justify-content-center align-items-center py-5"> <!-- row start -->
            <div class="col-md-8 text-center">
                <p class="text-light">Powered by : <b>cvkreatif.com</b></p>
            </div>
        </div> <!-- row end -->
    </div>
</div>

</div> <!-- ======================================= Theme content end ================================================== -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
<script>
$(window).resize(function() {
  if($(window).width() < 992) {
      $('#section-about').removeClass('py-5');
      $('.about-data').removeClass('ps-5');
  } else {
      $('.about-data').removeClass('ps-5').addClass('ps-5');
  }
});
$(document).ready(function(){ 
  // window size
  if($(window).width() < 992) {
      $('#section-about').removeClass('py-5');
      $('.about-data').removeClass('ps-5');
  } else {
      $('.about-data').removeClass('ps-5').addClass('ps-5');
  }
});

$('.nav-link').click(function(){
    $('.nav-link').removeClass('active');
    $(this).addClass('active');
});

(function() {
  "use strict";

  // Easy selector helper function
  const select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [...document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }

  // Easy event listener function
  const on = (type, el, listener, all = false) => {
    let selectEl = select(el, all)
    if (selectEl) {
      if (all) {
        selectEl.forEach(e => e.addEventListener(type, listener))
      } else {
        selectEl.addEventListener(type, listener)
      }
    }
  }
  
  // Porfolio isotope and filter 
   window.addEventListener('load', () => {
    let portfolioContainer = select('.portfolio-container');
    if (portfolioContainer) {
      let portfolioIsotope = new Isotope(portfolioContainer, {
        itemSelector: '.portfolio-item'
      });
      let portfolioFilters = select('#portfolio-filters li', true);

      on('click', '#portfolio-filters li', function(e) {
        e.preventDefault();
        portfolioFilters.forEach(function(el) {
          el.classList.remove('filter-active');
        });
        this.classList.add('filter-active');

        portfolioIsotope.arrange({
          filter: this.getAttribute('data-filter')
        });
        portfolioIsotope.on('arrangeComplete', function() {
          AOS.refresh()
        });
      }, true);
    }
  });
  

})()

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_cv', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/themes/default.blade.php ENDPATH**/ ?>