<style>
    #navbar { padding: 12px; }
    .nav-item { margin-left: 6px; }
    #user-img { width: 40px; margin-right: 14px; }
</style>

<div id="section-navbar">
    <nav id="navbar" class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a href="/" class="navbar-brand">Sprachschule Mitra Leipzig</a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav">
                    <a href="/ <?php if(Route::is('index')): ?> #section-news <?php endif; ?>" class="nav-item nav-link disabled">News</a>
                    <li class="nav-item dropdown">
                        <a href="#" role="button" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Schedule &nbsp;</a>
                        <ul class="dropdown-menu">
                            <li><a href="/calendar" class="dropdown-item">Calendar</a></li>
                            <li><a href="/" class="dropdown-item">Assignment</a></li>
                        </ul>
                    </li>
                    <a href="#" class="nav-item nav-link disabled">Reports</a>
                </div>
                <div class="navbar-nav ms-auto">
                    <?php if(auth()->guard()->check()): ?>
                    
                        <div class="dropdown nav-item d-flex vertical-center text-light">
                            <a href="/profile"><img src="<?php echo e(asset('/img/profiles/'.Auth::user()->profile->image)); ?>" id="user-img" alt="" class="img-fluid rounded-circle"></a>
                            <span class="mr-8"><?php echo e(Auth::user()->profile->first_name); ?> <?php echo e(Auth::user()->profile->last_name); ?></span>
                            <i id="user-icon" class='bx bx-chevron-down' type="button" id="user-menu" data-bs-toggle="dropdown" aria-expanded="false"></i>
                            <ul class="dropdown-menu" aria-labelledby="user-menu">
                                <li><a class="dropdown-item" href="/profile">Profile</a></li>
                                <li><a class="dropdown-item" href="/logout">Logout</a></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="/login" class="nav-item nav-link">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\Project - Calendar\iCalendar\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>