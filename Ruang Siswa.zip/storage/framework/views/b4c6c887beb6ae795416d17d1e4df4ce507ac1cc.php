

<?php $__env->startPush('css-styles'); ?>
<style>
@media (max-width:768px) {
    .col-sm-6 { width: 50%; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content">
    <div class="container-fluid">
        <div class="row">

            <!-- user table start -->
            <div class="col-md-12 p-3">
                <div class="shadow p-4 rounded">
                    <table id="table-user" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Full name</th>
                                <th>Profession</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="/cv/<?php echo e($user->username); ?>"><?php echo e($user->username); ?></a></td>
                                <td><?php echo e($user->email); ?></td>
                                <?php if(isset($user->profile)): ?>
                                <td><?php echo e($user->profile->first_name.' '.$user->profile->last_name); ?></td>
                                <td><?php echo e($user->profile->profession); ?></td>
                                <?php else: ?>
                                <td class="text-center">-</td>
                                <td class="text-center">-</td>
                                <?php endif; ?>
                            </tr> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- user table end -->

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('/vendor/chart/chart.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/vendor/chart/chartjs-plugin-datalabels.min.js')); ?>" ></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: .2,
        delay: 0,
        once: true,
    });
});
</script>
<script>
$(document).ready(function(){ 
    $('.nav-link').removeClass('active'); $('#link-overview').addClass('active'); // nav-link active
    // datatables start
    $('#table-user').DataTable({
        order: [[0, 'desc']], responsive: true,
    });
    // datatables end
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/admin/overview.blade.php ENDPATH**/ ?>