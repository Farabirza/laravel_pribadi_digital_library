

<?php $__env->startPush('css-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<style>
body { background: #f9f9f9; }
.popper { cursor: help; }
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark, .icon-dark { color: #124265; } .title-light, .icon-light { color: #f1f1f1; }
.title-icon { font-size: 28pt; }
table tr { vertical-align: middle; }
.form-label { color: #149ddd; }

.report-container {
    border-top: 8px solid #fac863;
    box-shadow: 0 0 1px rgba(0,0,0,.125),0 1px 3px rgba(0,0,0,.2);
}

@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-report -->
<section id="section-report" class="ptb-60">
    <div class="container bg-white ptb-40 report-container">
        <div class="row justify-content-center mb-2">
            <div class="col-md-12 text-center mb-3">
                <i class='bx bxs-report title-icon icon-dark mb-2'></i>
                <h1 class="section-title title-dark">Report</h1`>
            </div>
            <div class="col-md-4">
                <table class="table table-borderless">
                    <tr>
                        <th>Name</th>
                        <td><?php echo e(Auth::user()->profile->first_name.' '.Auth::user()->profile->last_name); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e(Auth::user()->email); ?></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-4">
                <table class="table table-borderless">
                    <tr>
                        <th>Role</th>
                        <td><?php echo e(ucfirst(Auth::user()->role)); ?></td>
                    </tr>
                    <tr>
                        <th>Group</th>
                        <td><?php echo e(Auth::user()->group->name); ?></td>
                    </tr>
                </table>
            </div>
        </div> <!-- row end  -->
        <div class="row justify-content-center">
            <div id="container-report" class="col-md-10">
                <table id="table-report" class="table table-striped">
                    <thead>
                        <th class="col">#</th>
                        <th class="col">Assignments</th>
                        <th class="col">Score</th>
                        <th class="col">Comment</th>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th class="text-center" colspan="4"><?php echo e($subject['subject_title']); ?></th>
                        </tr>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $subject['assignments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?>.</td>
                            <td><?php echo e($assignment['assignment_title']); ?></td>
                            <td><?php echo e($assignment['score']); ?></td>
                            <td><?php echo e($assignment['comment']); ?></td>
                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <th>Total</th>
                            <td><?php echo e($subject['total']); ?></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <th>Average</th>
                            <td><?php echo e($subject['average']); ?></td>
                            <td></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td class="text-center" colspan="4">No assignment data found</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div> <!-- row end  -->
    </div>
</div>
<!-- section-report end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('.nav-link').removeClass('active');
    $('.nav-link-report').addClass('active');
    const lightbox = GLightbox({
        touchNavigation: true,
        loop: true,
        autoplayVideos: true
    });
});
</script>
<script src="<?php echo e(asset('/js/ajax_assignment.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/report/report.blade.php ENDPATH**/ ?>