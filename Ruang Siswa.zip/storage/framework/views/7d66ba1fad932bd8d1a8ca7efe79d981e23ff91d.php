

<?php $__env->startPush('css-styles'); ?>
<style>
.carousel-item img { height: 720px; }
@media (max-width: 1199px) {
    .carousel-item img { height: inherit; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php if(auth()->guard()->guest()): ?>
<section id="section-hero-landing" class="bg-light">
    <div class="container-fluid vh-100">
        <div class="row h-100 d-flex justify-content-center align-items-center">
            <div class="col-md-10 text-center">
                <h1 class="display-1 mb-5">Welcome</h1>
                <div class="w-100 d-flex justify-content-center">
                    <hr class="w-25"/>
                </div>
                <ul class="d-inline fs-18 p-0">
                    <span class="hover-pointer hover-underline mx-3" onclick="modal_login_show()">Sign in</span>
                    <span class="hover-pointer hover-underline mx-3" onclick="modal_register_show()">Sign up</span>
                    <span class="hover-pointer hover-underline mx-3">About</span>
                </ul>
                <div class="w-100 d-flex justify-content-center">
                    <hr class="w-25"/>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<section id="section-content">
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                        <img src="<?php echo e(asset('img/carousel/carousel (1).jpg')); ?>" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>First slide label</h5>
                            <p>Some representative placeholder content for the first slide.</p>
                        </div>
                        </div>
                        <div class="carousel-item">
                        <img src="<?php echo e(asset('img/carousel/carousel (2).jpg')); ?>" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>Second slide label</h5>
                            <p>Some representative placeholder content for the second slide.</p>
                        </div>
                        </div>
                        <div class="carousel-item">
                        <img src="<?php echo e(asset('img/carousel/carousel (3).jpg')); ?>" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>Third slide label</h5>
                            <p>Some representative placeholder content for the third slide.</p>
                        </div>
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>

        <div class="row py-5">
            <div class="col-md-12">
                <h1 class="display-5 text-center mb-4">About Us</h1>
            </div>
            <div class="col-md-6">
                <p class="fs-11">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                <ul class='bx-ul'>
                    <li><i class='bx bx-check-double'></i>Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
                    <li><i class='bx bx-check-double'></i>Duis aute irure dolor in reprehenderit in voluptate velit</li>
                    <li><i class='bx bx-check-double'></i>Excepteur sint occaecat cupidatat non proident</li>
                </ul>
            </div>
            <div class="col-md-6">
                <p class="fs-11">Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <a href="/" class="btn border-2 btn-outline-info">Learn more</a>
            </div>
        </div>

        <div class="row align-items-center py-5 px-4 bg-light">
            <div class="col-md-7">
                <h3 class="display-5 mb-3">Sed do eiusmod <b>tempor incididunt ut labore</b> et dolore magna aliqua. </h3>
                <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
                <a href="/" class="btn border-2 btn-outline-info">Learn more</a>
            </div>
            <div class="col-md-5">
                <img src="<?php echo e(asset('img/materials/photo-1.jpg')); ?>" alt="" class="rounded shadow-sm">
            </div>
        </div>

        <div class="row py-5">
            <div class="col-md-12 text-center mb-4">
                <h1 class="display-5 mb-4">Our Services</h1>
                <p class="w-75 mx-auto fs-11">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit</p>
            </div>
            <div class="col-md-12 d-flex flex-wrap gap-3 justify-content-center">
                <?php for($i=0; $i<=3; $i++) { ?>
                <div class="col card py-4 px-2 shadow">
                    <div class="card-body">
                        <p class="card-text fs-32 text-primary d-flex mb-1"><i class="bx bx-file"></i></p>
                        <p class="card-text fs-18 text-primary mb-1">Lorem Ipsum</p>
                        <p class="card-text fs-11 text-secondary">Necessitatibus eius consequatur ex aliquid fuga eum quidem.</p>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
$(document).ready(function(){
    $('#section-hero-landing').css('margin-top', $('#section-header').outerHeight()*-1);
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Staff\resources\views/index.blade.php ENDPATH**/ ?>