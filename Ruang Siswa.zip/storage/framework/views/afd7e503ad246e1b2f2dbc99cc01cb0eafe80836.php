<!-- Check wether this user is an admin -->
<?php if(Auth::user()->role == 'user'): ?>
<?php header("Location: /?admin=false"); die(); ?>
<?php endif; ?>
<!-- Check wether this user is an admin -->



<?php $__env->startPush('css-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>">
<link href="<?php echo e(asset('/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('/vendor/fontawesome/fontawesome.js')); ?>" crossorigin="anonymous"></script>
<style>
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark, .icon-dark { color: #124265; } .title-light, .icon-light { color: #f1f1f1; }
.title-icon { font-size: 28pt; }
table tr { vertical-align: middle; }
#section-assignments .modal label { color: #149ddd; }
#submissionsTable-container { display: none; }
@media (max-width: 768px) {
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-users -->
<section id="section-users" class="ptb-40">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 mb-3 text-center">
                <i class='bx bxs-user title-icon icon-dark mb-2' ></i>
                <h2 class="section-title title-dark">Users Controller</h2>
            </div>
            <div class="col-md-12">
                <h4 class="mb-3">Users Table</h4>
                <table id="usersTable" class="table table-striped">
                    <thead>
                        <th>#</th>
                        <th>Email</th>
                        <th>Group</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td>
                                <a href="<?php echo e(asset('/img/profiles/'.$user->profile->image)); ?>" data-title="<?php echo e($user->profile->first_name); ?> <?php echo e($user->profile->last_name); ?>" data-description="<?php echo e($user->profile->gender); ?> | <?php echo e($user->group->name); ?>" class="glightbox">
                                    <img src="<?php echo e(asset('/img/profiles/'.$user->profile->image)); ?>" id="user-img" class="rounded-circle">
                                </a>
                                <span class="user_email popper" title="<?php echo e($user->profile->first_name); ?> <?php echo e($user->profile->last_name); ?>"><?php echo e($user->email); ?></span>
                            </td>
                            <td><a href="<?php echo e($user->id); ?>" class="change_group" <?php if($user->group->name==='uncategorized'): ?> style="color:#e95344;" <?php endif; ?>><?php echo e(ucfirst($user->group->name)); ?></a></td>
                            <td>
                                <?php if($user->role == 'user'): ?>
                                <a href="/change_role/<?php echo e($user->id); ?>/admin" class="btn btn-outline-primary btn-sm mr-3"><i class='bx bx-user'></i> User</a>
                                <?php elseif($user->role == 'admin'): ?>
                                <a href="/change_role/<?php echo e($user->id); ?>/superadmin" class="btn btn-outline-primary btn-sm mr-3"><i class='bx bx-star'></i> Super Admin</a>
                                <a href="/change_role/<?php echo e($user->id); ?>/user" class="btn btn-primary btn-sm mr-3"><i class='bx bx-user'></i> Admin</a>
                                <?php elseif($user->role == 'superadmin'): ?>
                                <a href="/change_role/<?php echo e($user->id); ?>/admin" class="btn btn-primary btn-sm mr-3"><i class='bx bxs-star'></i> Super Admin</a>
                                <a href="/change_role/<?php echo e($user->id); ?>/user" class="btn btn-primary btn-sm mr-3"><i class='bx bx-user'></i> Admin</a>
                                <?php endif; ?>
                                <a href="/reset_password/<?php echo e($user->id); ?>" class="btn btn-secondary btn-warn btn-sm mr-3" confirm="Are you sure"><i class='bx bx-key'></i> Reset password</a>
                                <a href="/delete_user/<?php echo e($user->id); ?>" class="btn btn-danger btn-warn-delete btn-sm mr-3"><i class='bx bx-trash'></i> Delete</a>
                            </td>
                            <?php $i++; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">No data found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                <!-- modal change group -->
                <div class="modal fade" id="modal-change_group" aria-hidden="true"> 
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <form action="/change_group" method="post">
                            <?php echo csrf_field(); ?>
                                <div class="modal-header d-flex justify-content-between vertical-center">
                                    <h4 class="modal-title">Change User Group</h4>
                                    <button type="button" id="cancel-change_group" class="btn btn-secondary btn-sm mr-4"><i class="fa-solid fa-x"></i></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="user_id" id="user_id" value="">
                                    <select name="group" id="select-change_group" class="form-control form-select">
                                        <option value="-" selected disabled hidden>Select Group</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($group->name); ?>"><?php echo e($group->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class='bx bx-arrow-back'></i> Cancel</button>
                                    <button type="submit" class="btn btn-primary" id="submit-change_group"><i class='bx bx-edit-alt' ></i> Change</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- modal change group end --> 

            </div>
        </div>
    </div>
</section>
<!-- section-users end -->

<!-- section-groups -->
<section id="section-groups" class="ptb-40 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 mb-3 text-center">
                <i class='bx bx-group title-icon icon-dark mb-2' ></i>
                <h2 class="section-title title-dark">Groups Controller</h2>
            </div>
            <div class="col-md-12">
                <h4 class="mb-3">Groups Table</h4>
                <table id="groupsTable" class="table table-striped">
                    <thead>
                        <th>#</th>
                        <th>Group name</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $j = 1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($j); ?></td>
                            <td><span <?php if($group->name==='uncategorized'): ?> style="color:#e95344;" <?php endif; ?>><?php echo e(ucfirst($group->name)); ?></span></td>
                            <form action="/update_group" method="post">
                            <?php echo csrf_field(); ?>
                                <td class="d-flex">
                                    <input type="hidden" name="group_id" value="<?php echo e($group->id); ?>">
                                    <span class="mr-8"><input type="text" class="form-control form-control-sm" name="group_name" placeholder="Edit group's name"></span>
                                    <button type="submit" class="btn btn-primary btn-sm mr-8"><i class='bx bx-edit-alt' ></i> Update</button>
                                    <a type="button" href="/delete_group/<?php echo e($group->id); ?>" class="btn btn-danger btn-sm btn-warn-delete mr-3"><i class='bx bx-trash'></i> Delete</a>
                                </td>
                            </form>
                            <?php $j++; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3">No data found</td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <form action="/new_group" method="post">
                            <?php echo csrf_field(); ?>
                            <td colspan="3">
                                <div class="d-flex">
                                    <span class="mr-8"><input type="text" name="new_group" class="form-control" placeholder="New group name"></span>
                                    <button type="submit" class="btn btn-primary mr-8"><i class='bx bx-message-square-add' ></i> Create a new group</button>
                                </div>
                            </td>
                            </form>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<!-- section-groups end -->

<!-- section-assignments -->
<section id="section-assignments" class="ptb-40">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 mb-3 text-center">
                <i class='bx bx-task title-icon icon-dark mb-2' ></i>
                <h2 class="section-title title-dark">Assignments Controller</h2>
            </div>

            <!-- assignmentsTable start -->
            <div class="col-md-12 mb-4">
                <div class="d-flex justify-content-between mb-2">
                    <h4>Assignments Table</h4>
                    <a id="new-assignment" href="#" class="btn btn-outline-primary popper" title="New assignment"><i class='bx bx-plus' ></i></a>
                </div>
                <table id="assignmentsTable" class="table table-striped">
                    <thead>
                        <th>#</th>
                        <th>Title</th>
                        <th>Target Group</th>
                        <th>Submission</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $k = 1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($k); ?></td>
                            <td><span class="popper" title="<?php echo e($item->description); ?>"><?php echo e($item->title); ?></span></td>
                            <td><?php echo e($item->group->name); ?></td>
                            <td><?php echo e($submission_count[$item->id]); ?> / <?php echo e($group_member_count[$item->group->name]); ?></td>
                            <td>
                                <a href="<?php echo e($item->id); ?>" class="assignment-show btn btn-success btn-sm mr-4"><i class='bx bx-show'></i> Show</a>
                                <a href="/delete_assignment/<?php echo e($item->id); ?>" class="btn-warn-delete btn btn-danger btn-sm mr-4"><i class='bx bx-trash'></i> Delete</a>
                            </td>
                            <?php $k++; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <!-- assignmentsTable end -->

            <!-- submissionsTable -->
            <div id="submissionsTable-container" class="col-md-12 card padd-20 box-shadow-2 mb-4">
                <h4 id="submissionsTable-title" class="mb-2">Assignment Title</h4>
                <table id="submissionsTable" class="table table-striped">
                    <thead>
                        <th>#</th>
                        <th>User Name</th>
                        <th>Submitted At</th>
                        <th>Comment</th>
                        <th>Action</th>
                    </thead>
                    <tbody id="submissions-list">
                        <tr>
                            <td colspan="5" class="text-center">No submission data found</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- submissionsTable end -->
        </div> <!-- Row end -->

        <!-- Modal New Assignment -->
        <div class="modal fade" id="modal-assignment" aria-hidden="true"> 
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">New Assignment</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/new_assignment" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-floating mb-3">
                                <input type="text" name="assignment_title" id="assign_title" class="form-control" placeholder="Title" required>
                                <label for="assign_title">Title</label>
                            </div>
                            <div class="form-floating mb-3">
                                <select name="assignment_group" id="assign_group" class="form-control form-select" required>
                                    <option selected hidden disabled>Select group</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($group->name); ?>"><?php echo e($group->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value="-" disabled>Group empty</option>
                                    <?php endif; ?>
                                </select>
                                <label for="assign_group">Target group</label>
                            </div>
                            
                            <div class="form-group">
                                <div class="d-flex mb-3">
                                    <div class="col form-floating">
                                        <input type="date" name="assignment_date_start" id="assign_date_start" class="form-control" value="<?php echo e($date_today); ?>" required>
                                        <label for="assign_date_start">Limit start date</label>
                                    </div>
                                    <span>&ensp;</span>
                                    <div class="col form-floating">
                                        <input type="date" name="assignment_date_end" id="assign_date_end" class="form-control" value="<?php echo e($date_today); ?>" required>
                                        <label for="assign_date_end">Limit end date</label>
                                    </div>
                                </div>
                                <div class="d-flex">
                                    <div class="col form-floating">
                                        <input type="time" id="assign_time_start" name="assignment_time_start" value="00:00" class="form-control" required>
                                        <label for="assign_time_start">Open time</label>
                                    </div>
                                    <span>&ensp;</span>
                                    <div class="col form-floating">
                                        <input type="time" name="assignment_time_end" id="assign_time_end" class="form-control" value="23:59" required>
                                        <label for="assign_time_end">Close time</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-floating">
                                <textarea name="assignment_description" id="assign_description" style="height:100px" class="form-control" placeholder="( Optional )"></textarea>
                                <label for="assign_description">Brief description</label>
                            </div>
                    </div>
                    <div class="modal-footer">
                            <button type="button" id="cancel-newAssign" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Cancel</button>
                            <button type="submit" id="submit-newAssign" class="btn btn-primary"><i class='bx bx-message-square-add' ></i> Create assignment</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal New Assignment end -->
        
        <!-- Modal Comment -->
        <div class="modal fade" id="modal-comment" aria-hidden="true"> 
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Comment</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="form-comment" action="/dashboard_ajax" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-floating">
                            <textarea name="comment" id="input-comment" style="height:100px" class="form-control" placeholder=""></textarea>
                            <label for="input-comment">Put your comment here</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary mr-4" data-bs-dismiss="modal" aria-label="Close"><i class='bx bx-arrow-back'></i> Cancel</button>
                        <button type="submit" class="btn btn-primary" id="submit-comment"><i class='bx bx-paper-plane' ></i> Send</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Modal Comment end -->

    </div>
</section>
<!-- section-assignments end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
$(document).ready(function(){
    var usersTable = $('#usersTable').DataTable();
    var assignmentsTable = $('#assignmentsTable').DataTable();
    $('#new-assignment').click(function(e){
        e.preventDefault();
        $('#modal-assignment').modal('show');
    });
    const lightbox = GLightbox({
        touchNavigation: true,
        loop: true,
        autoplayVideos: true
    });
    
    usersTable.on('order.dt search.dt', function () {
        let i = 1;
        usersTable.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(i++);
        });
    }).draw();
    assignmentsTable.on('order.dt search.dt', function () {
        let j = 1;
        assignmentsTable.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(j++);
        });
    }).draw();
    $('.change_group').click(function(e){
        e.preventDefault();
        var user_id = $(this).attr('href');
        $('#user_id').val(user_id);
        $('#modal-change_group').modal('show');
        $('#cancel-change_group').click(function(){
            $('#modal-change_group').modal('hide');
            $('#submit-change_group').unbind();
        });
    });
});
</script>
<script src="<?php echo e(asset('/js/ajax_dashboard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project - Calendar\Sprachschule Mitra Leipzig\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>