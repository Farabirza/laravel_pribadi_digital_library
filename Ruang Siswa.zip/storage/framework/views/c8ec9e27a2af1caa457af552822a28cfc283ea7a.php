

<?php $__env->startPush('css-styles'); ?>
<link href="<?php echo e(asset('/vendor/datatables/datatables.min.css')); ?>" rel="stylesheet">
<style>
body { background: #f9f9f9; min-height: 100vh; vertical-align: center; }
table thead th { font-weight: 500; }
.alert { font-size: 9pt; padding: 10px; }
.form-label { color: var(--bs-primary); font-size: 11pt; }
.dropdown-item { display: flex; align-items: center; gap: 8px; padding-left: 10px; }
.dropdown-item:hover { cursor: pointer; }

@media (max-width: 1199px) {
}
@media (max-width: 768px) {
}
</style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section class="py-5">
    <div class="container">
        <!-- breadcrumb start -->
        <div class="my-4">
            <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item">Admin</li>
                    <li class="breadcrumb-item active" aria-current="page">User controller</li>
                </ol>
            </nav>
        </div>
        <!-- breadcrumb end -->
        <div class="row my-4">
            <div class="col-md-12 p-4 bg-white rounded shadow">
                <h3 class="d-flex align-items-center gap-2 fs-18 mb-3"><i class="bx bx-user"></i>Users</h3>
                <table id="table-users" class="table table-striped fs-9">
                    <thead>
                        <th>#</th>
                        <th>Full name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Authority</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e(($user->profile ? $user->profile->full_name : '-')); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e(($user->profile ? $user->profile->role : '-')); ?></td>
                            <td><?php echo e($user->authority->name); ?></td>
                            <td>
                                <div class="dropdown">
                                    <i class="bx bx-dots-vertical bx-border-circle btn-outline-dark p-1" role="button" data-bs-toggle="dropdown" aria-expanded="false"></i>
                                    <div class="dropdown-menu fs-10">
                                        <div class="dropdown-item" onclick="modalPassword('<?php echo e($user->id); ?>', '<?php echo e($user->email); ?>')"><i class="bx bx-key"></i>Reset password</div>
                                        <div class="dropdown-item" onclick="modalAuthority('<?php echo e($user->id); ?>', '<?php echo e($user->authority->id); ?>', '<?php echo e($user->email); ?>')"><i class="bx bx-crown"></i>Change authority</div>
                                        <div class="dropdown-item" onclick="modalNotification('<?php echo e($user->id); ?>')"><i class="bx bx-message"></i>Send notification</div>
                                    </div>

                                </div>
                            </td>
                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('layouts.partials.modal_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables.min.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
    new DataTable('#table-users', {
        fixedColumns: true,
        ordering: false,
        searching: true,
    });
    $('#link-admin').addClass('active');
    $('#submenu-admin').addClass('show');
    $('#link-admin-user').addClass('active');
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Digital Library - New\Pribadi Depok Digital Library\resources\views/admin/user.blade.php ENDPATH**/ ?>