

<?php $__env->startPush('css-styles'); ?>
<style>
@media (max-width:768px) {
    .col-sm-6 { width: 50%; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-sm-6 p-4">
                <div class="shadow p-4 text-center">
                    <h1 class="display-3 purecounter" data-purecounter-end="<?php echo e($count_visit_today_auth); ?>">0</h1>
                    <p class="fs-11 text-secondary mb-0">Pengunjung terdaftar hari ini</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 p-4">
                <div class="shadow p-4 text-center">
                    <h1 class="display-3 purecounter" data-purecounter-end="<?php echo e($count_visit_today_guest); ?>">0</h1>
                    <p class="fs-11 text-secondary mb-0">Pengunjung tidak terdaftar hari ini</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 p-4">
                <div class="shadow p-4 text-center">
                    <h1 class="display-3 purecounter" data-purecounter-end="<?php echo e($count_visit_thisMonth_auth); ?>">0</h1>
                    <p class="fs-11 text-secondary mb-0">Pengunjung terdaftar bulan ini</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 p-4">
                <div class="shadow p-4 text-center">
                    <h1 class="display-3 purecounter" data-purecounter-end="<?php echo e($count_visit_thisMonth_guest); ?>">0</h1>
                    <p class="fs-11 text-secondary mb-0">Pengunjung tidak terdaftar bulan ini</p>
                </div>
            </div>
            <div class="col-md-12 p-4">
                <p class="fst-italic fs-11 text-secondary"><a href="/dashboard/analytics">Lihat data selengkapnya &raquo;</a></p>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('/vendor/chart/chart.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/vendor/chart/chartjs-plugin-datalabels.min.js')); ?>" ></script>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: .2,
        delay: 0,
        once: true,
    });
});
</script>
<script>
$(document).ready(function(){ 
    $('.nav-link').removeClass('active'); $('#link-overview').addClass('active'); // nav-link active

});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/dashboard/overview.blade.php ENDPATH**/ ?>