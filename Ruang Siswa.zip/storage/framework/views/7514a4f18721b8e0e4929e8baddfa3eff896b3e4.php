<?php if(auth()->guard()->guest()): ?>
<?php header("Location: /?login=required"); die(); ?>
<?php endif; ?>



<?php $__env->startPush('css-styles'); ?>
<style>
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-form" class="bg-light py-60">
    <div class="container">
        <div class="mb-4 d-flex flex-wrap align-items-center">
            <span class="me-3"><i class='bx bx-error text-warning fs-24'></i></span>
            <span class="col text-secondary fs-11">Dengan mengisi form ini, anda dianggap telah menyetujui <a href="" class="text-primary">ketentuan dan kondisi</a> yang berlaku. Anda diperkenankan untuk <b>mengosongkan kotak isian yang anda rasa tidak perlu.</b></span>
        </div>
        <div class="row mb-4 align-items-center">
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold text-dark ps-3 mb-3 fs-32 bl-dark-md">Profil</h3>
            </div>

            <div class="col-md-12"> <!-- col form start -->

                <!-- name  -->
                <div class="form-group d-flex mb-4">
                    <div class="form-floating col">
                        <input type="text" class="form-control" name="first_name" placeholder="Nama depan" value="<?php echo e(old('first_name')); ?>">
                        <label for="first_name" class="form-label">Nama depan</label>
                    </div>
                    <span>&ensp;</span>
                    <div class="form-floating col">
                        <input type="text" class="form-control" name="last_name" placeholder="Nama belakang" value="<?php echo e(old('last_name')); ?>">
                        <label for="last_name" class="form-label">Nama belakang</label>
                    </div>
                </div>
                <!-- name end -->

                <!-- gender & birth data  -->
                <div class="form-group mb-4">
                    <div class="d-flex">
                        <div class="form-floating col">
                            <select id="gender" name="gender" class="form-control form-select">
                                <option value="select" selected disabled hidden>Gender</option>
                                <option value="male">Laki-laki</option>
                                <option value="female">Perempuan</option>
                            </select>
                            <label for="gender" class="form-label">Jenis kelamin</label>
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <span>&ensp;</span>
                        <div class="form-floating col">
                            <input type="date" min="1950-01-01" max="<?php echo e(date('Y-m-d', time())); ?>" id="birth_date" class="form-control" name="birth_date" value="" required>
                            <label for="birth_date" class="form-label">Tanggal lahir</label>
                        </div>
                    </div>
                </div>
                <!-- gender & birth data end -->
                
                <!-- address -->
                <div class="form-group mb-3">
                    <label class="text-muted mb-2">Domisili</label>
                    <div class="d-flex">
                        <div class="form-floating col">
                            <input type="text" class="form-control" name="address_city" placeholder="City" value="<?php echo e(old('city')); ?>" required>
                            <label for="city" class="form-label">Kota / kabupaten</label>
                        </div>
                        <span>&ensp;</span>
                        <div class="form-floating col">
                            <input type="text" class="form-control" name="address_province" placeholder="Province" value="<?php echo e(old('province')); ?>" required>
                            <label for="province" class="form-label">Provinsi</label>
                        </div>
                        <span>&ensp;</span>
                        <div class="form-floating col">
                            <input type="number" class="form-control" name="zip" placeholder="Zip" value="<?php echo e(old('zip')); ?>" required>
                            <label for="zip" class="form-label">Kode pos</label>
                        </div>
                    </div>
                </div>
                <!-- address -->

            </div><!-- col form start end -->
        </div> <!-- row end -->

        <div class="row align-items-center"> <!-- row start -->
            <div class="col-md-12 mb-4">
                <h3 class="fw-bold text-dark ps-3 fs-32 bl-dark-md">Profesi</h3>
            </div>
            <div class="col-md-12"> <!-- col form start -->
                
            <!-- profession  -->
            <label class="text-muted mb-2">Profesi terakhir</label>
            <div class="form-group mb-4">
                <div class="form-floating">
                    <input type="text" class="form-control" name="profession" placeholder="profession" value="<?php echo e(old('profession')); ?>" required>
                    <label for="profession" class="form-label">Profesi</label>
                </div>
            </div>
            <div class="form-group d-flex mb-4">
                <div class="form-floating col">
                    <input type="text" class="form-control" name="profession" placeholder="profession" value="<?php echo e(old('profession')); ?>" required>
                    <label for="profession" class="form-label">Nama perusahaan / instansi</label>
                </div>
                <span>&ensp;</span>
                <div class="form-floating col">
                    <select id="job_status" name="job_status" class="form-control form-select">
                        <option value="select" selected disabled hidden>Job status</option>
                        <option value="full_time">Waktu penuh (full time)</option>
                        <option value="part_time">Paruh waktu (part time)</option>
                        <option value="freelance">Freelance</option>
                    </select>
                    <label for="job_status" class="form-label">Status pekerjaan</label>
                </div>
            </div>
            <!-- profession end -->

            </div> <!-- col form end -->
        </div> <!-- row end -->
    </div>
</section>
<section class="text-light bg-dark">
    <div class="container">
        <div class="row vh-100 align-items-center">
            <h1 class="display-1 text-center">Hello World</h1>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif\Laravel CVKreatif\resources\views/cv/cv_create.blade.php ENDPATH**/ ?>