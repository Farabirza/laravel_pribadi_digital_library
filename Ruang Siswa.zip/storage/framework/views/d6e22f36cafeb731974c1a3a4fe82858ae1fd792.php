<?php if(auth()->guard()->guest()): ?>
<?php header("Location: /?login=required"); die(); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />

<meta name="description" content="Buat CV Kreatif online kamu sendiri gratis di cvkreatif.com" />
<meta property="og:image" content="<?php echo e(asset('img/bg/office-1.jpg')); ?>" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.1.1.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/cropper/cropper.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>CVKreatif.com | Salin Alamat Halaman CV</title>
  
<style>
#section-login {
    height: 100vh;
    background: #f8e9a1;
    background-size: cover;
}

.overlay-container { position: relative; }
#overlay-img img {
    opacity: 1;
    display: block;
    width: 100%;
    height: auto;
    transition: .5s ease;
    backface-visibility: hidden;
}
.overlay {
    transition: .5s ease;
    opacity: 0;
    position: absolute;
    text-align: center;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
}
.overlay-container:hover #overlay-img img { opacity: 0.3; }
.overlay-container:hover .overlay { opacity: 1; }
.overlay-text { background-color: var(--bs-primary); color: white; font-size: 10pt; padding: 4px 10px; border: 1px solid var(--bs-primary); }
.overlay-text:hover { cursor:pointer; background-color: #fff; color: var(--bs-primary); transition: .5s; }
.cropper-preview { overflow: hidden; height: 180px; margin: 10px; border: 1px solid red; }
</style>
</head>
<body>

<section class="bg-light vh-100">
    <div class="container h-100">

        <!-- Profile IMG -->
        <div class="row d-flex h-100 justify-content-center align-items-center"> <!-- row start -->
            <div class="col-md-8">
                <div class="alert alert-success text-center mb-4" role="alert">
                    <span>CV berhasil dibuat, silahkan salin alamat dibawah untuk dibagikan ke rekan anda.</span>
                </div>
                <div class="d-flex justify-content-center"> <!-- col start -->
                    <!-- replace profile image -->
                    <div class="overlay-container col-md-4 text-center mb-3">
                        <label for="replace-img">
                            <div id="overlay-img">
                                <img src="<?php echo e(asset('/img/profiles/'.Auth::user()->profile->image)); ?>" id="profile-img" alt="" class="rounded-circle shadow">
                            </div>
                            <div class="overlay">
                                <div id="overlay-text" class="overlay-text rounded">Ubah foto profil</div>
                            </div>
                        </label>
                    </div>
                    <form id="form-profile_img" action="/profile_img" enctype="multipart/form-data" method="POST">
                        <input id="replace-img" class="absolute d-none" name="profile-img" type="file">
                    </form>
                    <!-- replace profile image end -->
                </div> <!-- col end -->
                <div class="text-center mb-3"> <!-- col start -->
                    <h3 class="display-5"><?php echo e(Auth::user()->profile->first_name." ".Auth::user()->profile->last_name); ?></h3>
                    <h4 class="fw-bold"><?php echo e(Auth::user()->profile->profession); ?></h3>
                </div> <!-- col end -->
                <div class="d-flex justify-content-center mb-4"> <!-- col start -->
                    <div class="text-center mb-3">
                        <p class="fs-12 text-secondary">Link menuju halaman CV kamu :</p>
                        <div class="input-group rounded me-2">
                            <input id="link" class="form-control" type="text" aria-label="Copy" value="https://cvkreatif.com/cv/<?php echo e(Auth::user()->username); ?>">
                            <!-- <button id="copy" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Salin alamat halaman CV"><i class='bx bx-clipboard'></i> Salin alamat</button> -->
                            <button id="copy" class="btn btn-primary"><i class='bx bx-clipboard'></i> Salin alamat halaman CV</button>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                    <a href="/" class="btn btn-secondary me-2"><i class='bx bxs-home'></i> Kembali ke halaman utama</a>
                    <a href="/cv/<?php echo e(Auth::user()->username); ?>" class="btn btn-success"><i class='bx bx-file-blank'></i> Menuju halaman CV</a>
                </div>
            </div> <!-- col end -->
        </div>
        <!-- Profile IMG end -->

    </div>
</section>

<!-- modal image cropper -->
<div class="modal fade" id="modal-profile-image-cropper" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-md-8">
                            <img id="img-crop" src="">
                        </div>
                        <div class="col-md-4">
                            <div class="cropper-preview"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batalkan</button>
                <button type="button" class="btn btn-primary" id="crop">Pilih</button>
            </div>
        </div>
    </div>
</div>
<!-- modal image cropper end -->

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/cropper/cropper.min.js')); ?>"></script>

<script>
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

// for ajax_profile
var source_page = '/wizard/finish';

$(document).ready(function(){ 
    <?php if(isset($_GET['complete'])): ?>
    Swal.fire({
      icon: 'success',
      title: "Sukses!",
      text: "Halaman CV anda berhasil dibuat",
      showConfirmButton: false,
      timer: 2000
    });
    <?php endif; ?>
});

$('#copy').click(function(e){
    e.preventDefault();
    let link = document.getElementById('link');
    link.select(); link.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(link.value);
    $(this).tooltip('hide').tooltip('disable').removeClass('btn-primary').addClass('btn-success').html('<i class="bx bx-check-double" ></i> Alamat telah disalin');
    // $(this).attr('data-bs-original-title', 'Alamat telah disalin');
    // toastr.info('Link berhasil disalin', 'Info');
});

// btn-theme-activate
$('.btn-theme-activate').click(function(e) {
    $('.btn-theme-activate').removeClass('active btn-primary').addClass('btn-outline-primary').html(
        '<i class="bx bx-check"></i> Aktifkan'
    );
    $(this).addClass('active btn-primary').removeClass('btn-outline-primary').html(
        '<i class="bx bx-check-double"></i> Aktif'
    );
});

$('input[name=profile-img]').change(function(e){
    var modal = $('#modal-profile-image-cropper');
    var image = document.getElementById('img-crop');
    var cropper;
    modal.modal('show');

    let reader = new FileReader();
    reader.onload = (e) => { 
        $('#img-crop').attr('src', e.target.result); 
    }
    reader.readAsDataURL(this.files[0]); 

    modal.on('shown.bs.modal', function () {
        cropper = new Cropper(image, {
        aspectRatio: 1, viewMode: 3, preview: '.cropper-preview',
        });
    }).on('hidden.bs.modal', function () {
        cropper.destroy();
        cropper = null;
    });
    $("#crop").click(function(){
        var canvas = cropper.getCroppedCanvas({
            width: 320,
            height: 320,
        });
        canvas.toBlob(function(blob) {
            url = URL.createObjectURL(blob);
            var reader = new FileReader();
            reader.readAsDataURL(blob); 
            reader.onloadend = function() {
                var base64data = reader.result; 
                $.ajax({
                    type: "POST",
                    url: "/ajax/profile",
                    data: { action: 'update_profile_img', profile_img: base64data },
                    dataType: "json",
                    success: function(data) {
                        modal.modal('hide');
                        successMessage(data.message);
                        location.reload();
                    }, error: function(data) {
                        errorMessage('Foto profil anda gagal diperbaharui');
                        return false;
                    }
                });
            }
        });
    });
});
function successMessage(message) { toastr.success(message, 'Success!'); } 
function infoMessage(message) { toastr.info(message, 'Info'); } 
function warningMessage(message) { toastr.error(message, 'Warning!'); } 
function errorMessage(message) { toastr.error(message, 'Error!'); } 
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\CV Kreatif\cvkreatif.com\resources\views/cv/wizard_finish.blade.php ENDPATH**/ ?>