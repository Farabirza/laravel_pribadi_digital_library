

<?php $__env->startPush('css-styles'); ?>
<style>
    .section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
    .title-dark { color: #124265; } .title-light { color: #f1f1f1; }
    #section-hero {
        padding: 200px 0;
        background: url('../img/bg/bg_trans-80.png') top left repeat, url("../img/bg/bg-hero-1.jpg") top center transparent fixed;
        color: white;
        text-align: center;
    }
    .btn-hero1 { margin-right: 20px; padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: white; color: #202020; }
    .btn-hero1:hover { background: transparent; color: white; transition: ease .4s; }
    .btn-hero2 { padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: transparent; }
    .btn-hero2:hover { background: white; color: #202020; transition: ease .4s; }

    #section-counter {
        background: url('../img/bg/bg_trans-60.png') top left repeat, url("../img/bg/bg-hero-1.jpg") top center transparent fixed; 
        background-size: cover;
        color: #f1f1f1;
    } #section-counter p { margin-bottom: 0; font-size: 11pt }
    #section-counter .purecounter { font-size: 42pt; font-weight: 600; margin-bottom: 10px; }

    .news-item { padding: 0 10px 20px 10px; }
    .news-item .card:hover { box-shadow: 2px 2px 10px #333; }

    .contact-info { display: flex; align-items: center; margin-bottom: 30px; }
    .contact-info h5 { color: #124265; font-weight: 600; }
    .contact-info p { margin: 0; font-size: 11pt; color: #217bbc }
    .contact-icon { background: #e3f0fa; border-radius: 4px; height: 50px; width: 50px; justify-content: center; align-items: center; display: flex; margin-right: 20px; font-size: 20pt; color: #2487ce; }
    @media (max-width: 768px) {
        #section-hero { padding: 40px 0; }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- section-hero -->
<section id="section-hero">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="display-4 mb-20">Welcome</h1>
                <p class="mb-40">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec accumsan nulla. Quisque elit urna, cursus a rutrum nec, pharetra non dui. Vivamus quis vestibulum purus. Nullam ullamcorper risus vitae tempor maximus. Fusce a sapien quis sapien maximus tempus.</p>
                <div class="d-flex justify-content-center">
                    <a href="#section-news" class="btn-hero1 scrollTo">News</a>
                    <a href="/calendar" class="btn-hero2">Calendar</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- section-hero end -->

<!-- section-news -->
<section id="section-news" class="section">
    <div class="container">

        <div class="row justify-content-center mb-40">
            <div class="col-md-12">
                
                <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                        <img src="<?php echo e(asset('img/bg/landscape-1.jpg')); ?>" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>First slide label</h5>
                            <p>Some representative placeholder content for the first slide.</p>
                        </div>
                        </div>
                        <div class="carousel-item">
                        <img src="<?php echo e(asset('img/bg/landscape-1.jpg')); ?>" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>Second slide label</h5>
                            <p>Some representative placeholder content for the second slide.</p>
                        </div>
                        </div>
                        <div class="carousel-item">
                        <img src="<?php echo e(asset('img/bg/landscape-1.jpg')); ?>" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>Third slide label</h5>
                            <p>Some representative placeholder content for the third slide.</p>
                        </div>
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>

            </div>
        </div> <!-- row end -->

        <div class="row justify-content-center mb-20">

            <?php for($i = 1; $i <= 8; $i++): ?>
            <div class="news-item col-md-3"> <!-- news-item -->
                <div class="card">
                    <img src="<?php echo e(asset('img/bg/bg-hero-1.jpg')); ?>" alt="">
                    <div class="card-body">
                        <h5 class="card-title">News</h5>
                        <p class="card-text">Quisque elit urna, cursus a rutrum nec, pharetra non dui.</p>
                        <a href="#" class="btn btn-primary">Read more</a>
                    </div>
                </div>
            </div> <!-- news-item end -->
            <?php endfor; ?>

        </div> <!-- row end  -->

        <div class="row">
            <div class="col-md-12 d-flex flex-wrap justify-content-center">
                <nav aria-label="Page navigation example">
                    <ul class="pagination">
                        <li class="page-item"><a class="page-link" href="#" aria-label="First"><span aria-hidden="true">&laquo;</span></a></li>
                        <li class="page-item"><a class="page-link" href="#"><span aria-hidden="true">Previous</span></a></li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#"><span aria-hidden="true">Next</span></a></li>
                        <li class="page-item"><a class="page-link" href="#" aria-label="Last"><span aria-hidden="true">&raquo;</span></a></li>
                    </ul>
                </nav>
            </div>
        </div> <!-- row end  -->

    </div>
</section>
<!-- section-news end -->

<!-- section-counter -->
<section id="section-counter" class="section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 align-center mb-30">
                <h2 class="section-title title-light mb-10">What We Have Achieved</h2>
                <p>Vivamus euismod elementum elit, eget tincidunt mi aliquam vel.</p>
            </div>
            <div class="col-md-10 d-flex">
                <div class="col align-center">
                    <h1 class="purecounter" data-purecounter-end="80">0</h1>
                    <p>Clients</p>
                </div>
                <div class="col align-center">
                    <h1 class="purecounter" data-purecounter-end="144">0</h1>
                    <p>Projects</p>
                </div>
                <div class="col align-center">
                    <h1 class="purecounter" data-purecounter-end="11">0</h1>
                    <p>Partners Across the World</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- section-counter end -->

<!-- section-action -->
<section id="section-action" class="section bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 align-center">
                <h2 class="section-title title-dark mb-10">Call to Action</h2>
                <p style="font-size:11pt">Phasellus posuere, odio diam gravida nibh, quis volutpat ligula sem eu sem. Nam eget ante malesuada, vehicula ante et, mattis velit.</p>
                <button class="btn btn-outline-primary">Click here</button>
            </div>
        </div>
    </div>
</section>
<!-- section-action end -->

<!-- section-contact -->
<section id="section-contact" class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 align-center mb-30">
                <h1 class="section-title title-dark mb-10">CONTACT US</h1>
                <p style="font-size:11pt">Quisque id lacus volutpat, eleifend urna at, tempus ante.</p>
            </div>
            <div class="col-md-12 mb-30">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d16327777.283213008!2d108.85076622122007!3d-2.4153216792310515!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2c4c07d7496404b7%3A0xe37b4de71badf485!2sIndonesia!5e0!3m2!1sen!2sid!4v1651801389775!5m2!1sen!2sid" style="border:0;width:100%;height:320px" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <div class="col-md-4">
                <div class="contact-info">
                    <i class='bx bx-location-plus contact-icon'></i>
                    <div class="contact-data"><h5>Location</h5><p>Indonesia</p></div>
                </div>
                <div class="contact-info">
                    <i class='bx bx-envelope contact-icon'></i>
                    <div class="contact-data"><h5>Email</h5><p>company_email@gmail.com</p></div>
                </div>
                <div class="contact-info">
                    <i class='bx bx-phone contact-icon'></i>
                    <div class="contact-data"><h5>Call</h5><p>+62 5589 55488 55s</p></div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="form-group d-flex">
                    <input type="text" class="form-control mr-8" placeholder="Your name">
                    <input type="text" class="form-control" placeholder="Your email">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Subject">
                </div>
                <div class="form-group">
                    <textarea name="" id="" rows="5" class="form-control" placeholder="Message"></textarea>
                </div>
                <button class="btn btn-primary btn-md">Send Message</button>
            </div>
        </div>
    </div>
</section>
<!-- section-contact end -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project - Calendar\iCalendar\resources\views/index.blade.php ENDPATH**/ ?>