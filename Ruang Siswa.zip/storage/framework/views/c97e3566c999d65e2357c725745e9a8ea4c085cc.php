<section id="section-footer">
    <div class="container">
        <div class="row justify-content-center ptb-20">
            <div class="col-md-10 text-center">
                <p>© Copyright <a href="https://mitraleipzig.de/" target="_blank">Sprachschule Mitra Leipzig</a></p>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>