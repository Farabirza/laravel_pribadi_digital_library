<!-- Check login status -->
<?php if(auth()->guard()->check()): ?>
<?php header("Location: /home"); die(); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="description" content="Learning Management System by Sprachschule Mitra Leipzig" />
<meta name="keywords" lan="en" content="Sprachschule Mitra Leipzig, LMS, Learning Management System, JournalSML" />
<meta property="og:type" content="website" />
<meta property="og:title" content="JournalSML" />
<meta property="og:description" content="Learning Management System by Sprachschule Mitra Leipzig." />
<meta property="og:url" content="https://www.journalsml.co.id/" />
<meta property="og:site_name" content="JournalSML.co.id" />
<meta property="og:image" content="//journalsml.co.id/img/bg/mitraleipzig-min.png" />
<meta property="og:image:type" content="image/png" />
<meta property="og:image:width" content="1366" />
<meta property="og:image:height" content="768" />

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/jquery/jquery-3.1.1.min.js')); ?>"></script>

<!-- Favicons -->
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('/img/logo/logo.png')); ?>" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="<?php echo e(asset('/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/vendor/toastr/toastr.min.css')); ?>" rel="stylesheet">

<!-- Main CSS File -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet">

<title>Sprachschule Mitra Leipzig</title>

<style>
.section-title { font-family: 'Raleway',sans-serif; font-weight: bold; }
.title-dark { color: #124265; } .title-light { color: #f1f1f1; }
#section-hero {
    height: 100vh;
    background: url('../img/bg/bg_trans-60.png') top left repeat, url("../img/bg/mitraleipzig-min.png") top center transparent fixed;
    background-size: cover;
    color: white;
    text-align: center;
}
.hero-title {
    text-transform: uppercase;
    letter-spacing: 2px;
    font-weight: 800;
}
.btn-hero1 { margin-right: 20px; padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: white; color: #202020; }
.btn-hero1:hover { background: transparent; color: white; transition: ease .4s; }
.btn-hero2 { padding: 10px 20px; border: 1px solid white; border-radius: 4px; background: transparent; }
.btn-hero2:hover { background: white; color: #202020; transition: ease .4s; }

@media (max-width: 768px) {
}
</style>
</head>
<body>

<!-- section-hero -->
<section id="section-hero">
    <div class="container">
        <div class="row vh-100 vertical-center justify-content-center">
            <div class="col-md-10">
                <img src="<?php echo e(asset('img/logo/logo.png')); ?>" alt="">
                <h1 class="hero-title display-1 mb-20">Sprachschule Mitra Leipzig</h1>
                <a href="#section-about" class="scrollTo"><p class="mb-40" style="font-size:22pt;font-family:raleway;">About Us<br><i class='bx bx-chevrons-down' ></i></p></a>
                <div class="d-flex justify-content-center">
                    <a href="/login" class="btn btn-primary btn-lg mr-15"><i class='bx bx-log-in'></i> Login</a>
                    <a href="/register" class="btn btn-success btn-lg"><i class='bx bx-user' ></i> Register</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- section-hero end -->

<!-- section-about -->
<section id="section-about">
    <div class="container">
        <div class="row justify-content-center ptb-60">
            <div class="col-md-10 mb-3">
                <h1 class="section-title title-dark">About Us</h1>
            </div>
            <div class="col-md-10">
                <p class="mb-3"><b>Sprachschule Mitra Leipzig</b> adalah Sekolah Bahasa Jerman yang berafiliasi langsung dengan Privates Studienkolleg Leipzig Halle Neuzelle di Negara Jerman, berkedudukan di Indonesia dengan kantor pusat di Jakarta, dan kantor Cabang di Bali, Medan dan Pontianak, untuk memajukan kaum muda Indonesia dan menghasilkan SDM unggul dengan kemampuan intra dan inter personal di era Revolusi Industri 4.0, melalui pembelajaran bahasa dan pengenalan budaya Jerman serta mendorong kerjasama antara Indonesia dan Jerman ke arah positif, mampu memenuhi kebutuhan industri dan pembangunan nasional dengan membangun komunitas pembelajar berpengetahuan teknologi modern, sebagai bakti kepada Nusantara.</p>
                <p class="mb-3"><b>Sprachschule Mitra Leipzig</b> dirancang bagi Peserta Didik untuk ujian sertifikasi resmi Bahasa Jerman berstandart ALTE sebagaimana yang digunakan untuk:</p>
                <ul>
                    <li>Berbincang, tinggal dan hidup di Negara Jerman.</li>
                    <li>Program persiapan perkuliahan di Jerman, termasuk Studienkolleg.</li>
                    <li>Persiapan Sekolah Vokasi di Jerman berbasis kompetensi yang Link and Match dengan industri.</li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- section-about end -->

</body>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/popper/popper.min.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('/js/main.js')); ?>"></script>

<!-- Purecounter -->
<script src="<?php echo e(asset('/vendor/purecounter/purecounter.js')); ?>">
$(document).ready(function(){
    var purecounter = new PureCounter({
        selector: ".purecounter",
        duration: 2,
        delay: 10,
        once: true,
    });
});
</script>
<script type="text/javascript">
$(document).ready(function(){
  <?php if(session('success')): ?>
    successMessage("<?php echo e(session('success')); ?>");
  <?php elseif(session('error')): ?>
    errorMessage("<?php echo e(session('error')); ?>");
  <?php endif; ?>
  <?php if(isset($_GET['admin']) == 'false'): ?>
    Swal.fire({
      icon: 'error',
      title: "Access Denied!",
      text: "You are not an admin!",
      showConfirmButton: false,
      timer: 2000
    });
  <?php endif; ?>
  
});
  function successMessage(message) {
      toastr.success(message, 'Success!');
  } 
  function infoMessage(message) {
      toastr.info(message, 'Info');
  } 
  function warningMessage(message) {
      toastr.error(message, 'Warning!');
  } 
  function errorMessage(message) {
      toastr.error(message, 'Error!');
  } 
</script>
</html><?php /**PATH C:\xampp\htdocs\Sprachschule Mitra Leipzig\Sprachschule Mitra Leipzig\resources\views/index.blade.php ENDPATH**/ ?>