

<?php $__env->startPush('css-styles'); ?>
<style>
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section id="section-wizard-config" class="section-wizard py-5">
    <div class="container">

        <div class="row bg-white p-4 rounded shadow mb-4">
            <div class="col-md-12">
                <h2 class="section-title mt-3 mb-4">Config</h2>

                <!-- form config start -->
                <?php if(Auth::user()->config): ?>
                <form action="ajax/config/<?php echo e(Auth::user()->config->id); ?>" method="put" id="form-config" class="m-0">
                <?php else: ?>
                <form action="ajax/config" method="post" id="form-config" class="m-0">
                <?php endif; ?>
                <div class="mb-3">
                    <label for="accessibility" class="form-label">Accessibility</label>
                    <select name="accessibility" id="config-accessibility" class="form-select form-select-sm mb-2">
                        <option value="public">Public</option>
                        <option value="registered">Registered</option>
                        <option value="private">Private</option>
                    </select>
                    <p class="mb-2 fs-9 text-muted fst-italic">*) decide who can access your cv page</p>
                </div>
                </form>
                <!-- form config end -->

                <div class="mb-3">
                    <label class="form-label">Select theme</label>
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-3 px-2 pb-3">
                            <div class="card">
                                <img src="<?php echo e(asset('img/theme_preview/'.$theme->image)); ?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($theme->title); ?></h5>
                                    <?php if($theme->description): ?>
                                    <p class="card-text fs-10 text-muted"><?php echo e($theme->description); ?></p>
                                    <?php else: ?>
                                    <p class="card-text fs-10 text-muted"><?php echo e($theme->title); ?> is a cool and interactive online portfolio layout that will blow your mind</p>
                                    <?php endif; ?>
                                    <div class="d-flex align-items-center justify-content-end gap-2">
                                        <?php if(Auth::user()->config && Auth::user()->config->preference->theme_id == $theme->id): ?>
                                        <button id="btn-select-theme-<?php echo e($key+1); ?>" class="btn-select-theme btn btn-primary btn-sm d-flex align-items-center" onclick="selectTheme('<?php echo e($theme->id); ?>', '<?php echo e($key+1); ?>')"><i class="bx bx-check-double me-2"></i>Selected</button>
                                        <?php else: ?>
                                        <button id="btn-select-theme-<?php echo e($key+1); ?>" class="btn-select-theme btn btn-outline-primary btn-sm d-flex align-items-center" onclick="selectTheme('<?php echo e($theme->id); ?>', '<?php echo e($key+1); ?>')"><i class="bx bx-check me-2"></i>Select</button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="d-flex align-items-center mb-3">
                    <hr class="col me-3"/>
                    <button id="config-btn-submit" type="button" class="btn btn-success d-flex align-items-center" onclick="submitConfig()"><i class='bx bxs-save me-2' ></i>Save</button>
                </div>
            </div>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/js/ScriptConfig.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function() { 
    $(`[name="accessibility"] option[value="`+'<?php echo e(Auth::user()->config->accessibility); ?>'+`"]`).prop('selected', true);
});
var username = '<?php echo e(Auth::user()->username); ?>';
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV Kreatif 2.0\cvkreatif.com\resources\views/dashboard/edit_config.blade.php ENDPATH**/ ?>